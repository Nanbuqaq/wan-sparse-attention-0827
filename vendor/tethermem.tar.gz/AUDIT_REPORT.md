# TetherMem repository audit

Audit date: 2026-08-18

## Paths and project boundary

Scanned root:

```text
/mnt/vision-gen-ks3-yzjs/Video_Generation/lichen/code/video_stream_generation
```

Output repository:

```text
/mnt/vision-gen-ks3-yzjs/Video_Generation/lichen/code/TetherMem
```

The 100 GB `project_runs/TetherMem` directory is an experiment-artifact tree,
not a publishable source repository. It is dominated by generated videos,
logs, masks, comparison packages, metrics, blind evaluation packages, and
archives.

The actual implementation boundary is composite:

- final generation-time routing implementation:
  `project_runs/TetherMem/tethermem_auto_routing_iteration_20260711_082715/scripts/rfra_patch_routing.py`;
- final generation driver:
  `project_runs/TetherMem/tethermem_auto_routing_iteration_20260711_082715/scripts/run_table1_R2R4.py`;
- canonical config:
  `project_runs/TetherMem/tethermem_routing_mechanism_analysis_20260717_100935/config/tethermem_base.yaml`;
- modified backbone source: `repos/LongLive-RAG-main`.

The later analysis copy of the routing patch contains additional diagnostics.
Its analysis report says the forward path is unchanged, but this release uses
the frozen generation-iteration source rather than substituting that later
copy.

The scan-root `.git` entry was not a usable repository: it contained only an
`info/exclude` stub and no `HEAD`, refs, or object history. The output therefore
does not inherit any root history.

## Audit method

The source audit covered:

- Python, Shell, YAML, JSON, TOML, JS/TS, notebooks, README files, configs, and
  tests;
- nested Git worktrees, refs, and all reachable history;
- `.env*`, invitation files, private/blind naming patterns, database suffixes,
  absolute developer paths, URL/DSN patterns, and credential-related terms;
- ZIP/TAR member names and bounded readable text from 18 archives;
- large files, model/checkpoint suffixes, generated media, caches, logs, and
  build outputs;
- exact token-like formats for common cloud and model-host credentials, without
  printing matching values.

`gitleaks` was not installed. An attempted temporary official binary download
did not complete, so the audit used `rg --no-ignore`, bounded archive readers,
Git-native history searches, filename/type inspection, and exact-format
patterns as the equivalent scanner. Matching values were never printed or
copied into this report.

## Source findings

### Credential-like material

Exact token-format matches occurred only in excluded experiment reports/logs
and one metric-definition document. The findings were classified by path and
format (`SK_LIKE` or `HF_LIKE`) without reading values into the report. None of
those files was copied.

Credential-related variable names in public source are limited to the optional
Wan prompt-extension integration. That integration reads its value from the
runtime environment, is not used by TetherMem inference, is now an optional
import, and is not enabled by any release config. W&B training is also optional
and defaults off.

No runtime credential value is embedded in copied Python, Shell, YAML,
requirements, or documentation.

### Private evaluation material

The source tree contains explicit private and blind evaluation assets,
including names matching:

```text
PRIVATE_AB_MAPPING.json
PRIVATE_PAIR_MAPPING.json
*_pair_mapping.csv
private_*
blind_eval*
assignment*
invite_token.txt
```

Related packages contain prompt assignments, pair keys, annotation keys,
databases, original labels, and blind videos. All such content is excluded.
No private mapping was converted into a public fixture.

### Archives

Eighteen ZIP/TAR archives were inventoried without extracting them into the
release. Several contained private mappings, blind media, or experiment
packages. Readable-text inspection found many development-machine absolute
paths but no exact credential-format or database-DSN match. Every archive is
excluded regardless of that negative scan because none is necessary for the
source execution path.

### Nested repositories and history

The following nested repositories were inspected and excluded in full:

| Repository | HEAD | All-history commits | Finding |
| --- | --- | ---: | --- |
| VideoX-Fun | `804a4258e2608f855ccaec8fffa279e75a3b89c6` | 228 | token-like and assignment-like history hits; unrelated to TetherMem source boundary |
| Wan2.2 | `42bf4cfaa384bc21833865abc2f9e6c0e67233dc` | 51 | assignment-like README/prompt-extension hits; wrong backbone |
| SAM2 | `2b90b9f5ceec907a1c18123530e92e794ad901a4` | 104 | token-like notebook examples; integration remains external |

No nested `.git` directory or history was copied. The SAM2 commit is recorded
only so an operator can install the public mask dependency separately.

## Upstream model verification

Public GitHub and Hugging Face metadata were checked for LongLive-RAG,
LongLive, and Wan. `docs/MODELS.md` records exact revisions and sizes.

The actual backbone is `Wan-AI/Wan2.1-T2V-1.3B`. The canonical TetherMem path
loads `causal_forcing.pt` and `ae_latent_mem.pt`; it does not load
`longlive_lora.pt`. The LongLive base/LoRA pair is retained only for the public
LongLive-RAG latent-corpus workflow.

The local `repos/LongLive-RAG-main` source is materially different from the
checked public GitHub revision in its inference entrypoint, causal pipeline,
latent-memory model, AE code, Wan wrapper, and VAE. Replacing it with current
upstream source would remove dependencies used by TetherMem and was therefore
not done.

Absolute model symlinks in the local tree were not copied:

```text
repos/LongLive-RAG-main/checkpoints
repos/LongLive-RAG-main/toydatasets
repos/LongLive-RAG-main/wan_models/Wan2.1-T2V-1.3B
```

## Included content

The clean repository includes only:

- the required modified `ae/`, `pipeline/`, `utils/`, and `wan/` source;
- selected LongLive-RAG configs and corpus/AE training entrypoints;
- the frozen TetherMem routing implementation;
- a portable single-prompt reference/TetherMem inference CLI;
- automatic center-subject SAM2 selection, generic explicit-box tracking, and a
  clearly labeled synthetic smoke mask generator;
- a one-command reference -> SAM2 -> TetherMem orchestration entrypoint with a tracking-quality
  gate and paired diagnostics;
- focused tests;
- public model downloader;
- release, model, reproducibility, license, and third-party documentation.

The clean implementation changes local absolute model paths to `MODEL_ROOT`,
uses repository-relative defaults, makes online integrations opt-in, removes
hard-coded experiment GPU lists, and atomically writes important outputs.

## Excluded content

The clean repository excludes:

- original `.git` data and every nested repository;
- `.env*`, invitations, cookies, credential values, and private service config;
- all private/blind mappings, assignments, annotations, databases, and
  evaluation packages;
- experiment masks, prompts tied to private assignments, videos, metrics,
  reports, logs, and result tables;
- model weights, public or private datasets, latent tensors, checkpoints, and
  model symlinks;
- ZIP/TAR packages and temporary exports;
- `.venv`, caches, `node_modules`, `.next`, `.wrangler`, `dist`, and build
  products;
- the old broad `inference.py` entrypoint, which was replaced by the scoped
  portable TetherMem CLI.

Negative or failed source artifacts remain untouched in the original tree;
they were excluded, not deleted or relabeled.

## Portability fixes

- `MODEL_ROOT` resolves both Wan and LongLive-RAG assets.
- The default ignored layout is `models/wan_models/...` and
  `models/longlive_rag/...`.
- Shell launchers use `set -euo pipefail` and propagate worker failures.
- GPU selection is an operator environment choice; workers address their first
  visible device as `cuda:0`.
- W&B is disabled by default and imported only when explicitly enabled.
- DashScope is optional and no longer a core import dependency.
- The custom generation entrypoint disables and asserts cuDNN state before
  model construction, then runs a real bf16 CUDA `Conv3d` preflight.
- Videos, checkpoints, latent tensors, masks, configs, and completion metadata
  use same-directory temporary files followed by atomic rename.
- A generated MP4 is retained if its later decode check fails.

## Validation record

Static acceptance used independent clones under `/tmp`, the required repository
Python executable, and committed source rather than untracked files. The
automatic orchestration is committed as `d487f94`. Its GPU run used the same
script content immediately before that commit, on top of source revision
`4aeda84`; the child run metadata therefore records the base revision.

| Check | Result |
| --- | --- |
| `pip install -r requirements-dev.txt` from fresh clone | passed; exact release dependencies resolved with the repository Python |
| Python `compileall` | passed for `ae`, `pipeline`, `utils`, `wan`, `tethermem`, `scripts`, and `generate_latent.py` |
| Import check | passed for AE, pipeline, Wan, routing, masks, paths, and atomic I/O |
| Config parse | passed; canonical model is Wan 1.3B and default mode is TetherMem |
| Unit/CLI tests | 16 passed; two non-failing SWIG deprecation warnings |
| Existing tests | all tests present in the clean repository passed |
| Downloader dry-runs | passed with a model-root path containing spaces; pinned repositories, revisions, include patterns, and matching SAM2 Hiera-L URL were preserved |
| Shell syntax | passed for all four Shell launchers |
| `git diff --check` and committed-tree whitespace check | passed |
| Git object integrity | `git fsck --full --no-dangling` passed |
| README runtime absolute-path scan | passed; no developer-machine path in commands or runtime docs |
| Local Markdown target check | passed |
| GPU device/node/driver visibility | passed: one NVIDIA M403, driver 570.124.06, 143771 MiB |
| PyTorch CUDA allocation | passed with PyTorch 2.6.0+cu124 and CUDA runtime 12.4 |
| cuDNN-disabled bf16 CUDA `Conv3d` | passed |
| Real short-video model smoke | passed on NVIDIA M403: TetherMem, 21 latent frames, 81 decoded frames at 832x480/16 fps, 10.92 s; one retrieval event; 30 patched layers, hook counts 5..5 |
| Automatic 21-frame full-pipeline smoke | passed: reference generation, automatic box `[179,82,650,426]`, SAM2 tracking 81/81 with IoU 0.9932, quality gate, TetherMem generation, and paired diagnostics |
| Canonical reference generation | passed: LongLive-RAG reference, 120 latent frames, 474 fully decoded 832x480 frames at 16 fps, 34 retrieval events, 163.24 s |
| Real SAM2 mask extraction | passed with Hiera-L and explicit teapot box: 474/474 tracked, zero held frames, mean area 0.2844, consecutive IoU 0.9904; early/middle/late overlays visually accepted |
| Canonical TetherMem generation | passed with a real SAM2 mask, 120 latent frames, 474 fully decoded nonblank frames, 34 retrieval events, 30 patched modules with hook counts 170..170, 206.76 s |
| Paired technical diagnostics | passed: matching count/rate/shape and normalized mean absolute pixel difference 0.1331; no perceptual-quality claim |
| Automatic 120-frame full pipeline | passed: reference in 161.77 s; automatic box `[179,85,653,414]`; SAM2 474/474, no held frames, IoU 0.9905; TetherMem in 280.70 s with 34 retrieval events and routing hooks 170..170; paired pixel difference 0.1132 |
| Automatic visual review | passed for this prompt: selector plus early/middle/late mask overlays covered the teapot; TetherMem frames 0, 237, and 473 were visible and retained the intended subject |
| Full latent-corpus generation and AE training | not executed; these are expensive workflows, not static acceptance checks |
| Workspace exact-format secret/DSN/private-key scan | passed; no match |
| Full new-history exact-format secret/DSN/private-key scan | passed; no match |
| High-entropy long-string scan | passed at Shannon entropy threshold 4.8; no candidate |
| Forbidden filename, suffix, and object-size scan | passed; no private mapping, database, archive, model weight, media, or Git object over 10 MiB |

`gitleaks` remained unavailable. The final equivalent scans operated on both
the worktree and every commit in the new history and emitted paths only. Generic
keyword hits were reviewed as code identifiers or negative documentation: for
example, tokenizer/model terminology and the optional prompt extension's
runtime-only credential variable. No credential value was present.

### GPU follow-up details

The smoke reused existing external public model files through a temporary
`MODEL_ROOT` layout; no weight was copied into this repository. The resolved
files were:

```text
/mnt/vision-gen-ssd-yzjs/Video_Generation/lichen33/checkpoints/Wan2.1-T2V-1.3B/
/mnt/vision-gen-ssd-yzjs/Video_Generation/lichen33/checkpoints/LongLive-RAG/checkpoints/causal_forcing.pt
/mnt/vision-gen-ssd-yzjs/Video_Generation/lichen33/checkpoints/LongLive-RAG/checkpoints/ae_latent_mem.pt
```

The first attempted 18-latent-frame check completed denoising but correctly
failed its routing assertion because `recent_exclude=5` left no eligible
history frame. The portable validator and README now require 21 frames for the
default routing smoke. A subsequent 21-frame run exposed a PyAV float-rate
compatibility issue; `materialize_video` now passes an explicit rational frame
rate. The final 21-frame run passed the CUDA preflight, model load, TetherMem routing,
atomic MP4 write, and PyAV decode. The generated MP4 and smoke metadata remain
under ignored `outputs/` and are excluded from Git and the release ZIP.

The canonical follow-up used the same public checkpoints and prompt for both
generations. LongLive-RAG first produced the real reference video. SAM2 commit
`2b90b9f5ceec907a1c18123530e92e794ad901a4` and the matching public
`sam2_hiera_large.pt` checkpoint tracked a manually inspected first-frame box.
Its optional connected-components extension was unavailable, so upstream
hole-filling post-processing was skipped; the base tracker completed and the
three saved overlays showed a coherent teapot mask. TetherMem then consumed the
resulting `[474,30,52]` mask and completed all routing checks. Both final MP4s
decoded end to end. These generated artifacts are ignored and excluded from
the release archive.

The later automatic run exercised the new wrapper without a supplied box. SAM2
automatic mask generation produced 19 first-frame candidates and the
class-agnostic center-subject prior chose the complete teapot. Tracking passed
the configured 95% tracked / 5% held quality gate, and TetherMem plus diagnostics ran
without manual stage commands. This proves automation for the documented
centered single-subject prompt; it does not prove semantic target selection for
arbitrary off-center or multi-subject prompts. The wrapper retains `--box` and
re-anchor overrides for those cases.

## Reproducibility classification

The source, model resolver, config, downloaders, automatic selector, mask
contract, one-command wrapper, CPU entry checks, full LongLive-RAG reference,
real SAM2 track, and full TetherMem output correspond. The documented public teapot
workflow is therefore automatic canonical-inference verified. Full AE
retraining, semantic selection for arbitrary prompts, perceptual superiority,
cross-GPU bit-exact output, and the original private evaluation table remain
unverified or unavailable. See `REPRODUCIBILITY.md` for the exact boundary.

The clean working tree and every commit in its new history contain no detected
real API key, token, password, cookie, invitation, private credential, or
private annotation/database material.

## Source preservation

No file under the scan root was deleted or modified while assembling this
output. All changes were made only in the separate clean output directory.
