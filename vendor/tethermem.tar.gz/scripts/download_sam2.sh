#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
model_root="${MODEL_ROOT:-${repo_root}/models}"
dry_run="${DRY_RUN:-0}"

checkpoint_url="https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_large.pt"
checkpoint_dir="${model_root}/sam2"
checkpoint_path="${checkpoint_dir}/sam2_hiera_large.pt"
partial_path="${checkpoint_path}.part"

if [[ "${dry_run}" == "1" ]]; then
    printf 'curl --fail --location --output %q %q\n' \
        "${partial_path}" "${checkpoint_url}"
    printf 'mv %q %q\n' "${partial_path}" "${checkpoint_path}"
    exit 0
fi

if [[ -s "${checkpoint_path}" ]]; then
    echo "SAM2 checkpoint already exists at ${checkpoint_path}"
    exit 0
fi

if ! command -v curl >/dev/null 2>&1; then
    echo "curl is required to download the SAM2 checkpoint." >&2
    exit 1
fi

mkdir -p "${checkpoint_dir}"
curl_args=(--fail --location --output "${partial_path}")
if [[ -f "${partial_path}" ]]; then
    curl_args+=(--continue-at -)
fi
curl "${curl_args[@]}" "${checkpoint_url}"
mv "${partial_path}" "${checkpoint_path}"

echo "SAM2 checkpoint downloaded to ${checkpoint_path}"
