#!/usr/bin/env python3
"""Select a central subject box from the first frame with SAM2 AMG.

SAM2's automatic mask generator is class-agnostic.  This module therefore
uses a deterministic central-subject prior rather than pretending to perform
open-vocabulary prompt grounding.  The selected candidate and its diagnostics
are written to JSON so a caller can reject or override a poor selection.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from utils.io import atomic_json_dump


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Use SAM2 automatic masks to choose a central salient subject box "
            "from video frame 0. The selector is class-agnostic."
        )
    )
    parser.add_argument("--video", type=Path, required=True)
    parser.add_argument("--sam2-repo", type=Path, required=True)
    parser.add_argument("--sam2-config", required=True)
    parser.add_argument("--sam2-checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--overlay", type=Path)
    parser.add_argument("--points-per-side", type=int, default=16)
    parser.add_argument("--points-per-batch", type=int, default=64)
    parser.add_argument("--pred-iou-thresh", type=float, default=0.7)
    parser.add_argument("--stability-score-thresh", type=float, default=0.8)
    parser.add_argument("--min-mask-region-area", type=int, default=100)
    parser.add_argument("--device", default="cuda")
    return parser


def read_first_frame(path: Path) -> tuple[np.ndarray, np.ndarray]:
    import cv2

    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise RuntimeError(f"unable to open video: {path}")
    ok, bgr = capture.read()
    capture.release()
    if not ok or bgr is None:
        raise RuntimeError(f"video has no readable first frame: {path}")
    return bgr, cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)


def _area_prior(area_fraction: float) -> float:
    # Prefer a coherent object-sized region without requiring a fixed subject
    # size.  The broad prior still permits small or large centered subjects.
    area = max(area_fraction, 1e-6)
    return float(np.exp(-((np.log(area) - np.log(0.20)) / 1.15) ** 2))


def score_candidate(
    annotation: dict[str, Any], image_shape: tuple[int, int]
) -> dict[str, Any] | None:
    mask = np.asarray(annotation.get("segmentation"), dtype=bool)
    if mask.ndim != 2 or not mask.any():
        return None
    height, width = image_shape
    ys, xs = np.where(mask)
    x0, x1 = int(xs.min()), int(xs.max()) + 1
    y0, y1 = int(ys.min()), int(ys.max()) + 1
    area_fraction = float(mask.mean())
    center_x, center_y = width / 2.0, height / 2.0
    centroid_x, centroid_y = float(xs.mean()), float(ys.mean())
    diagonal = float(np.hypot(width, height))
    center_distance = float(
        np.hypot(centroid_x - center_x, centroid_y - center_y) / diagonal
    )
    center_proximity = max(0.0, 1.0 - center_distance)
    contains_center = bool(mask[height // 2, width // 2])
    touches_edge = bool(x0 <= 1 or y0 <= 1 or x1 >= width - 1 or y1 >= height - 1)
    predicted_iou = float(annotation.get("predicted_iou", 0.0))
    stability = float(annotation.get("stability_score", 0.0))
    score = (
        4.0 * float(contains_center)
        + 2.0 * center_proximity
        + 1.5 * predicted_iou
        + stability
        + _area_prior(area_fraction)
        - 2.0 * float(touches_edge)
    )
    if area_fraction < 0.01 or area_fraction > 0.85:
        score -= 2.0
    return {
        "score": float(score),
        "area_fraction": area_fraction,
        "bbox_xyxy": [x0, y0, x1, y1],
        "bbox_xywh": [x0, y0, x1 - x0, y1 - y0],
        "centroid": [centroid_x, centroid_y],
        "center_distance": center_distance,
        "contains_center": contains_center,
        "touches_edge": touches_edge,
        "predicted_iou": predicted_iou,
        "stability_score": stability,
    }


def rank_candidates(
    annotations: list[dict[str, Any]], image_shape: tuple[int, int]
) -> list[dict[str, Any]]:
    ranked: list[dict[str, Any]] = []
    for index, annotation in enumerate(annotations):
        scored = score_candidate(annotation, image_shape)
        if scored is not None:
            scored["index"] = index
            ranked.append(scored)
    ranked.sort(key=lambda item: item["score"], reverse=True)
    return ranked


def write_overlay(
    bgr: np.ndarray, mask: np.ndarray, box: list[int], destination: Path
) -> None:
    import cv2

    destination.parent.mkdir(parents=True, exist_ok=True)
    overlay = (bgr.astype(np.float32) * 0.55).astype(np.uint8)
    overlay[mask.astype(bool)] = (0, 255, 0)
    x0, y0, x1, y1 = box
    cv2.rectangle(overlay, (x0, y0), (x1, y1), (0, 0, 255), 2)
    cv2.imwrite(str(destination), overlay)


def main() -> int:
    args = build_parser().parse_args()
    if not args.video.is_file():
        raise FileNotFoundError(f"video not found: {args.video}")
    if not args.sam2_repo.is_dir():
        raise FileNotFoundError(f"SAM2 repository not found: {args.sam2_repo}")
    if not args.sam2_checkpoint.is_file():
        raise FileNotFoundError(f"SAM2 checkpoint not found: {args.sam2_checkpoint}")
    if args.points_per_side <= 0 or args.points_per_batch <= 0:
        raise ValueError("points-per-side and points-per-batch must be positive")

    bgr, image = read_first_frame(args.video)
    height, width = image.shape[:2]

    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("automatic SAM2 subject selection requires a CUDA GPU")
    torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = False

    sam2_path = str(args.sam2_repo.resolve())
    if sam2_path not in sys.path:
        sys.path.insert(0, sam2_path)
    from sam2.automatic_mask_generator import SAM2AutomaticMaskGenerator
    from sam2.build_sam import build_sam2

    model = build_sam2(
        config_file=args.sam2_config,
        ckpt_path=str(args.sam2_checkpoint),
        device=args.device,
    )
    generator = SAM2AutomaticMaskGenerator(
        model,
        points_per_side=args.points_per_side,
        points_per_batch=args.points_per_batch,
        pred_iou_thresh=args.pred_iou_thresh,
        stability_score_thresh=args.stability_score_thresh,
        min_mask_region_area=args.min_mask_region_area,
    )
    annotations = generator.generate(image)
    ranked = rank_candidates(annotations, (height, width))
    if not ranked:
        raise RuntimeError("SAM2 automatic mask generation returned no candidates")

    selected = ranked[0]
    selected_annotation = annotations[int(selected["index"])]
    selected_mask = np.asarray(selected_annotation["segmentation"], dtype=np.uint8)
    atomic_json_dump(
        {
            "selection_method": "sam2_amg_center_subject_prior",
            "class_agnostic": True,
            "video": str(args.video),
            "frame_index": 0,
            "height": height,
            "width": width,
            "candidate_count": len(ranked),
            "selected": selected,
            "top_candidates": ranked[:20],
        },
        args.output,
    )
    if args.overlay:
        write_overlay(bgr, selected_mask, selected["bbox_xyxy"], args.overlay)
    print(
        "Automatic subject box: "
        f"{selected['bbox_xyxy']} ({len(ranked)} candidates, "
        f"score={selected['score']:.3f})"
    )
    print(f"Selection metadata: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
