"""Command-line entrypoints for the clean TetherMem repository."""
