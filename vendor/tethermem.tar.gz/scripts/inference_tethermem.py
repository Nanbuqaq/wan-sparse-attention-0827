#!/usr/bin/env python3
"""Portable single-prompt inference for LongLive-RAG and TetherMem."""

from __future__ import annotations

import argparse
import os
import socket
import subprocess
import sys
import tempfile
import time
from fractions import Fraction
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from utils.io import atomic_json_dump


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Generate one video with the frozen TetherMem routing patch."
    )
    parser.add_argument("--prompt", help="Text prompt for a single generated video")
    parser.add_argument("--mask", type=Path, help="Subject mask .npy with shape [T,30,52]")
    parser.add_argument(
        "--mode",
        choices=("baseline", "tethermem"),
        default="tethermem",
        help="Generate the LongLive-RAG reference or apply TetherMem routing",
    )
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--frames", type=int, help="Override latent output-frame count")
    parser.add_argument("--output", type=Path, default=Path("outputs/tethermem.mp4"))
    parser.add_argument("--config", type=Path, default=Path("configs/tethermem.yaml"))
    parser.add_argument("--model-root", type=Path)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--fps", type=float, default=16.0)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--no-low-memory", action="store_true")
    parser.add_argument("--routing-diagnostics", action="store_true")
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Parse and validate config/CLI without importing or loading CUDA models",
    )
    parser.add_argument(
        "--require-models",
        action="store_true",
        help="With --validate-only, fail when required model files are absent",
    )
    return parser


def load_config(args: argparse.Namespace):
    if args.model_root is not None:
        os.environ["MODEL_ROOT"] = str(args.model_root.expanduser())

    from omegaconf import OmegaConf

    if not args.config.is_file():
        raise FileNotFoundError(f"config not found: {args.config}")
    config = OmegaConf.load(args.config)
    if args.frames is not None:
        config.num_output_frames = args.frames
    config.seed = args.seed
    config.routing_mode = args.mode
    config.sam2_mask_path = str(args.mask) if args.mask is not None else None
    config.region_factorize = True
    config.routing_diag_active = args.routing_diagnostics
    OmegaConf.to_container(config, resolve=True)
    return config


def required_model_paths(config: Any) -> list[Path]:
    from utils.paths import wan_model_dir

    wan_dir = wan_model_dir(str(config.model_name))
    return [
        wan_dir / "diffusion_pytorch_model.safetensors",
        wan_dir / "models_t5_umt5-xxl-enc-bf16.pth",
        wan_dir / "Wan2.1_VAE.pth",
        wan_dir / "config.json",
        wan_dir / "google" / "umt5-xxl" / "special_tokens_map.json",
        wan_dir / "google" / "umt5-xxl" / "spiece.model",
        wan_dir / "google" / "umt5-xxl" / "tokenizer.json",
        wan_dir / "google" / "umt5-xxl" / "tokenizer_config.json",
        Path(str(config.generator_ckpt)),
        Path(str(config.model_kwargs.ae_ckpt)),
    ]


def minimum_routing_frames(config: Any) -> int | None:
    """Return the shortest block-aligned run that can retrieve one history frame."""
    block_size = int(config.num_frame_per_block)
    local_window = int(config.model_kwargs.local_attn_size)
    memory_size = int(config.model_kwargs.memory_size)
    recent_exclude = int(config.model_kwargs.recent_exclude)
    if local_window == -1 or memory_size <= 0:
        return None

    first_retrieval_block = (
        (local_window + recent_exclude + 1 + block_size - 1) // block_size
    ) * block_size
    return first_retrieval_block + block_size


def validate_inputs(
    args: argparse.Namespace, config: Any, *, require_models: bool
) -> dict[str, Any]:
    frames = int(config.num_output_frames)
    block_size = int(config.num_frame_per_block)
    local_window = int(config.model_kwargs.local_attn_size)
    if frames <= 0 or frames % block_size:
        raise ValueError(
            f"frames must be positive and divisible by block size {block_size}: {frames}"
        )
    if args.mode == "tethermem":
        minimum_frames = minimum_routing_frames(config)
        if minimum_frames is not None and frames < minimum_frames:
            recent_exclude = int(config.model_kwargs.recent_exclude)
            raise ValueError(
                "TetherMem needs enough block-aligned frames to evict local state "
                "and leave one eligible history frame after recent exclusion; "
                f"use at least {minimum_frames} latent frames "
                f"(local_window={local_window}, recent_exclude={recent_exclude}, "
                f"block_size={block_size})"
            )
    if not args.validate_only and not args.prompt:
        raise ValueError("--prompt is required for generation")
    if args.mode == "tethermem" and args.mask is None:
        raise ValueError("--mask is required in tethermem mode")

    mask_shape = None
    if args.mask is not None:
        from tethermem.masks import load_patch_mask

        mask = load_patch_mask(args.mask, minimum_frames=frames)
        mask_shape = list(mask.shape)

    model_paths = required_model_paths(config)
    missing = [str(path) for path in model_paths if not path.is_file()]
    if require_models and missing:
        formatted = "\n".join(f"  - {path}" for path in missing)
        raise FileNotFoundError(f"required model files are missing:\n{formatted}")
    return {
        "mode": args.mode,
        "frames": frames,
        "block_size": block_size,
        "local_attention_size": local_window,
        "mask_shape": mask_shape,
        "model_files_present": len(model_paths) - len(missing),
        "model_files_expected": len(model_paths),
        "missing_model_files": missing,
    }


def source_revision() -> str | None:
    result = subprocess.run(
        ["git", "-C", str(REPO_ROOT), "rev-parse", "HEAD"],
        check=False,
        capture_output=True,
        text=True,
    )
    return result.stdout.strip() if result.returncode == 0 else None


def runtime_record(args: argparse.Namespace, config: Any, torch: Any) -> dict[str, Any]:
    return {
        "status": "starting",
        "executable": sys.executable,
        "python_version": sys.version.split()[0],
        "torch_version": torch.__version__,
        "torch_cuda_version": torch.version.cuda,
        "cudnn_version": torch.backends.cudnn.version(),
        "cudnn_enabled": bool(torch.backends.cudnn.enabled),
        "hostname": socket.gethostname(),
        "visible_gpu_count": torch.cuda.device_count(),
        "visible_gpu_names": [
            torch.cuda.get_device_name(index) for index in range(torch.cuda.device_count())
        ],
        "config": str(args.config),
        "generator_checkpoint": str(config.generator_ckpt),
        "retrieval_ae_checkpoint": str(config.model_kwargs.ae_ckpt),
        "output": str(args.output),
        "mode": args.mode,
        "seed": args.seed,
        "latent_frames": int(config.num_output_frames),
        "source_revision": source_revision(),
    }


def cuda_preflight(torch: Any, device: Any) -> None:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; full TetherMem inference is GPU-only")
    if device.type != "cuda":
        raise ValueError("TetherMem inference currently supports CUDA devices only")
    torch.cuda.set_device(device)
    if torch.backends.cudnn.enabled:
        raise RuntimeError("cuDNN must be disabled before model construction")

    convolution = torch.nn.Conv3d(2, 2, kernel_size=3, padding=1).to(
        device=device, dtype=torch.bfloat16
    )
    sample = torch.randn((1, 2, 3, 8, 8), device=device, dtype=torch.bfloat16)
    output = convolution(sample)
    if output.shape != sample.shape or not torch.isfinite(output).all():
        raise RuntimeError("bf16 CUDA Conv3d preflight produced an invalid result")
    del output, sample, convolution
    torch.cuda.empty_cache()


def load_generator_checkpoint(pipeline: Any, config: Any, torch: Any) -> None:
    checkpoint = torch.load(
        str(config.generator_ckpt), map_location="cpu", weights_only=False
    )
    if "generator" in checkpoint or "generator_ema" in checkpoint:
        key = "generator_ema" if bool(config.use_ema) else "generator"
        if key not in checkpoint:
            raise KeyError(f"checkpoint does not contain requested state: {key}")
        state = checkpoint[key]
    elif "model" in checkpoint:
        state = checkpoint["model"]
    else:
        state = checkpoint
    if bool(config.use_ema):
        state = {
            name.replace("_fsdp_wrapped_module.", ""): value
            for name, value in state.items()
        }
        missing, unexpected = pipeline.generator.load_state_dict(state, strict=False)
        if missing or unexpected:
            print(
                f"EMA load: {len(missing)} missing keys, {len(unexpected)} unexpected keys"
            )
    else:
        pipeline.generator.load_state_dict(state)


def materialize_video(video: Any, destination: Path, fps: float) -> None:
    import torch
    from torchvision.io import write_video

    destination.parent.mkdir(parents=True, exist_ok=True)
    file_descriptor, temporary_name = tempfile.mkstemp(
        prefix=f".{destination.stem}.", suffix=".mp4", dir=destination.parent
    )
    os.close(file_descriptor)
    temporary = Path(temporary_name)
    try:
        pixels = (video.clamp(0, 1) * 255.0).to(torch.uint8).cpu()
        # PyAV expects an AVRational-like value; passing argparse's float can
        # become numpy.float64 inside torchvision and fail at stream creation.
        rate = Fraction(str(fps)).limit_denominator(1000)
        write_video(str(temporary), pixels, fps=rate)
        if temporary.stat().st_size == 0:
            raise RuntimeError("video encoder produced an empty file")
        os.replace(temporary, destination)
    finally:
        temporary.unlink(missing_ok=True)


def decode_probe(path: Path) -> dict[str, Any]:
    import av

    with av.open(str(path), mode="r") as container:
        stream = container.streams.video[0]
        first_frame = next(container.decode(stream), None)
        if first_frame is None:
            raise RuntimeError("generated media contains no decodable video frame")
        return {
            "width": int(first_frame.width),
            "height": int(first_frame.height),
            "average_rate": str(stream.average_rate),
        }


def run_generation(args: argparse.Namespace, config: Any) -> dict[str, Any]:
    import torch

    torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = False
    device = torch.device(args.device)
    cuda_preflight(torch, device)
    torch.set_grad_enabled(False)

    from einops import rearrange

    from pipeline import CausalInferencePipeline
    from tethermem.routing import apply_selective_patch
    from utils.memory import DynamicSwapInstaller, get_cuda_free_memory_gb
    from utils.misc import set_seed
    from wan.modules.causal_model_latentmem import CausalWanSelfAttention

    print(f"CUDA preflight passed; free VRAM: {get_cuda_free_memory_gb(device):.1f} GiB")
    set_seed(args.seed)
    pipeline = CausalInferencePipeline(config, device=device)
    load_generator_checkpoint(pipeline, config, torch)
    pipeline = pipeline.to(dtype=torch.bfloat16)
    low_memory = not args.no_low_memory
    if low_memory:
        DynamicSwapInstaller.install_model(pipeline.text_encoder, device=device)
    pipeline.generator.to(device=device)
    pipeline.vae.to(device=device)

    apply_selective_patch(pipeline, config)
    attention_modules = [
        module
        for module in pipeline.generator.model.modules()
        if isinstance(module, CausalWanSelfAttention)
    ]
    if not attention_modules:
        raise RuntimeError("no CausalWanSelfAttention modules were patched")

    noise = torch.randn(
        (1, int(config.num_output_frames), 16, 60, 104),
        device=device,
        dtype=torch.bfloat16,
    )
    started = time.monotonic()
    video, latents = pipeline.inference(
        noise=noise,
        text_prompts=[args.prompt],
        return_latents=True,
        low_memory=low_memory,
        profile=False,
        retrieval_policy="topk",
        retrieval_policy_kwargs=None,
    )
    runtime_seconds = time.monotonic() - started
    hook_counts = [
        int(getattr(module, "_selective_call_count", 0))
        for module in attention_modules
    ]
    if args.mode == "tethermem" and min(hook_counts) <= 0:
        raise RuntimeError("generation completed without exercising TetherMem routing")

    pixel_video = rearrange(video[0], "t c h w -> t h w c")
    materialize_video(pixel_video, args.output, args.fps)
    probe = decode_probe(args.output)
    pipeline.vae.model.clear_cache()

    return {
        "runtime_seconds": runtime_seconds,
        "latent_frames": int(latents.shape[1]),
        "retrieval_events": len(pipeline.memory_indices_log),
        "patched_attention_modules": len(attention_modules),
        "routing_hook_min": min(hook_counts),
        "routing_hook_max": max(hook_counts),
        "decode": probe,
    }


def main() -> int:
    args = build_parser().parse_args()
    config = load_config(args)
    validation = validate_inputs(
        args,
        config,
        require_models=(args.require_models or not args.validate_only),
    )
    if args.validate_only:
        print(
            "Configuration valid: "
            f"mode={validation['mode']} frames={validation['frames']} "
            f"models={validation['model_files_present']}/{validation['model_files_expected']}"
        )
        if validation["missing_model_files"]:
            print("Model files are not required in validate-only mode unless --require-models is set.")
        return 0

    if args.output.exists() and not args.overwrite:
        raise FileExistsError(
            f"output already exists: {args.output}; pass --overwrite to replace it"
        )

    import torch

    torch.backends.cudnn.enabled = False
    run_path = args.output.with_suffix(".run.json")
    done_path = args.output.with_suffix(".done.json")
    record = runtime_record(args, config, torch)
    atomic_json_dump(record, run_path)
    try:
        result = run_generation(args, config)
    except Exception as exc:
        status = (
            "post_processing_failed"
            if args.output.is_file() and args.output.stat().st_size > 0
            else "failed"
        )
        record.update({"status": status, "error_type": type(exc).__name__, "error": str(exc)})
        atomic_json_dump(record, run_path)
        raise

    record.update({"status": "completed", **result})
    atomic_json_dump(record, run_path)
    atomic_json_dump(
        {
            "status": "completed",
            "output": str(args.output),
            "config": str(args.config),
            "mode": args.mode,
            "seed": args.seed,
            "latent_frames": result["latent_frames"],
            "decode": result["decode"],
            "routing_hook_min": result["routing_hook_min"],
            "routing_hook_max": result["routing_hook_max"],
        },
        done_path,
    )
    print(f"Generated video: {args.output}")
    print(f"Completion metadata: {done_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
