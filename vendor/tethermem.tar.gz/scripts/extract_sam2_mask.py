#!/usr/bin/env python3
"""Track a boxed subject with SAM2 and emit a TetherMem patch mask."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tethermem.masks import dilate_patch_mask, validate_patch_mask
from utils.io import atomic_json_dump, atomic_numpy_save


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Generate a [decoded video frame,30,52] subject mask from an explicit "
            "box prompt. Automatic box selection is intentionally not provided."
        )
    )
    parser.add_argument("--video", type=Path, required=True)
    parser.add_argument(
        "--box", type=float, nargs=4, metavar=("X0", "Y0", "X1", "Y1"), required=True
    )
    parser.add_argument("--sam2-repo", type=Path, required=True)
    parser.add_argument("--sam2-config", required=True)
    parser.add_argument("--sam2-checkpoint", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--raw-output", type=Path, help="Optional undilated [T,30,52] output"
    )
    parser.add_argument(
        "--pixel-output", type=Path, help="Optional full-resolution binary mask"
    )
    parser.add_argument("--metadata", type=Path)
    parser.add_argument("--overlay-dir", type=Path)
    parser.add_argument(
        "--extra-prompts",
        type=Path,
        help="JSON list of [frame_index,[x0,y0,x1,y1]] re-anchor boxes",
    )
    parser.add_argument("--dilate-radius", type=int, default=2)
    parser.add_argument("--anchor-weight", type=float, default=1.0)
    parser.add_argument("--target-average", type=float, default=0.25)
    parser.add_argument(
        "--no-hold-empty",
        action="store_true",
        help="Fail instead of filling tracker dropouts with the last valid mask",
    )
    return parser


def probe_video(path: Path) -> tuple[int, int, int, float]:
    import cv2

    capture = cv2.VideoCapture(str(path))
    if not capture.isOpened():
        raise RuntimeError(f"unable to open video: {path}")
    frame_count = int(capture.get(cv2.CAP_PROP_FRAME_COUNT))
    width = int(capture.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(capture.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = float(capture.get(cv2.CAP_PROP_FPS))
    capture.release()
    if frame_count <= 0 or width <= 0 or height <= 0:
        raise RuntimeError(f"video metadata is invalid: {path}")
    return frame_count, height, width, fps


def load_extra_prompts(path: Path | None) -> list[tuple[int, np.ndarray]]:
    if path is None:
        return []
    with path.open(encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, list):
        raise ValueError("extra-prompts JSON must be a list")
    prompts: list[tuple[int, np.ndarray]] = []
    for item in payload:
        if not isinstance(item, list) or len(item) != 2 or len(item[1]) != 4:
            raise ValueError(f"invalid extra prompt entry: {item!r}")
        prompts.append((int(item[0]), np.asarray(item[1], dtype=np.float32)))
    return prompts


def fill_empty_masks(masks: np.ndarray, minimum_area: int = 1) -> tuple[int, int]:
    held_forward = 0
    held_backward = 0
    last_good = None
    for index in range(masks.shape[0]):
        if int(masks[index].sum()) >= minimum_area:
            last_good = masks[index].copy()
        elif last_good is not None:
            masks[index] = last_good
            held_forward += 1

    first_good = next(
        (masks[index].copy() for index in range(masks.shape[0]) if masks[index].sum()),
        None,
    )
    if first_good is not None:
        for index in range(masks.shape[0]):
            if masks[index].sum() == 0:
                masks[index] = first_good
                held_backward += 1
    return held_forward, held_backward


def consecutive_iou(masks: np.ndarray) -> float:
    values: list[float] = []
    for previous, current in zip(masks[:-1], masks[1:]):
        intersection = np.logical_and(previous, current).sum()
        union = np.logical_or(previous, current).sum()
        values.append(float(intersection / union) if union else 0.0)
    return float(np.mean(values)) if values else 0.0


def write_overlays(
    video: Path, masks: np.ndarray, box: np.ndarray, destination: Path
) -> None:
    import cv2

    destination.mkdir(parents=True, exist_ok=True)
    samples = {
        "early": masks.shape[0] // 8,
        "middle": masks.shape[0] // 2,
        "late": masks.shape[0] * 7 // 8,
    }
    capture = cv2.VideoCapture(str(video))
    for label, frame_index in samples.items():
        capture.set(cv2.CAP_PROP_POS_FRAMES, frame_index)
        ok, frame = capture.read()
        if not ok:
            continue
        overlay = (frame.astype(np.float32) * 0.6).astype(np.uint8)
        overlay[masks[frame_index] > 0] = (0, 255, 0)
        x0, y0, x1, y1 = (int(value) for value in box)
        cv2.rectangle(overlay, (x0, y0), (x1, y1), (0, 0, 255), 2)
        cv2.imwrite(str(destination / f"{label}.png"), overlay)
    capture.release()


def main() -> int:
    args = build_parser().parse_args()
    if not args.video.is_file():
        raise FileNotFoundError(f"video not found: {args.video}")
    if not args.sam2_repo.is_dir():
        raise FileNotFoundError(f"SAM2 repository not found: {args.sam2_repo}")
    if not args.sam2_checkpoint.is_file():
        raise FileNotFoundError(f"SAM2 checkpoint not found: {args.sam2_checkpoint}")

    frame_count, height, width, fps = probe_video(args.video)
    box = np.asarray(args.box, dtype=np.float32)
    x0, y0, x1, y1 = box
    if not (0 <= x0 < x1 <= width and 0 <= y0 < y1 <= height):
        raise ValueError(f"box {box.tolist()} is outside the {width}x{height} video")

    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("SAM2 mask extraction requires a CUDA GPU")
    torch.backends.cudnn.enabled = False
    torch.backends.cudnn.benchmark = False

    sam2_path = str(args.sam2_repo.resolve())
    if sam2_path not in sys.path:
        sys.path.insert(0, sam2_path)
    from sam2.build_sam import build_sam2_video_predictor

    predictor = build_sam2_video_predictor(
        config_file=args.sam2_config,
        ckpt_path=str(args.sam2_checkpoint),
        device="cuda",
    )
    state = predictor.init_state(
        video_path=str(args.video),
        async_loading_frames=False,
        offload_video_to_cpu=True,
    )
    predictor.add_new_points_or_box(state, frame_idx=0, obj_id=1, box=box)
    for frame_index, extra_box in load_extra_prompts(args.extra_prompts):
        if not 0 <= frame_index < frame_count:
            raise ValueError(f"extra prompt frame is out of range: {frame_index}")
        predictor.add_new_points_or_box(
            state, frame_idx=frame_index, obj_id=1, box=extra_box
        )

    pixel_masks = np.zeros((frame_count, height, width), dtype=np.uint8)
    for frame_index, _object_ids, logits in predictor.propagate_in_video(state):
        mask = (logits[0] > 0).detach().cpu().numpy().squeeze()
        if mask.shape != (height, width):
            import cv2

            mask = cv2.resize(
                mask.astype(np.uint8),
                (width, height),
                interpolation=cv2.INTER_NEAREST,
            )
        pixel_masks[int(frame_index)] = (mask > 0).astype(np.uint8)
    predictor.reset_state(state)

    tracked = pixel_masks.reshape(frame_count, -1).any(axis=1)
    if not tracked.any():
        raise RuntimeError("SAM2 did not produce a non-empty mask")
    held_forward = held_backward = 0
    if not tracked.all():
        if args.no_hold_empty:
            missing = int((~tracked).sum())
            raise RuntimeError(f"SAM2 returned {missing} empty frames")
        held_forward, held_backward = fill_empty_masks(pixel_masks)

    import cv2

    patch_masks = np.zeros((frame_count, 30, 52), dtype=np.uint8)
    for frame_index, mask in enumerate(pixel_masks):
        reduced = cv2.resize(
            mask.astype(np.float32), (52, 30), interpolation=cv2.INTER_AREA
        )
        patch_masks[frame_index] = (reduced > 0.5).astype(np.uint8)
    patch_masks = validate_patch_mask(patch_masks)
    repaired, dilation = dilate_patch_mask(
        patch_masks,
        radius=args.dilate_radius,
        anchor_weight=args.anchor_weight,
        target_average=args.target_average,
    )

    atomic_numpy_save(repaired, args.output)
    if args.raw_output:
        atomic_numpy_save(patch_masks, args.raw_output)
    if args.pixel_output:
        atomic_numpy_save(pixel_masks, args.pixel_output)
    if args.overlay_dir:
        write_overlays(args.video, pixel_masks, box, args.overlay_dir)

    areas = pixel_masks.reshape(frame_count, -1).mean(axis=1)
    metadata_path = args.metadata or args.output.with_suffix(".json")
    atomic_json_dump(
        {
            "video": str(args.video),
            "decoded_frames": frame_count,
            "height": height,
            "width": width,
            "fps": fps,
            "box_prompt": box.tolist(),
            "patch_mask_shape": list(repaired.shape),
            "temporal_indexing": "one mask row per decoded video frame",
            "mean_pixel_area_fraction": float(areas.mean()),
            "consecutive_mask_iou": consecutive_iou(pixel_masks),
            "sam2_tracked_fraction": float(tracked.mean()),
            "held_forward": held_forward,
            "held_backward": held_backward,
            "dilation": dilation.as_dict(),
        },
        metadata_path,
    )
    print(f"Wrote TetherMem mask: {args.output}")
    print(f"Metadata: {metadata_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
