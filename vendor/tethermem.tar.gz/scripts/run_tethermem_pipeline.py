#!/usr/bin/env python3
"""Run the public reference -> mask -> TetherMem pipeline in one command."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Sequence

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from utils.io import atomic_json_dump


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Generate a LongLive-RAG reference, automatically select a SAM2 subject, "
            "track its mask, and generate TetherMem."
        )
    )
    parser.add_argument("--prompt", help="Text prompt for the generated video")
    parser.add_argument("--model-root", type=Path, default=Path("models"))
    parser.add_argument("--sam2-repo", type=Path, default=Path("external/sam2"))
    parser.add_argument(
        "--sam2-config", default="configs/sam2/sam2_hiera_l.yaml"
    )
    parser.add_argument("--sam2-checkpoint", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("outputs/auto_pipeline"))
    parser.add_argument("--frames", type=int, default=120)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--fps", type=float, default=16.0)
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--sam2-device", default="cuda")
    parser.add_argument(
        "--box",
        type=float,
        nargs=4,
        metavar=("X0", "Y0", "X1", "Y1"),
        help="Optional explicit first-frame box; otherwise use SAM2 automatic selection",
    )
    parser.add_argument(
        "--extra-prompts",
        type=Path,
        help="Optional JSON re-anchor boxes passed to SAM2 tracking",
    )
    parser.add_argument("--points-per-side", type=int, default=16)
    parser.add_argument("--points-per-batch", type=int, default=64)
    parser.add_argument("--min-tracked-fraction", type=float, default=0.95)
    parser.add_argument("--max-held-fraction", type=float, default=0.05)
    parser.add_argument("--no-low-memory", action="store_true")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument(
        "--validate-only",
        action="store_true",
        help="Validate the pipeline plan without loading models or running stages",
    )
    return parser


def _relative_or_absolute(path: Path) -> str:
    return str(path)


def _stage(
    label: str,
    command: Sequence[str],
    *,
    model_root: Path,
) -> None:
    environment = os.environ.copy()
    environment["MODEL_ROOT"] = str(model_root)
    # The external SAM2 checkout is an input-only dependency. Avoid creating
    # bytecode beside it during an automated run.
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    print(f"[pipeline] {label}")
    subprocess.run(
        list(command),
        cwd=REPO_ROOT,
        env=environment,
        check=True,
    )


def _paths(output_dir: Path) -> dict[str, Path]:
    return {
        "reference": output_dir / "reference_longlive_rag.mp4",
        "box": output_dir / "subject_box.json",
        "box_overlay": output_dir / "auto_subject_overlay.png",
        "patch": output_dir / "subject_patch.npy",
        "raw_patch": output_dir / "subject_patch_raw.npy",
        "pixel_mask": output_dir / "subject_pixel_mask.npy",
        "mask_metadata": output_dir / "subject_mask.json",
        "overlay_dir": output_dir / "sam2_overlays",
        "tethermem": output_dir / "tethermem.mp4",
        "pair": output_dir / "pair_diagnostics.json",
        "summary": output_dir / "pipeline_summary.json",
    }


def _validate_args(args: argparse.Namespace) -> None:
    if not args.validate_only and not args.prompt:
        raise ValueError("--prompt is required unless --validate-only is used")
    if args.frames <= 0 or args.frames % 3:
        raise ValueError("--frames must be positive and divisible by 3")
    if args.frames < 21:
        raise ValueError("TetherMem requires at least 21 latent frames")
    if not 0.0 <= args.min_tracked_fraction <= 1.0:
        raise ValueError("--min-tracked-fraction must be between 0 and 1")
    if not 0.0 <= args.max_held_fraction <= 1.0:
        raise ValueError("--max-held-fraction must be between 0 and 1")
    if args.box is not None:
        x0, y0, x1, y1 = args.box
        if not (x0 < x1 and y0 < y1):
            raise ValueError("--box must satisfy x0<x1 and y0<y1")
    if args.extra_prompts is not None and not args.extra_prompts.is_file():
        raise FileNotFoundError(f"extra prompts file not found: {args.extra_prompts}")


def _write_explicit_box(path: Path, box: Sequence[float]) -> None:
    atomic_json_dump(
        {
            "selection_method": "explicit_box",
            "class_agnostic": False,
            "frame_index": 0,
            "bbox_xyxy": [float(value) for value in box],
        },
        path,
    )


def _read_json(path: Path) -> dict[str, Any]:
    with path.open(encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object: {path}")
    return payload


def _mask_quality_gate(args: argparse.Namespace, metadata_path: Path) -> dict[str, Any]:
    metadata = _read_json(metadata_path)
    tracked = float(metadata.get("sam2_tracked_fraction", 0.0))
    held = int(metadata.get("held_forward", 0)) + int(
        metadata.get("held_backward", 0)
    )
    decoded = int(metadata.get("decoded_frames", 0))
    held_fraction = held / decoded if decoded else 1.0
    if tracked < args.min_tracked_fraction or held_fraction > args.max_held_fraction:
        raise RuntimeError(
            "SAM2 mask quality gate failed: "
            f"tracked_fraction={tracked:.4f} (minimum {args.min_tracked_fraction:.4f}), "
            f"held_fraction={held_fraction:.4f} (maximum {args.max_held_fraction:.4f}); "
            f"inspect {metadata_path} and its overlay directory"
        )
    return {
        "tracked_fraction": tracked,
        "held_frames": held,
        "held_fraction": held_fraction,
        "consecutive_iou": float(metadata.get("consecutive_mask_iou", 0.0)),
        "patch_mask_shape": metadata.get("patch_mask_shape"),
    }


def main() -> int:
    args = build_parser().parse_args()
    _validate_args(args)
    paths = _paths(args.output_dir)
    model_root = args.model_root
    checkpoint = args.sam2_checkpoint or (model_root / "sam2" / "sam2_hiera_large.pt")

    if args.validate_only:
        mode = "explicit box" if args.box is not None else "SAM2 automatic box"
        print(
            "Pipeline configuration valid: "
            f"frames={args.frames} seed={args.seed} box_mode={mode} "
            f"output_dir={args.output_dir}"
        )
        return 0

    args.output_dir.mkdir(parents=True, exist_ok=True)
    protected_outputs = [paths[key] for key in ("reference", "tethermem", "summary")]
    existing = [path for path in protected_outputs if path.exists()]
    if existing and not args.overwrite:
        formatted = ", ".join(str(path) for path in existing)
        raise FileExistsError(
            f"pipeline outputs already exist: {formatted}; pass --overwrite to replace"
        )

    python = sys.executable
    base = [
        python,
        "scripts/inference_tethermem.py",
        "--model-root",
        _relative_or_absolute(model_root),
        "--prompt",
        args.prompt,
        "--frames",
        str(args.frames),
        "--seed",
        str(args.seed),
        "--device",
        args.device,
        "--fps",
        str(args.fps),
    ]
    if args.no_low_memory:
        base.append("--no-low-memory")

    reference_command = base + [
        "--mode",
        "baseline",
        "--output",
        _relative_or_absolute(paths["reference"]),
    ]
    if args.overwrite:
        reference_command.append("--overwrite")
    _stage("LongLive-RAG reference generation", reference_command, model_root=model_root)

    if args.box is None:
        _stage(
            "SAM2 automatic first-frame subject selection",
            [
                python,
                "scripts/auto_subject_box.py",
                "--video",
                _relative_or_absolute(paths["reference"]),
                "--sam2-repo",
                _relative_or_absolute(args.sam2_repo),
                "--sam2-config",
                args.sam2_config,
                "--sam2-checkpoint",
                _relative_or_absolute(checkpoint),
                "--output",
                _relative_or_absolute(paths["box"]),
                "--overlay",
                _relative_or_absolute(paths["box_overlay"]),
                "--points-per-side",
                str(args.points_per_side),
                "--points-per-batch",
                str(args.points_per_batch),
                "--device",
                args.sam2_device,
            ],
            model_root=model_root,
        )
    else:
        _write_explicit_box(paths["box"], args.box)

    box_report = _read_json(paths["box"])
    box = box_report.get("selected", {}).get("bbox_xyxy") or box_report.get(
        "bbox_xyxy"
    )
    if not isinstance(box, list) or len(box) != 4:
        raise ValueError(f"automatic box report has no bbox_xyxy: {paths['box']}")

    mask_command = [
        python,
        "scripts/extract_sam2_mask.py",
        "--video",
        _relative_or_absolute(paths["reference"]),
        "--box",
        *(str(float(value)) for value in box),
        "--sam2-repo",
        _relative_or_absolute(args.sam2_repo),
        "--sam2-config",
        args.sam2_config,
        "--sam2-checkpoint",
        _relative_or_absolute(checkpoint),
        "--output",
        _relative_or_absolute(paths["patch"]),
        "--raw-output",
        _relative_or_absolute(paths["raw_patch"]),
        "--pixel-output",
        _relative_or_absolute(paths["pixel_mask"]),
        "--metadata",
        _relative_or_absolute(paths["mask_metadata"]),
        "--overlay-dir",
        _relative_or_absolute(paths["overlay_dir"]),
    ]
    if args.extra_prompts is not None:
        mask_command.extend(["--extra-prompts", _relative_or_absolute(args.extra_prompts)])
    _stage("SAM2 video tracking and mask extraction", mask_command, model_root=model_root)
    mask_quality = _mask_quality_gate(args, paths["mask_metadata"])

    tethermem_command = base + [
        "--mode",
        "tethermem",
        "--mask",
        _relative_or_absolute(paths["patch"]),
        "--output",
        _relative_or_absolute(paths["tethermem"]),
    ]
    if args.overwrite:
        tethermem_command.append("--overwrite")
    _stage("TetherMem generation", tethermem_command, model_root=model_root)

    _stage(
        "reference/TetherMem technical diagnostics",
        [
            python,
            "scripts/evaluate_pair.py",
            "--baseline",
            _relative_or_absolute(paths["reference"]),
            "--tethermem",
            _relative_or_absolute(paths["tethermem"]),
            "--output",
            _relative_or_absolute(paths["pair"]),
        ],
        model_root=model_root,
    )

    atomic_json_dump(
        {
            "status": "completed",
            "prompt": args.prompt,
            "seed": args.seed,
            "latent_frames": args.frames,
            "selection_method": box_report.get("selection_method"),
            "selected_box_xyxy": box,
            "mask_quality": mask_quality,
            "reference": str(paths["reference"]),
            "mask": str(paths["patch"]),
            "tethermem": str(paths["tethermem"]),
            "pair_diagnostics": str(paths["pair"]),
        },
        paths["summary"],
    )
    print(f"Pipeline completed: {paths['tethermem']}")
    print(f"Pipeline summary: {paths['summary']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
