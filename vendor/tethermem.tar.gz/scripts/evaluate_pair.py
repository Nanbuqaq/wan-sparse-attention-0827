#!/usr/bin/env python3
"""Technical paired-video diagnostics; not a perceptual quality metric."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import av
import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from utils.io import atomic_json_dump


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Check paired video structure and report simple pixel diagnostics."
    )
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--tethermem", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    return parser


def video_frames(path: Path):
    container = av.open(str(path), mode="r")
    stream = container.streams.video[0]
    try:
        for frame in container.decode(stream):
            yield frame.to_ndarray(format="rgb24"), stream
    finally:
        container.close()


def main() -> int:
    args = build_parser().parse_args()
    for path in (args.baseline, args.tethermem):
        if not path.is_file():
            raise FileNotFoundError(f"video not found: {path}")

    baseline_iterator = iter(video_frames(args.baseline))
    tethermem_iterator = iter(video_frames(args.tethermem))
    frame_count = 0
    absolute_difference_sum = 0.0
    baseline_motion_sum = 0.0
    tethermem_motion_sum = 0.0
    previous_baseline = None
    previous_tethermem = None
    shape = None
    baseline_rate = tethermem_rate = None

    while True:
        baseline_item = next(baseline_iterator, None)
        tethermem_item = next(tethermem_iterator, None)
        if baseline_item is None or tethermem_item is None:
            if baseline_item is not None or tethermem_item is not None:
                raise ValueError("paired videos have different frame counts")
            break
        baseline, baseline_stream = baseline_item
        tethermem, tethermem_stream = tethermem_item
        if baseline.shape != tethermem.shape:
            raise ValueError(
                f"paired frame shapes differ: {baseline.shape} vs {tethermem.shape}"
            )
        shape = baseline.shape
        baseline_rate = str(baseline_stream.average_rate)
        tethermem_rate = str(tethermem_stream.average_rate)
        baseline_float = baseline.astype(np.float32) / 255.0
        tethermem_float = tethermem.astype(np.float32) / 255.0
        absolute_difference_sum += float(
            np.abs(baseline_float - tethermem_float).mean()
        )
        if previous_baseline is not None:
            baseline_motion_sum += float(
                np.abs(baseline_float - previous_baseline).mean()
            )
            tethermem_motion_sum += float(
                np.abs(tethermem_float - previous_tethermem).mean()
            )
        previous_baseline = baseline_float
        previous_tethermem = tethermem_float
        frame_count += 1

    if frame_count == 0 or shape is None:
        raise RuntimeError("paired videos contain no decoded frames")
    motion_denominator = max(frame_count - 1, 1)
    report = {
        "report_type": "technical_pair_diagnostics",
        "perceptual_quality_claim": False,
        "baseline": str(args.baseline),
        "tethermem": str(args.tethermem),
        "decoded_frames": frame_count,
        "frame_shape_hwc": list(shape),
        "baseline_average_rate": baseline_rate,
        "tethermem_average_rate": tethermem_rate,
        "paired_mean_absolute_pixel_difference": absolute_difference_sum
        / frame_count,
        "baseline_mean_frame_difference": baseline_motion_sum / motion_denominator,
        "tethermem_mean_frame_difference": tethermem_motion_sum / motion_denominator,
    }
    atomic_json_dump(report, args.output)
    print(f"Wrote paired technical diagnostics: {args.output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
