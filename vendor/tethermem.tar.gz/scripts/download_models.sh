#!/usr/bin/env bash
set -euo pipefail

repo_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
model_root="${MODEL_ROOT:-${repo_root}/models}"
dry_run="${DRY_RUN:-0}"

wan_revision="${WAN_REVISION:-37ec512624d61f7aa208f7ea8140a131f93afc9a}"
longlive_revision="${LONGLIVE_RAG_REVISION:-aaafe325726e0204ada9d1f019356fde97e08c2e}"

wan_dir="${model_root}/wan_models/Wan2.1-T2V-1.3B"
longlive_dir="${model_root}/longlive_rag"
longlive_assets=(
    "checkpoints/causal_forcing.pt"
    "checkpoints/ae_latent_mem.pt"
)

if [[ "${dry_run}" == "1" ]]; then
    printf 'hf download %q --revision %q --local-dir %q\n' \
        'Wan-AI/Wan2.1-T2V-1.3B' "${wan_revision}" "${wan_dir}"
    printf 'hf download %q --revision %q --local-dir %q --include %q %q\n' \
        'qixinhu11/LongLive-RAG' "${longlive_revision}" "${longlive_dir}" \
        "${longlive_assets[0]}" "${longlive_assets[1]}"
    exit 0
fi

if ! command -v hf >/dev/null 2>&1; then
    echo "The Hugging Face CLI ('hf') is required. Install requirements first." >&2
    exit 1
fi

mkdir -p "${wan_dir}" "${longlive_dir}"

hf download Wan-AI/Wan2.1-T2V-1.3B \
    --revision "${wan_revision}" \
    --local-dir "${wan_dir}"

hf download qixinhu11/LongLive-RAG \
    --revision "${longlive_revision}" \
    --local-dir "${longlive_dir}" \
    --include "${longlive_assets[@]}"

echo "TetherMem inference models downloaded under ${model_root}"
