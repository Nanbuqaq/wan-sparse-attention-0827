#!/usr/bin/env python3
"""Create a deterministic synthetic mask for code-level smoke checks only."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from tethermem.masks import dilate_patch_mask, validate_patch_mask
from utils.io import atomic_json_dump, atomic_numpy_save


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create a synthetic [T,30,52] mask; not a scientific fixture."
    )
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--frames", type=int, default=30)
    parser.add_argument("--kind", choices=("static", "moving"), default="moving")
    parser.add_argument("--dilate-radius", type=int, default=2)
    parser.add_argument("--target-average", type=float, default=0.25)
    return parser


def make_mask(frames: int, kind: str) -> np.ndarray:
    if frames <= 0:
        raise ValueError("frames must be positive")
    mask = np.zeros((frames, 30, 52), dtype=np.uint8)
    box_height, box_width = 8, 10
    for frame_index in range(frames):
        if kind == "moving":
            span = 52 - box_width - 8
            left = 4 + (frame_index * span // max(frames - 1, 1))
        else:
            left = (52 - box_width) // 2
        top = (30 - box_height) // 2
        mask[frame_index, top : top + box_height, left : left + box_width] = 1
    return validate_patch_mask(mask)


def main() -> int:
    args = build_parser().parse_args()
    raw = make_mask(args.frames, args.kind)
    mask, stats = dilate_patch_mask(
        raw,
        radius=args.dilate_radius,
        target_average=args.target_average,
    )
    atomic_numpy_save(mask, args.output)
    metadata_path = args.output.with_suffix(".json")
    atomic_json_dump(
        {
            "fixture_type": "synthetic_code_smoke_only",
            "scientific_reproduction": False,
            "kind": args.kind,
            "shape": list(mask.shape),
            "dilation": stats.as_dict(),
        },
        metadata_path,
    )
    print(f"Wrote synthetic smoke mask: {args.output}")
    print(f"Metadata: {metadata_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
