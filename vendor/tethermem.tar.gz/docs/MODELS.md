# Models and public assets

## Confirmed backbone

TetherMem uses `Wan-AI/Wan2.1-T2V-1.3B`. This was verified from the model
construction path in `utils/wan_wrapper.py`, the canonical TetherMem config,
the local generation driver, and the public LongLive-RAG configs. The choice is
not inferred from a directory name.

The default TetherMem run uses:

- Wan base model: `Wan-AI/Wan2.1-T2V-1.3B`
- AR generator: `checkpoints/causal_forcing.pt`
- retrieval encoder: `checkpoints/ae_latent_mem.pt`
- no LoRA adapter

The `longlive_base.pt` and `longlive_lora.pt` pair belongs to the LongLive
backbone used by latent-corpus generation and upstream comparisons. It is not
loaded by `configs/tethermem.yaml`.

## Pinned public revisions

The release audit checked these public revisions on 2026-08-23:

| Resource | Revision | License reported upstream |
| --- | --- | --- |
| `qixinhu11/LongLive-RAG` GitHub | `973884a3cd3ad4b314c3d4ab42274c52e7a0b22a` | Apache-2.0 |
| `qixinhu11/LongLive-RAG` Hugging Face | `aaafe325726e0204ada9d1f019356fde97e08c2e` | Apache-2.0 |
| `Wan-AI/Wan2.1-T2V-1.3B` Hugging Face | `37ec512624d61f7aa208f7ea8140a131f93afc9a` | Apache-2.0 |
| `NVlabs/LongLive` GitHub | `7860ad9685686bc3edfd407eb4d12579ca47d689` | Apache-2.0 |
| `Wan-Video/Wan2.1` GitHub | `9737cba9c1c3c4d04b33fcad41c111989865d315` | Apache-2.0 |
| `facebookresearch/sam2` GitHub | `2b90b9f5ceec907a1c18123530e92e794ad901a4` | Apache-2.0 |
| SAM2 Hiera-L checkpoint | upstream `072824/sam2_hiera_large.pt` asset | Apache-2.0 |

The downloader pins the two Hugging Face revisions by default. Override
`WAN_REVISION` or `LONGLIVE_RAG_REVISION` only when intentionally testing a
different public snapshot, and use a different model directory for that run.

## LongLive-RAG inference assets

`scripts/download_models.sh` downloads only the two LongLive-RAG files used by
the standard TetherMem inference path:

```text
checkpoints/causal_forcing.pt
checkpoints/ae_latent_mem.pt
```

Their sizes are:

| File | Bytes | Approximate GiB |
| --- | ---: | ---: |
| `causal_forcing.pt` | 5,676,282,643 | 5.29 |
| `ae_latent_mem.pt` | 362,866,531 | 0.34 |

Together they are approximately 6.039 GB decimal (5.62 GiB).

The same Hugging Face repository also publishes `self_forcing.pt`,
`longlive_base.pt`, `longlive_lora.pt`, prompt lists, and 20 toy latent files.
Those assets support upstream comparisons, latent-corpus generation, or AE
development; they are not loaded by the standard TetherMem pipeline. The full
optional resource set is approximately 20.697 GB decimal (19.276 GiB).

## Wan asset set

The entire `Wan-AI/Wan2.1-T2V-1.3B` repository is downloaded because the local
LongLive-RAG wrapper reads the transformer config/weights, Wan VAE, UMT5
encoder, and tokenizer files. Representative large files are:

| File | Bytes | Approximate GiB |
| --- | ---: | ---: |
| `diffusion_pytorch_model.safetensors` | 5,676,070,424 | 5.29 |
| `models_t5_umt5-xxl-enc-bf16.pth` | 11,361,920,418 | 10.58 |
| `Wan2.1_VAE.pth` | 507,609,880 | 0.47 |

The complete Wan repository is approximately 17.574 GB decimal (16.367 GiB).

## SAM2 asset set

The complete reference-to-mask-to-TetherMem workflow additionally uses the
public SAM2 Hiera-L source config and checkpoint:

```text
external/sam2/sam2/configs/sam2/sam2_hiera_l.yaml
${MODEL_ROOT}/sam2/sam2_hiera_large.pt
```

The checkpoint is 897,952,466 bytes (approximately 0.836 GiB) and comes from
the public upstream URL dated 2024-07-28. It matches the original
`configs/sam2/sam2_hiera_l.yaml` interface. The similarly named
`sam2.1_hiera_large.pt` is a different checkpoint/config generation and must
not be substituted without intentionally changing the integration.

## Disk planning

- Default TetherMem payload: approximately 23.6 GB decimal for Wan plus the
  causal generator and retrieval AE.
- Default full-pipeline payload: approximately 24.5 GB decimal for Wan, the
  causal generator, retrieval AE, and SAM2 Hiera-L checkpoint.
- Recommended free space for the standard full pipeline: at least 30 GB when
  assets are written directly into the local model directories, or about 45 GB
  when keeping a separate Hugging Face cache.
- Optional full upstream asset set: approximately 39.2 GB decimal including
  Wan and SAM2, before any generated latent corpus.

These are public model files and data, but they are still excluded from Git.

## Download

From the repository root:

```bash
DRY_RUN=1 bash scripts/download_models.sh
bash scripts/download_models.sh

DRY_RUN=1 bash scripts/download_sam2.sh
bash scripts/download_sam2.sh
```

The effective commands are equivalent to:

```bash
hf download Wan-AI/Wan2.1-T2V-1.3B \
  --revision 37ec512624d61f7aa208f7ea8140a131f93afc9a \
  --local-dir "${MODEL_ROOT:-models}/wan_models/Wan2.1-T2V-1.3B"

hf download qixinhu11/LongLive-RAG \
  --revision aaafe325726e0204ada9d1f019356fde97e08c2e \
  --local-dir "${MODEL_ROOT:-models}/longlive_rag" \
  --include \
    "checkpoints/causal_forcing.pt" \
    "checkpoints/ae_latent_mem.pt"

mkdir -p "${MODEL_ROOT:-models}/sam2"
curl --fail --location \
  --output "${MODEL_ROOT:-models}/sam2/sam2_hiera_large.pt.part" \
  https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_large.pt
mv "${MODEL_ROOT:-models}/sam2/sam2_hiera_large.pt.part" \
  "${MODEL_ROOT:-models}/sam2/sam2_hiera_large.pt"
```

To inspect upstream-only checkpoints, prompts, and toy latents as well, run a
separate optional download:

```bash
hf download qixinhu11/LongLive-RAG \
  --revision aaafe325726e0204ada9d1f019356fde97e08c2e \
  --local-dir "${MODEL_ROOT:-models}/longlive_rag" \
  --include "checkpoints/*" "toydatasets/*"
```

The scripts do not accept a credential argument, write credentials to disk, or
print them. Authentication, if required by a user's Hugging Face setup, is
owned by the installed `hf` client and its runtime environment. The SAM2
checkpoint is public and downloaded to a `.part` file before an atomic rename.

## Upstream comparison

The public LongLive-RAG README and `inference.sh` expose a three-backbone by
two-memory-mode grid. Its `causal_forcing_latentmem.yaml` uses the same Wan
1.3B model, causal checkpoint, retrieval AE, local window 12, sink 1, memory 6,
and recency exclusion 5 used by TetherMem.

The local source incorporated into this repository is materially modified from
the checked GitHub revision. Differences include the causal inference pipeline,
latent-memory model, AE training/corpus code, VAE code, and inference controls
required by the TetherMem experiments. Replacing these files with current
upstream LongLive-RAG is not a supported update and would not reproduce the
same execution path.

## License responsibility

The checked LongLive-RAG, LongLive, Wan source repositories and the two checked
Hugging Face model cards identify Apache-2.0. Always re-read the model cards at
the downloaded revision before redistribution or deployment. This repository's
`LICENSE` covers the source release; it does not turn downloaded model files
into files tracked by this Git repository.
