"""Portable repository and model path helpers."""

from __future__ import annotations

import os
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[1]


def model_root() -> Path:
    """Return MODEL_ROOT, defaulting to the ignored repository-local models/ dir."""
    configured = os.environ.get("MODEL_ROOT")
    return Path(configured).expanduser() if configured else REPO_ROOT / "models"


def wan_model_dir(model_name: str = "Wan2.1-T2V-1.3B") -> Path:
    return model_root() / "wan_models" / model_name


def longlive_rag_dir() -> Path:
    return model_root() / "longlive_rag"
