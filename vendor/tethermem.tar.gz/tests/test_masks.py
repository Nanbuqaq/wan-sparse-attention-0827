from __future__ import annotations

import numpy as np
import pytest

from tethermem.masks import (
    budget_rows,
    dilate_patch_mask,
    solve_context_weight,
    validate_patch_mask,
)


def test_context_weight_hits_budget_when_not_clamped() -> None:
    subject_fraction = 0.1
    context = solve_context_weight(subject_fraction, 1.0, 0.25)
    effective = subject_fraction + (1.0 - subject_fraction) * context
    assert effective == pytest.approx(0.25)


def test_context_weight_clamps_for_oversized_subject() -> None:
    assert solve_context_weight(0.4, 1.0, 0.25) == 0.0


def test_validate_patch_mask_rejects_wrong_spatial_shape() -> None:
    with pytest.raises(ValueError, match="spatial shape"):
        validate_patch_mask(np.zeros((4, 29, 52), dtype=np.uint8))


def test_dilation_backs_off_to_respect_reachable_budget() -> None:
    mask = np.zeros((3, 30, 52), dtype=np.uint8)
    mask[:, 12:18, 23:29] = 1
    repaired, stats = dilate_patch_mask(mask, radius=5, target_average=0.08)
    assert repaired.shape == mask.shape
    assert stats.max_fraction_after <= 0.08 + 1e-9
    assert max(stats.radii_used) < 5


def test_budget_rows_distinguish_clamped_frames() -> None:
    mask = np.zeros((2, 30, 52), dtype=np.uint8)
    mask[0, :3] = 1
    mask[1, :15] = 1
    rows = budget_rows(mask)
    assert rows[0]["clamped"] == 0
    assert rows[0]["effective_average"] == pytest.approx(0.25)
    assert rows[1]["clamped"] == 1
