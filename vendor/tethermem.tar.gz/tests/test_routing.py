from __future__ import annotations

import numpy as np
import torch

from tethermem.routing import (
    _split_query_sdpa,
    build_memory_subject_mask,
    solve_context_weight,
)


def test_per_frame_memory_mask_uses_retrieved_frame_labels() -> None:
    masks = np.zeros((3, 2, 2), dtype=np.uint8)
    masks[0, 0, 0] = 1
    masks[1, 0, 1] = 1
    masks[2, 1, 0] = 1
    query = masks[2]
    result = build_memory_subject_mask(
        masks,
        [[0, 2]],
        2,
        query,
        per_frame=True,
    )
    expected = np.concatenate([masks[0].reshape(-1), masks[2].reshape(-1)]).astype(
        bool
    )
    np.testing.assert_array_equal(result, expected)


def test_tiled_memory_mask_uses_current_query_labels() -> None:
    masks = np.zeros((3, 2, 2), dtype=np.uint8)
    query = np.array([[1, 0], [0, 1]], dtype=np.uint8)
    result = build_memory_subject_mask(
        masks,
        [[0, 1, 2]],
        3,
        query,
        per_frame=False,
    )
    np.testing.assert_array_equal(result, np.tile(query.reshape(-1), 3).astype(bool))


def test_split_query_sdpa_has_stable_shape_and_finite_output() -> None:
    torch.manual_seed(0)
    query = torch.randn(1, 4, 2, 3)
    key = torch.randn(1, 5, 2, 3)
    value = torch.randn(1, 5, 2, 3)
    subject_queries = np.array([True, False, True, False])
    subject_bias = torch.tensor([0.0, -0.5, 0.0, -0.5, 0.0])
    background_bias = torch.tensor([-0.5, 0.0, -0.5, 0.0, 0.0])
    output = _split_query_sdpa(
        query,
        key,
        value,
        subject_queries,
        subject_bias,
        background_bias,
        torch.float32,
    )
    assert output.shape == query.shape
    assert torch.isfinite(output).all()


def test_frozen_and_public_budget_solver_agree() -> None:
    assert solve_context_weight(0.1, 1.0, 0.25) == 1.0 / 6.0
