from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import numpy as np

from scripts.auto_subject_box import rank_candidates


REPO_ROOT = Path(__file__).resolve().parents[1]


def _rectangle(height: int, width: int, x0: int, y0: int, x1: int, y1: int) -> np.ndarray:
    mask = np.zeros((height, width), dtype=np.uint8)
    mask[y0:y1, x0:x1] = 1
    return mask


def test_auto_box_prefers_center_subject_over_edge_region() -> None:
    height, width = 100, 160
    annotations = [
        {
            "segmentation": _rectangle(height, width, 45, 20, 115, 85),
            "predicted_iou": 0.9,
            "stability_score": 0.9,
        },
        {
            "segmentation": _rectangle(height, width, 0, 70, 160, 100),
            "predicted_iou": 0.99,
            "stability_score": 0.99,
        },
    ]
    ranked = rank_candidates(annotations, (height, width))
    assert ranked[0]["index"] == 0
    assert ranked[0]["contains_center"] is True
    assert ranked[0]["touches_edge"] is False


def test_pipeline_validate_only_needs_no_models() -> None:
    result = subprocess.run(
        [
            sys.executable,
            "scripts/run_tethermem_pipeline.py",
            "--validate-only",
            "--prompt",
            "A centered red teapot.",
            "--frames",
            "21",
            "--output-dir",
            "outputs/auto_pipeline_test",
        ],
        cwd=REPO_ROOT,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "SAM2 automatic box" in result.stdout
