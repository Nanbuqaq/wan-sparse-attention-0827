from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import numpy as np

from utils.paths import model_root, wan_model_dir


REPO_ROOT = Path(__file__).resolve().parents[1]


def test_model_root_honors_environment(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("MODEL_ROOT", str(tmp_path))
    assert model_root() == tmp_path
    assert wan_model_dir() == tmp_path / "wan_models" / "Wan2.1-T2V-1.3B"


def test_validate_only_cli_needs_no_models(tmp_path: Path) -> None:
    mask_path = tmp_path / "mask.npy"
    np.save(mask_path, np.ones((21, 30, 52), dtype=np.uint8), allow_pickle=False)
    environment = os.environ.copy()
    environment["MODEL_ROOT"] = str(tmp_path / "models")
    result = subprocess.run(
        [
            sys.executable,
            "scripts/inference_tethermem.py",
            "--validate-only",
            "--mode",
            "tethermem",
            "--frames",
            "21",
            "--mask",
            str(mask_path),
        ],
        cwd=REPO_ROOT,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "Configuration valid" in result.stdout


def test_baseline_mode_needs_no_subject_mask(tmp_path: Path) -> None:
    environment = os.environ.copy()
    environment["MODEL_ROOT"] = str(tmp_path / "models")
    result = subprocess.run(
        [
            sys.executable,
            "scripts/inference_tethermem.py",
            "--validate-only",
            "--mode",
            "baseline",
            "--frames",
            "21",
        ],
        cwd=REPO_ROOT,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "mode=baseline" in result.stdout


def test_validate_only_rejects_smoke_without_eligible_history(tmp_path: Path) -> None:
    mask_path = tmp_path / "short-mask.npy"
    np.save(mask_path, np.ones((18, 30, 52), dtype=np.uint8), allow_pickle=False)
    environment = os.environ.copy()
    environment["MODEL_ROOT"] = str(tmp_path / "models")
    result = subprocess.run(
        [
            sys.executable,
            "scripts/inference_tethermem.py",
            "--validate-only",
            "--mode",
            "tethermem",
            "--frames",
            "18",
            "--mask",
            str(mask_path),
        ],
        cwd=REPO_ROOT,
        env=environment,
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode != 0
    assert "use at least 21 latent frames" in result.stderr


def test_download_script_dry_run_is_noninteractive(tmp_path: Path) -> None:
    environment = os.environ.copy()
    environment["MODEL_ROOT"] = str(tmp_path / "models")
    environment["DRY_RUN"] = "1"
    result = subprocess.run(
        ["bash", "scripts/download_models.sh"],
        cwd=REPO_ROOT,
        env=environment,
        check=True,
        capture_output=True,
        text=True,
    )
    assert "Wan-AI/Wan2.1-T2V-1.3B" in result.stdout
    assert "qixinhu11/LongLive-RAG" in result.stdout
    assert "checkpoints/causal_forcing.pt" in result.stdout
    assert "checkpoints/ae_latent_mem.pt" in result.stdout
    assert "toydatasets" not in result.stdout
    assert "--token" not in result.stdout


def test_sam2_download_script_dry_run_uses_matching_checkpoint(tmp_path: Path) -> None:
    environment = os.environ.copy()
    environment["MODEL_ROOT"] = str(tmp_path / "models")
    environment["DRY_RUN"] = "1"
    result = subprocess.run(
        ["bash", "scripts/download_sam2.sh"],
        cwd=REPO_ROOT,
        env=environment,
        check=True,
        capture_output=True,
        text=True,
    )
    assert "072824/sam2_hiera_large.pt" in result.stdout
    assert str(tmp_path / "models" / "sam2" / "sam2_hiera_large.pt") in result.stdout
    assert "token" not in result.stdout.lower()
