from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PAGE = ROOT / "page"
INDEX = PAGE / "index.html"


def test_project_page_references_existing_local_assets() -> None:
    html = INDEX.read_text(encoding="utf-8")
    references = re.findall(r'(?:src|poster|href)="([^"]+)"', html)

    local_references = {
        reference.split("#", 1)[0]
        for reference in references
        if reference
        and not reference.startswith(("#", "http://", "https://", "mailto:"))
    }

    missing = [reference for reference in sorted(local_references) if not (PAGE / reference).is_file()]
    assert not missing, f"Missing project-page assets: {missing}"


def test_project_page_release_surface() -> None:
    html = INDEX.read_text(encoding="utf-8")

    assert 'rel="canonical" href="https://lichen1015.github.io/tethermem/"' in html
    assert 'href="https://github.com/lichen1015/tethermem"' in html
    assert 'href="https://arxiv.org/pdf/2608.26902"' in html
    assert '<a class="navPaper" href="https://arxiv.org/pdf/2608.26902"' in html
    assert ">Read Paper</a>" in html
    assert '<div class="navlinks"><a href="#demo">Demo</a><a href="#results">Results</a><a href="#problem">Problem</a><a href="#method">Method</a><a href="#evidence">Evidence</a></div>' in html
    assert "arXiv · 2608.26902" not in html
    assert ">arXiv ↗</a>" in html
    assert "eprint = {2608.26902}" in html
    assert "arXiv · coming soon" not in html
    assert html.count("<video controls") == 4
    assert (
        'id="tab-p04" aria-selected="true" aria-controls="demo-p04"'
        in html
    )
    assert (
        'class="demo isActive" id="demo-p04" role="tabpanel"'
        in html
    )
    assert "01 · TRANSFER" in html
    assert html.index("Tokyo woman") < html.index("Flower market")

    for video in (PAGE / "assets" / "videos").glob("*.mp4"):
        assert video.stat().st_size > 1_000_000
