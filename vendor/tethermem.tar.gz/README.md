<p align="center">
  <img src="assets/tethermem-banner.png" alt="TetherMem: Tether the Subject, Release the Scene" width="100%" />
</p>

<h1 align="center">TetherMem</h1>

<p align="center">
  <strong>Tether the Subject, Release the Scene</strong><br />
  Query-Aware Memory Routing for Long-Horizon Autoregressive Video Generation
</p>

<p align="center">
  <strong>Chen Li<sup>1,2</sup></strong> &nbsp;·&nbsp;
  <strong>Peng Zhang<sup>2</sup></strong> &nbsp;·&nbsp;
  <strong>Hanyu Zhou<sup>1</sup></strong> &nbsp;·&nbsp;
  <strong>Jialong Zuo<sup>1</sup></strong> &nbsp;·&nbsp;
  <strong>Fei Wang<sup>2</sup></strong> &nbsp;·&nbsp;
  <strong>Daiguo Zhou<sup>2</sup></strong> &nbsp;·&nbsp;
  <strong>Nong Sang<sup>1</sup></strong> &nbsp;·&nbsp;
  <strong>Changxin Gao<sup>1,*</sup></strong>
</p>

<p align="center">
  <sup>1</sup>Huazhong University of Science and Technology &nbsp;&nbsp;
  <sup>2</sup>MiLM Plus, Xiaomi Inc. &nbsp;&nbsp;
  <sup>*</sup>Corresponding author
</p>

<p align="center">
  <a href="https://lichen1015.github.io/tethermem/"><img src="https://img.shields.io/badge/Project-Page-2786ff?style=flat-square&labelColor=06101a" alt="Project page" /></a>
  <a href="https://arxiv.org/abs/2608.26902"><img src="https://img.shields.io/badge/arXiv-2608.26902-b31b1b?style=flat-square" alt="arXiv:2608.26902" /></a>
  <img src="https://img.shields.io/badge/Training--free-Inference--time-40dfff?style=flat-square&labelColor=06101a" alt="Training-free inference" />
  <img src="https://img.shields.io/badge/Backbone-Wan2.1--T2V--1.3B-8b73ff?style=flat-square&labelColor=06101a" alt="Wan2.1 T2V 1.3B" />
  <a href="LICENSE"><img src="https://img.shields.io/badge/License-MIT-2ee6a6?style=flat-square&labelColor=06101a" alt="MIT license" /></a>
</p>

<p align="center">
  <a href="#paper-overview">Paper overview</a> ·
  <a href="#reproduce-tethermem">Reproduce</a> ·
  <a href="#required-models">Models</a> ·
  <a href="#outputs">Outputs</a> ·
  <a href="https://lichen1015.github.io/tethermem/#demo">Video demos</a> ·
  <a href="#citation">Citation</a>
</p>

TetherMem is a **training-free, inference-time memory router** for long-horizon
autoregressive video generation. Subject queries retain access to identity-bearing
history, while scene queries favor recent background states. The video generator,
retrieval encoder, and all released checkpoints remain frozen: there is no
TetherMem fine-tuning, LoRA, optimizer, or backward pass.

| Frozen generator | Query-aware memory | Public reproduction |
| :---: | :---: | :---: |
| Wan2.1-T2V-1.3B + LongLive-RAG | Subject and scene queries read history differently | LongLive-RAG reference → SAM2 track → TetherMem |

## Paper overview

<p align="center">
  <img src="assets/tethermem-method-overview.png" alt="Paper Figure 2a: end-to-end TetherMem architecture" width="100%" />
</p>

**End-to-end TetherMem.** A time-aligned subject track and retrieved historical
tokens meet inside normalized memory routing. Regional routing preserves
identity-bearing subject evidence; recency routing lets scene queries release
stale backgrounds and follow newer scene states.

<p align="center">
  <img src="assets/tethermem-memory-routing.png" alt="Paper Figure 2b: frame-level selection versus query-conditioned TetherMem routing" width="100%" />
</p>

**Why query-level routing matters.** Prior methods decide which frames survive for
every query. TetherMem keeps the same retrieved memory budget but routes subject
and scene queries differently inside attention.

The public implementation is **TetherMem**. It keeps LongLive-RAG available as
the matched reference mode and applies TetherMem routing by default.

### Results at a glance

| Evidence | TetherMem result |
| --- | ---: |
| Blinded pairwise judgments | 2,400 |
| Overall expected preference | **0.780** |
| Scene-progression expected preference | **0.769** |
| Identity expected preference | 0.600 |

See the [project page](https://lichen1015.github.io/tethermem/) for the complete
Table 1, matched 30-second videos, paper figures, and qualitative trajectories.

## Reproduce TetherMem

The standard public path reproduces a matched LongLive-RAG reference and
TetherMem result from one prompt and seed. It automatically selects and
tracks the main subject with SAM2, checks the track, and writes both videos plus
diagnostics.

### System requirements

| Component | Validated / recommended setting |
| --- | --- |
| Operating system | Linux |
| Python | 3.10 |
| CUDA | 12.4 |
| PyTorch / torchvision | 2.6.0 / 0.21.0 |
| GPU | CUDA GPU with 48 GB VRAM recommended |
| System memory | 64 GB recommended |
| Model storage | ~24.5 GB; keep at least 30 GB free |

### 1. Clone the repository

```bash
git clone https://github.com/lichen1015/tethermem.git
cd tethermem
```

If your GitHub account is configured for SSH, use
`git clone git@github.com:lichen1015/tethermem.git` instead.

### 2. Create the environment

```bash
python3.10 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install torch==2.6.0 torchvision==0.21.0 \
  --index-url https://download.pytorch.org/whl/cu124
python -m pip install -r requirements.txt
```

Install SAM2 for automatic subject selection and tracking:

```bash
mkdir -p external
git clone https://github.com/facebookresearch/sam2.git external/sam2
git -C external/sam2 checkout 2b90b9f5ceec907a1c18123530e92e794ad901a4
python -m pip install -e external/sam2
```

### 3. Download the required models

Inspect the exact download commands without transferring weights:

```bash
DRY_RUN=1 bash scripts/download_models.sh
DRY_RUN=1 bash scripts/download_sam2.sh
```

Download the standard inference assets:

```bash
bash scripts/download_models.sh
bash scripts/download_sam2.sh
```

Set `MODEL_ROOT=/path/to/models` before these commands to use a shared model
directory. The same value must be present when running inference.

## Required models

| Component | Required asset | Download | Place under |
| --- | --- | --- | --- |
| Video foundation model | Wan2.1-T2V-1.3B | [Hugging Face repository](https://huggingface.co/Wan-AI/Wan2.1-T2V-1.3B) | `models/wan_models/Wan2.1-T2V-1.3B/` |
| Frozen AR generator | `causal_forcing.pt` | [Download checkpoint](https://huggingface.co/qixinhu11/LongLive-RAG/resolve/main/checkpoints/causal_forcing.pt?download=true) | `models/longlive_rag/checkpoints/causal_forcing.pt` |
| Retrieval encoder | `ae_latent_mem.pt` | [Download checkpoint](https://huggingface.co/qixinhu11/LongLive-RAG/resolve/main/checkpoints/ae_latent_mem.pt?download=true) | `models/longlive_rag/checkpoints/ae_latent_mem.pt` |
| Subject tracking | `sam2_hiera_large.pt` | [Download checkpoint](https://dl.fbaipublicfiles.com/segment_anything_2/072824/sam2_hiera_large.pt) | `models/sam2/sam2_hiera_large.pt` |

Expected layout:

```text
models/
├── wan_models/Wan2.1-T2V-1.3B/
├── longlive_rag/checkpoints/
│   ├── causal_forcing.pt
│   └── ae_latent_mem.pt
└── sam2/sam2_hiera_large.pt
```

Only these inference assets are downloaded. The standard path does not use
`self_forcing.pt`, `longlive_base.pt`, `longlive_lora.pt`, prompt lists, or the
LongLive-RAG toy latent dataset. Sizes and licenses are documented in
[`docs/MODELS.md`](docs/MODELS.md).

### 4. Validate the command before loading models

```bash
python scripts/run_tethermem_pipeline.py \
  --validate-only \
  --frames 21 \
  --output-dir outputs/plan_check
```

After downloading, verify that the generator, tokenizer, checkpoints, and
retrieval encoder are present:

```bash
python scripts/inference_tethermem.py \
  --validate-only \
  --require-models \
  --mode baseline \
  --frames 21
```

### 5. Run the complete pipeline

```bash
CUDA_VISIBLE_DEVICES=0 python scripts/run_tethermem_pipeline.py \
  --prompt "A red ceramic teapot remains centered while the camera moves slowly." \
  --frames 120 \
  --seed 0 \
  --output-dir outputs/teapot
```

The command executes:

```text
LongLive-RAG reference
  → automatic first-frame subject selection
  → SAM2 video tracking and mask-quality check
  → TetherMem with the same prompt and seed
  → matched diagnostics
```

For an off-center subject or a scene with several plausible subjects, provide
the intended first-frame box while keeping the rest of the pipeline unchanged:

```bash
CUDA_VISIBLE_DEVICES=0 python scripts/run_tethermem_pipeline.py \
  --prompt "A cyclist passes a red bus in a city square." \
  --frames 120 \
  --seed 0 \
  --box 180 70 520 430 \
  --output-dir outputs/cyclist
```

## Outputs

| Output | Description |
| --- | --- |
| `reference_longlive_rag.mp4` | matched LongLive-RAG reference |
| `tethermem.mp4` | TetherMem result |
| `auto_subject_overlay.png` | automatically selected first-frame subject |
| `sam2_overlays/` | early, middle, and late tracking previews |
| `subject_patch.npy` | patch-space subject mask consumed by TetherMem |
| `subject_mask.json` | tracking and mask statistics |
| `pair_diagnostics.json` | matched technical diagnostics |
| `pipeline_summary.json` | commands, runtime state, status, and artifact paths |

### Run the tests

```bash
python -m pip install -r requirements-dev.txt
python -m pytest
```

## Acknowledgements

We thank the authors and maintainers of
[LongLive-RAG](https://github.com/qixinhu11/LongLive-RAG),
[LongLive](https://github.com/NVlabs/LongLive),
[Causal-Forcing](https://github.com/thu-ml/Causal-Forcing),
[Wan2.1](https://github.com/Wan-Video/Wan2.1), and
[SAM2](https://github.com/facebookresearch/sam2) for releasing the code, models,
and research foundations that make this project possible. TetherMem is built on
these contributions.

## License

TetherMem's original contributions are released under the
[MIT License](LICENSE). Third-party-derived source and downloaded models remain
subject to their upstream licenses; see
[`THIRD_PARTY_NOTICES.md`](THIRD_PARTY_NOTICES.md).

## Citation

If TetherMem is useful in your work, please cite the 2026 arXiv preprint.

```bibtex
@article{li2026tethermem,
  title  = {Tether the Subject, Release the Scene: Query-Aware Memory Routing for Long-Horizon Autoregressive Video Generation},
  author = {Li, Chen and Zhang, Peng and Zhou, Hanyu and Zuo, Jialong and Wang, Fei and Zhou, Daiguo and Sang, Nong and Gao, Changxin},
  year   = {2026},
  eprint = {2608.26902},
  archivePrefix = {arXiv},
  primaryClass = {cs.CV},
  url    = {https://arxiv.org/abs/2608.26902}
}
```
