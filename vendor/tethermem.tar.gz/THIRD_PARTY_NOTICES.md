# Third-party notices

TetherMem's original contributions are distributed under the MIT License in
`LICENSE`. This repository also contains modified source derived from several
open research projects. Those
Apache-2.0-derived portions remain subject to the terms in
`THIRD_PARTY_LICENSES/Apache-2.0.txt`. The following notice is informational
and does not replace that license text or notices retained in individual
source files.

## LongLive-RAG

- Project: `https://github.com/qixinhu11/LongLive-RAG`
- Checked source revision: `973884a3cd3ad4b314c3d4ab42274c52e7a0b22a`
- Authors: Qixin Hu, Shuai Yang, Wei Huang, Song Han, Yukang Chen, and
  contributors
- License reported by the checked repository: Apache-2.0

The `ae/`, `pipeline/`, `utils/`, `wan/`, corpus-generation code, and baseline
configs originate from a locally modified LongLive-RAG source snapshot. The
local snapshot differs from the public revision and is retained because the
TetherMem experiments depend on its latent-memory extensions.

## LongLive

- Project: `https://github.com/NVlabs/LongLive`
- Checked source revision: `7860ad9685686bc3edfd407eb4d12579ca47d689`
- Copyright: NVIDIA Corporation and affiliates, plus contributors
- License reported by the checked repository: Apache-2.0

LongLive provides the autoregressive long-video lineage, attention-sink and
causal streaming foundations used by LongLive-RAG. NVIDIA notices are retained
in files such as `utils/lora_utils.py`.

## Wan2.1

- Project: `https://github.com/Wan-Video/Wan2.1`
- Checked source revision: `9737cba9c1c3c4d04b33fcad41c111989865d315`
- Model: `https://huggingface.co/Wan-AI/Wan2.1-T2V-1.3B`
- Checked model revision: `37ec512624d61f7aa208f7ea8140a131f93afc9a`
- Copyright: The Alibaba Wan Team Authors and contributors
- License reported by the checked source and model card: Apache-2.0

The `wan/` package is the model implementation used through the LongLive-RAG
wrapper. Wan weights are downloaded separately and are not part of this Git
repository.

## Self-Forcing and Causal-Forcing

- Self-Forcing: `https://github.com/guandeh17/Self-Forcing`
- Causal-Forcing: `https://github.com/thu-ml/Causal-Forcing`

LongLive-RAG attributes its causal inference and training recipe to these
projects. The source headers that identify adopted Self-Forcing code are
retained. Generator checkpoints are distributed by the LongLive-RAG model
repository and are not committed here.

## FramePack memory utilities

- Project: `https://github.com/lllyasviel/FramePack`
- License identified in `utils/memory.py`: Apache-2.0

The dynamic model swapping helper retains its source attribution and license
notice.

## SAM2

- Project: `https://github.com/facebookresearch/sam2`
- Source revision used by the audited local experiment checkout:
  `2b90b9f5ceec907a1c18123530e92e794ad901a4`
- Checkpoint: upstream 2024-07-28 `sam2_hiera_large.pt`
- License reported by the checked source and checkpoint documentation:
  Apache-2.0

SAM2 source, checkpoints, videos, box prompts, and generated masks are not
included. `scripts/extract_sam2_mask.py` is an integration entrypoint that
requires a separately installed SAM2 checkout. Users must review that checkout
and checkpoint license at the revision they install.

## Python dependencies

PyTorch, torchvision, Hugging Face Transformers, Diffusers, PEFT, NumPy,
OpenCV, PyAV, OmegaConf, and the other packages in `requirements*.txt` are
installed as external dependencies and are not vendored. Their own licenses
apply.

## Public model and dataset files

`qixinhu11/LongLive-RAG` supplies public generator checkpoints, the retrieval
AE, prompt text files, and toy latent tensors. `Wan-AI/Wan2.1-T2V-1.3B`
supplies the Wan model. Their file lists, revisions, and reported licenses are
documented in `docs/MODELS.md`. Downloaded assets remain outside Git.
