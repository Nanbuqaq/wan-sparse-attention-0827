"""Validation and budget-aware processing for TetherMem patch masks."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np


PATCH_HEIGHT = 30
PATCH_WIDTH = 52


def solve_context_weight(
    subject_fraction: float, anchor_weight: float, target_average: float
) -> float:
    """Solve the background weight while keeping the spatial mean on budget."""
    if not 0.0 <= subject_fraction <= 1.0:
        raise ValueError("subject_fraction must be in [0, 1]")
    if anchor_weight < 0.0 or target_average < 0.0:
        raise ValueError("weights must be non-negative")
    if 1.0 - subject_fraction > 1e-6:
        value = (
            target_average - subject_fraction * anchor_weight
        ) / (1.0 - subject_fraction)
    else:
        value = target_average
    return min(max(value, 0.0), 1.0)


def validate_patch_mask(
    mask: np.ndarray,
    *,
    minimum_frames: int | None = None,
    expected_hw: tuple[int, int] = (PATCH_HEIGHT, PATCH_WIDTH),
) -> np.ndarray:
    """Return a canonical uint8 binary mask or raise a precise shape error."""
    array = np.asarray(mask)
    if array.ndim != 3:
        raise ValueError(f"mask must have shape [T,H,W], got {array.shape}")
    if tuple(array.shape[1:]) != expected_hw:
        raise ValueError(
            f"mask spatial shape must be {expected_hw}, got {tuple(array.shape[1:])}"
        )
    if minimum_frames is not None and array.shape[0] < minimum_frames:
        raise ValueError(
            f"mask has {array.shape[0]} frames but inference needs {minimum_frames}"
        )
    if array.shape[0] == 0:
        raise ValueError("mask must contain at least one frame")
    if not np.isfinite(array).all():
        raise ValueError("mask contains non-finite values")
    return (array > 0).astype(np.uint8, copy=False)


def load_patch_mask(
    path: str | Path, *, minimum_frames: int | None = None
) -> np.ndarray:
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(f"mask file not found: {source}")
    return validate_patch_mask(
        np.load(source, allow_pickle=False), minimum_frames=minimum_frames
    )


def dilate_frame(mask: np.ndarray, radius: int) -> np.ndarray:
    """Binary square-kernel dilation implemented with NumPy only."""
    if radius < 0:
        raise ValueError("radius must be non-negative")
    source = np.asarray(mask, dtype=bool)
    if source.ndim != 2:
        raise ValueError(f"frame mask must be 2D, got {source.shape}")
    if radius == 0:
        return source.copy()
    padded = np.pad(source, radius, mode="constant", constant_values=False)
    result = np.zeros_like(source)
    height, width = source.shape
    for row_offset in range(2 * radius + 1):
        for col_offset in range(2 * radius + 1):
            result |= padded[
                row_offset : row_offset + height,
                col_offset : col_offset + width,
            ]
    return result


@dataclass(frozen=True)
class DilationStats:
    radius_default: int
    anchor_weight: float
    target_average: float
    mean_fraction_before: float
    max_fraction_before: float
    mean_fraction_after: float
    max_fraction_after: float
    clamped_fraction: float
    radii_used: tuple[int, ...]

    def as_dict(self) -> dict[str, object]:
        return {
            "radius_default": self.radius_default,
            "anchor_weight": self.anchor_weight,
            "target_average": self.target_average,
            "mean_fraction_before": self.mean_fraction_before,
            "max_fraction_before": self.max_fraction_before,
            "mean_fraction_after": self.mean_fraction_after,
            "max_fraction_after": self.max_fraction_after,
            "clamped_fraction": self.clamped_fraction,
            "radii_used": list(self.radii_used),
        }


def dilate_patch_mask(
    mask: np.ndarray,
    *,
    radius: int = 2,
    anchor_weight: float = 1.0,
    target_average: float = 0.25,
) -> tuple[np.ndarray, DilationStats]:
    """Dilate each frame, backing off the radius when it exceeds the budget."""
    patch = validate_patch_mask(mask)
    if radius < 0:
        raise ValueError("radius must be non-negative")
    if anchor_weight <= 0.0:
        raise ValueError("anchor_weight must be positive")
    ceiling = min(target_average / anchor_weight, 1.0)
    before = patch.reshape(patch.shape[0], -1).mean(axis=1)
    after_values: list[float] = []
    radii: list[int] = []
    output = np.zeros_like(patch)

    for index, frame in enumerate(patch):
        selected = frame.astype(bool)
        selected_radius = 0
        for candidate_radius in range(radius, -1, -1):
            candidate = dilate_frame(frame, candidate_radius)
            if candidate.mean() <= ceiling + 1e-9 or candidate_radius == 0:
                selected = candidate
                selected_radius = candidate_radius
                break
        output[index] = selected.astype(np.uint8)
        after_values.append(float(selected.mean()))
        radii.append(selected_radius)

    after = np.asarray(after_values, dtype=np.float64)
    stats = DilationStats(
        radius_default=radius,
        anchor_weight=float(anchor_weight),
        target_average=float(target_average),
        mean_fraction_before=float(before.mean()),
        max_fraction_before=float(before.max()),
        mean_fraction_after=float(after.mean()),
        max_fraction_after=float(after.max()),
        clamped_fraction=float((after * anchor_weight >= target_average - 1e-9).mean()),
        radii_used=tuple(radii),
    )
    return output, stats


def budget_rows(
    mask: np.ndarray, *, anchor_weight: float = 1.0, target_average: float = 0.25
) -> list[dict[str, float | int]]:
    patch = validate_patch_mask(mask)
    rows: list[dict[str, float | int]] = []
    for frame_index, frame in enumerate(patch):
        subject_fraction = float(frame.mean())
        context_weight = solve_context_weight(
            subject_fraction, anchor_weight, target_average
        )
        effective_average = (
            subject_fraction * anchor_weight
            + (1.0 - subject_fraction) * context_weight
        )
        rows.append(
            {
                "frame": frame_index,
                "subject_fraction": subject_fraction,
                "context_weight": context_weight,
                "effective_average": effective_average,
                "clamped": int(
                    context_weight <= 0.0 and subject_fraction > 1e-9
                ),
            }
        )
    return rows
