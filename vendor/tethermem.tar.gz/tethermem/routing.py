"""Query-conditioned TetherMem routing for LongLive-RAG attention.

The public implementation exposes two modes: ``baseline`` keeps the retrieved
memory attention unchanged, while ``tethermem`` applies regional and recency
routing to the same memory budget.
"""

import math
import numpy as np
import torch
import torch.nn.functional as F
from wan.modules.causal_model_latentmem import (
    CausalWanSelfAttention,
    block_relativistic_rope,
)
from wan.modules.attention import attention


def solve_context_weight(r, anchor_weight, target_avg):
    """
    Solve context_weight so that
        effective_avg = r*anchor_weight + (1-r)*context_weight == target_avg
    clamped to [0, 1].
    """
    if (1.0 - r) > 1e-6:
        ctx = (target_avg - r * anchor_weight) / (1.0 - r)
    else:
        ctx = target_avg
    return min(max(ctx, 0.0), 1.0)


def build_memory_subject_mask(
    masks,
    effective_indices_list,
    k_sel_eff,
    query_subject_mask,
    *,
    per_frame,
):
    """Build subject/background labels for retrieved memory tokens."""
    query_flat = query_subject_mask.reshape(-1).astype(bool)
    if not per_frame:
        return np.tile(query_flat, k_sel_eff)

    total_frames = masks.shape[0]
    per_frame_masks = []
    for batch_indices in effective_indices_list:
        for pool_index in batch_indices[:k_sel_eff]:
            clamped = min(max(int(pool_index), 0), total_frames - 1)
            per_frame_masks.append(masks[clamped].reshape(-1).astype(bool))
    if not per_frame_masks:
        return np.empty((0,), dtype=bool)
    return np.concatenate(per_frame_masks)


def _split_query_sdpa(roped_query, k_cat, v_cat, subj_q_mask_bool, bias_subj, bias_bg, v_dtype):
    """
    Split-query SDPA: run 2 SDPA calls on subject-query and bg-query subsets.

    Realizes 2D query x key bias via QUERY-SIDE SPLIT (2 SDPAs), NEVER a dense
    [S_q, S_k] mask. Each SDPA uses a per-key [K_total] additive bias broadcast
    over the query-subset.

    Args:
        roped_query: [B, S_q, N, d]
        k_cat:       [B, K_total, N, d]
        v_cat:       [B, K_total, N, d]
        subj_q_mask_bool: np.bool [S_q]  (subject-query tokens = True)
        bias_subj:   torch.float [K_total] per-key additive bias for subject queries (or None)
        bias_bg:     torch.float [K_total] per-key additive bias for bg queries (or None)
        v_dtype:     dtype for SDPA input casting

    Returns:
        x: [B, S_q, N, d]
    """
    import numpy as _np
    B, S_q, N, d = roped_query.shape
    device = roped_query.device

    q_idx_subj = _np.where(subj_q_mask_bool)[0]
    q_idx_bg = _np.where(~subj_q_mask_bool)[0]

    out = torch.zeros(B, S_q, N, d, device=device, dtype=roped_query.dtype)

    # Transpose for SDPA: [B, N, s, d]
    k_sdpa = k_cat.transpose(1, 2).to(dtype=v_dtype)
    v_sdpa = v_cat.transpose(1, 2).to(dtype=v_dtype)

    # --- Subject queries ---
    if len(q_idx_subj) > 0:
        q_idx_subj_t = torch.from_numpy(q_idx_subj).long().to(device)
        q_subj = roped_query[:, q_idx_subj_t].transpose(1, 2).to(dtype=v_dtype)  # [B, N, s_subj, d]
        if bias_subj is not None:
            bias_subj_4d = bias_subj.view(1, 1, 1, -1).to(dtype=v_dtype)
            out_subj = F.scaled_dot_product_attention(q_subj, k_sdpa, v_sdpa, attn_mask=bias_subj_4d)
        else:
            out_subj = F.scaled_dot_product_attention(q_subj, k_sdpa, v_sdpa)
        out[:, q_idx_subj_t] = out_subj.transpose(1, 2).contiguous().to(dtype=roped_query.dtype)

    # --- Bg queries ---
    if len(q_idx_bg) > 0:
        q_idx_bg_t = torch.from_numpy(q_idx_bg).long().to(device)
        q_bg = roped_query[:, q_idx_bg_t].transpose(1, 2).to(dtype=v_dtype)  # [B, N, s_bg, d]
        if bias_bg is not None:
            bias_bg_4d = bias_bg.view(1, 1, 1, -1).to(dtype=v_dtype)
            out_bg = F.scaled_dot_product_attention(q_bg, k_sdpa, v_sdpa, attn_mask=bias_bg_4d)
        else:
            out_bg = F.scaled_dot_product_attention(q_bg, k_sdpa, v_sdpa)
        out[:, q_idx_bg_t] = out_bg.transpose(1, 2).contiguous().to(dtype=roped_query.dtype)

    return out


def _compute_routing_diagnostics(
    roped_query, k_cat, bias_subj, bias_bg,
    subj_q_mask_bool, mem_subj_keymask,
    sink_tokens, mem_token_count, local_token_count,
    frame_seqlen, num_new_frames,
    device, head_dim, routing_mode, ctx_w, r,
):
    """
    Read-only routing-mechanism diagnostics.  Computes 8 attention-mass fractions
    from the POST-bias softmax A_post = softmax(Q.K_cat/root(d) + bias) on the
    FULL k_cat.  Chunked over query tokens to bound memory.

    Destinations: {sink, subj-mem, bg-mem, local}  (4 bins)
    Query groups: {subject-query, bg-query}          (2 groups)
    -> 8 fractions = 2 x 4.  Sum over all 4 destinations = 1.0 per query group.

    Returns a dict of per-metric scalars, or None if no subject queries.
    """
    with torch.no_grad():
        K_total = k_cat.shape[1]
        n_heads = k_cat.shape[2]
        d = head_dim
        scale = d ** 0.5

        subj_q = subj_q_mask_bool
        sq_idx = np.where(subj_q)[0]
        bg_idx = np.where(~subj_q)[0]

        mem_start = sink_tokens
        mem_end = sink_tokens + mem_token_count
        local_start = mem_end

        # Destination slices / index arrays
        sink_slice = slice(0, sink_tokens)
        subj_mem_indices = np.where(mem_subj_keymask)[0] + mem_start
        bg_mem_indices = np.where(~mem_subj_keymask)[0] + mem_start
        local_slice = slice(local_start, K_total)

        Q_all = roped_query[0].float()  # [S_q, n, d]
        Kf = k_cat[0].float()           # [K_total, n, d]

        results = {}

        for group_name, q_idx, bias_tensor_ref in [
            ("subj_q", sq_idx, bias_subj),
            ("bg_q", bg_idx, bias_bg),
        ]:
            n_q = len(q_idx)
            if n_q == 0:
                for dest in ["sink", "subj_mem", "bg_mem", "local"]:
                    results[f"{group_name}_to_{dest}"] = 0.0
                continue

            chunk_size = 128
            mass_sink = 0.0
            mass_subj_mem = 0.0
            mass_bg_mem = 0.0
            mass_local = 0.0
            mass_entropy = 0.0  # entropy of A_post over K_total, per (query,head)

            q_idx_t = torch.from_numpy(q_idx).long().to(device)

            for c_start in range(0, n_q, chunk_size):
                c_end = min(c_start + chunk_size, n_q)
                c_idx = q_idx_t[c_start:c_end]
                Qc = Q_all[c_idx]  # [chunk, n, d]

                logits = torch.einsum("qhd,khd->qhk", Qc, Kf) / scale

                if bias_tensor_ref is not None:
                    bias_3d = bias_tensor_ref.view(1, 1, -1).to(device=device, dtype=torch.float32)
                    logits_post = logits + bias_3d
                else:
                    logits_post = logits

                A_post = torch.softmax(logits_post, dim=-1)  # [chunk, n, K_total]

                # entropy of attention over K_total (per query,head); high = diffuse/uncertain
                _ap_safe = A_post.clamp(min=1e-12)
                mass_entropy += (-(_ap_safe * torch.log(_ap_safe)).sum(dim=-1)).sum().item()

                mass_sink += A_post[:, :, sink_slice].sum().item()
                if len(subj_mem_indices) > 0:
                    smi_t = torch.tensor(subj_mem_indices, device=device, dtype=torch.long)
                    mass_subj_mem += A_post[:, :, smi_t].sum().item()
                if len(bg_mem_indices) > 0:
                    bmi_t = torch.tensor(bg_mem_indices, device=device, dtype=torch.long)
                    mass_bg_mem += A_post[:, :, bmi_t].sum().item()
                mass_local += A_post[:, :, local_slice].sum().item()

            norm = max(n_q * n_heads, 1)
            results[f"{group_name}_to_sink"] = float(mass_sink / norm)
            results[f"{group_name}_to_subj_mem"] = float(mass_subj_mem / norm)
            results[f"{group_name}_to_bg_mem"] = float(mass_bg_mem / norm)
            results[f"{group_name}_to_local"] = float(mass_local / norm)
            results[f"{group_name}_entropy"] = float(mass_entropy / norm)

        results["cross_region_leakage_bg_to_subj"] = results.get("bg_q_to_subj_mem", 0.0)
        results["cross_region_leakage_subj_to_bg"] = results.get("subj_q_to_bg_mem", 0.0)
        return results


def _compute_fisher_diagnostics(
    roped_query, k_cat, v_cat, log_w_cat, sink_tokens, k_sel_eff,
    frame_seqlen, num_new_frames, subj, h_patches, w_patches,
    device, head_dim, anchor_count, routing_mode, cpu_k_list_len,
    anchor_pool_indices, ctx_w, r, memory_token_count,
):
    """
    Read-only fisher diagnostics using value-contribution (NOT logits).
    Chunked over subject-query tokens to bound memory.

    Returns a dict of per-metric scalars, or None if no subject queries.
    """
    with torch.no_grad():
        K_total = k_cat.shape[1]
        n_heads = k_cat.shape[2]
        d = head_dim
        scale = d ** 0.5

        # Subject query token indices
        subj_flat = subj.reshape(-1).astype(np.float32)
        sq_mask = np.tile(subj_flat.astype(bool), num_new_frames)
        sq_idx = np.where(sq_mask)[0]
        n_subj_q = len(sq_idx)
        if n_subj_q == 0:
            return None

        # Memory token indices within k_cat (after sink)
        mem_start = sink_tokens
        mem_end = sink_tokens + memory_token_count

        # Anchor key positions (first anchor_count*frame_seqlen tokens of memory)
        anchor_tokens = anchor_count * frame_seqlen
        anchor_abs_start = mem_start
        anchor_abs_end = mem_start + anchor_tokens
        anchor_abs = list(range(anchor_abs_start, min(anchor_abs_end, mem_end)))

        sq_idx_t = torch.from_numpy(sq_idx).long().to(device)

        Q_all = roped_query[0].float()   # [s, n, d]
        Kf = k_cat[0].float()            # [K_total, n, d]
        Vf = v_cat[0].float()            # [K_total, n, d]

        chunk_size = 128
        # Accumulators
        attn_mass_anchor_sum = 0.0
        attn_mass_mem_sum = 0.0
        contrib_anchor_norm_sq = 0.0
        mem_out_norm_sq = 0.0
        weight_sum_pre_sum = 0.0
        weight_sum_post_sum = 0.0
        n_chunks = 0

        log_w_bias = None
        if log_w_cat is not None:
            log_w_bias = log_w_cat[0].float()  # [1, 1, 1, K_total] -> squeeze to get [K_total] bias

        for c_start in range(0, n_subj_q, chunk_size):
            c_end = min(c_start + chunk_size, n_subj_q)
            c_idx = sq_idx_t[c_start:c_end]
            Qc = Q_all[c_idx]                      # [chunk, n, d]

            # Pre-renorm logits + softmax
            logits_pre = torch.einsum('qhd,khd->qhk', Qc, Kf) / scale  # [chunk, n, K_total]
            A_pre = torch.softmax(logits_pre, dim=-1)                    # [chunk, n, K_total]

            # Post-renorm (with log_w bias if applicable)
            if log_w_bias is not None:
                logits_post = logits_pre + log_w_bias  # broadcast [1, 1, K_total] over [chunk, n, K_total]
                A_post = torch.softmax(logits_post, dim=-1)
            else:
                A_post = A_pre

            # attn_mass_anchor: sum of attention over anchor keys
            if len(anchor_abs) > 0:
                anchor_idx_t = torch.tensor(anchor_abs, device=device, dtype=torch.long)
                A_pre_anchor = A_pre[:, :, anchor_idx_t]   # [chunk, n, n_anchor]
                attn_mass_anchor_sum += A_pre_anchor.sum().item()
                # Value contribution from anchor
                V_anchor = Vf[anchor_idx_t]                 # [n_anchor, n, d]
                contrib_anchor = torch.einsum('qhb,bhd->qhd', A_pre_anchor, V_anchor)
                contrib_anchor_norm_sq += (contrib_anchor ** 2).sum().item()

            # attn_mass_mem: sum over all memory keys
            mem_idx = list(range(mem_start, mem_end))
            mem_idx_t = torch.tensor(mem_idx, device=device, dtype=torch.long)
            A_pre_mem = A_pre[:, :, mem_idx_t]
            attn_mass_mem_sum += A_pre_mem.sum().item()

            # mem_out_norm: ||A_mem * V_mem||
            V_mem = Vf[mem_idx_t]
            contrib_mem = torch.einsum('qhb,bhd->qhd', A_pre_mem, V_mem)
            mem_out_norm_sq += (contrib_mem ** 2).sum().item()

            # Weight sums (pre and post renorm, over memory keys)
            weight_sum_pre_sum += A_pre_mem.sum().item()
            if log_w_bias is not None:
                A_post_mem = A_post[:, :, mem_idx_t]
                weight_sum_post_sum += A_post_mem.sum().item()
            else:
                weight_sum_post_sum += A_pre_mem.sum().item()

            n_chunks += 1

        # Normalize: divide by number of subject-query tokens (not chunks)
        n_q_total = n_chunks * min(chunk_size, n_subj_q - (n_chunks - 1) * chunk_size)
        if n_q_total == 0:
            n_q_total = 1

        # But we summed per-token across queries, so the actual total is n_subj_q queries
        # * n_heads per query. For "per-query" averages, we divide by n_subj_q.
        n_subj_queries = n_subj_q  # number of subject query tokens
        n_heads_actual = n_heads

        # attn_mass is raw sum (not per-query)
        attn_mass_anchor = attn_mass_anchor_sum
        attn_mass_mem = attn_mass_mem_sum

        # contrib norms are sum of squares
        contrib_anchor_norm = contrib_anchor_norm_sq ** 0.5
        mem_out_norm = mem_out_norm_sq ** 0.5

        # weight_sum_pre/post are averaged per query
        weight_sum_pre = weight_sum_pre_sum / max(n_subj_queries * n_heads_actual, 1)
        weight_sum_post = weight_sum_post_sum / max(n_subj_queries * n_heads_actual, 1)

        # realized_budget: effective average weight on memory tokens
        if ctx_w is not None and r is not None:
            realized_budget = r * 1.0 + (1.0 - r) * ctx_w  # anchor weight is 1.0 for subject
        else:
            realized_budget = 0.0

        # clamp_fraction: 1 if ctx_w <= 0 and r > 0, else 0
        clamp_fraction = 1.0 if (ctx_w is not None and ctx_w <= 0.0 and (r or 0) > 1e-9) else 0.0

        # Earliest retrieved frame: approximation from memory_indices
        earliest_frame = -1  # filled by caller

        return {
            "attn_mass_anchor": float(attn_mass_anchor),
            "attn_mass_mem": float(attn_mass_mem),
            "contrib_anchor_norm": float(contrib_anchor_norm),
            "mem_out_norm": float(mem_out_norm),
            "weight_sum_pre": float(weight_sum_pre),
            "weight_sum_post": float(weight_sum_post),
            "realized_budget": float(realized_budget),
            "clamp_fraction": float(clamp_fraction),
            "n_subj_q": n_subj_q,
            "K_total": K_total,
            "anchor_tokens": len(anchor_abs),
            "mem_tokens": mem_end - mem_start,
        }


def _selective_forward(
    self,
    x,
    seq_lens,
    grid_sizes,
    freqs,
    block_mask,
    kv_cache=None,
    current_start=0,
    cache_start=None,
    sink_recache_after_switch=False,
    memory_indices=None,
):
    """
    CausalWanSelfAttention.forward with optional TetherMem routing.
    """
    b, s, n, d = *x.shape[:2], self.num_heads, self.head_dim
    if cache_start is None:
        cache_start = current_start

    def qkv_fn(x):
        q = self.norm_q(self.q(x)).view(b, s, n, d)
        k = self.norm_k(self.k(x)).view(b, s, n, d)
        v = self.v(x).view(b, s, n, d)
        return q, k, v

    q, k, v = qkv_fn(x)

    if kv_cache is None:
        # --- training / teacher-forcing path (unchanged) ---
        from wan.modules.model import rope_apply
        from wan.modules.causal_model_latentmem import flex_attention
        is_tf = (s == seq_lens[0].item() * 2)
        if is_tf:
            q_chunk = torch.chunk(q, 2, dim=1)
            k_chunk = torch.chunk(k, 2, dim=1)
            roped_query, roped_key = [], []
            for ii in range(2):
                rq = rope_apply(q_chunk[ii], grid_sizes, freqs).type_as(v)
                rk = rope_apply(k_chunk[ii], grid_sizes, freqs).type_as(v)
                roped_query.append(rq)
                roped_key.append(rk)
            roped_query = torch.cat(roped_query, dim=1)
            roped_key = torch.cat(roped_key, dim=1)
            padded_length = math.ceil(q.shape[1] / 128) * 128 - q.shape[1]
            padded_roped_query = torch.cat(
                [roped_query, torch.zeros([q.shape[0], padded_length, q.shape[2], q.shape[3]], device=q.device, dtype=v.dtype)], dim=1)
            padded_roped_key = torch.cat(
                [roped_key, torch.zeros([k.shape[0], padded_length, k.shape[2], k.shape[3]], device=k.device, dtype=v.dtype)], dim=1)
            padded_v = torch.cat(
                [v, torch.zeros([v.shape[0], padded_length, v.shape[2], v.shape[3]], device=v.device, dtype=v.dtype)], dim=1)
            x = flex_attention(
                query=padded_roped_query.transpose(2, 1),
                key=padded_roped_key.transpose(2, 1),
                value=padded_v.transpose(2, 1),
                block_mask=block_mask
            )[:, :, :-padded_length].transpose(2, 1)
        else:
            roped_query = rope_apply(q, grid_sizes, freqs).type_as(v)
            roped_key = rope_apply(k, grid_sizes, freqs).type_as(v)
            padded_length = math.ceil(q.shape[1] / 128) * 128 - q.shape[1]
            padded_roped_query = torch.cat(
                [roped_query, torch.zeros([q.shape[0], padded_length, q.shape[2], q.shape[3]], device=q.device, dtype=v.dtype)], dim=1)
            padded_roped_key = torch.cat(
                [roped_key, torch.zeros([k.shape[0], padded_length, k.shape[2], k.shape[3]], device=k.device, dtype=v.dtype)], dim=1)
            padded_v = torch.cat(
                [v, torch.zeros([v.shape[0], padded_length, v.shape[2], v.shape[3]], device=v.device, dtype=v.dtype)], dim=1)
            x = flex_attention(
                query=padded_roped_query.transpose(2, 1),
                key=padded_roped_key.transpose(2, 1),
                value=padded_v.transpose(2, 1),
                block_mask=block_mask
            )[:, :, :-padded_length].transpose(2, 1)
    else:
        # --- inference path (unchanged structure) ---
        frame_seqlen = math.prod(grid_sizes[0][1:]).item()
        num_new_frames = grid_sizes[0][0].item()
        current_end = current_start + q.shape[1]
        sink_tokens = self.sink_size * frame_seqlen
        kv_cache_size = kv_cache["k"].shape[1]
        num_new_tokens = q.shape[1]

        cache_update_info = None
        is_recompute = current_end <= kv_cache["global_end_index"].item() and current_start > 0

        routing_mode = getattr(self, "routing_mode", "tethermem")
        anchor_count = 0
        anchor_pool_indices = []
        effective_indices_list = None
        k_sel_eff = 0
        k_sel_orig = 0
        cpu_k_list_len = 0

        if self.local_attn_size != -1 and (current_end > kv_cache["global_end_index"].item()) and (
                num_new_tokens + kv_cache["local_end_index"].item() > kv_cache_size):
            # Block-Relativistic RoPE roll-and-insert path
            num_evicted_tokens = num_new_tokens + kv_cache["local_end_index"].item() - kv_cache_size
            num_rolled_tokens = kv_cache["local_end_index"].item() - num_evicted_tokens - sink_tokens
            local_end_index = kv_cache["local_end_index"].item() + current_end - kv_cache["global_end_index"].item() - num_evicted_tokens
            local_start_index = local_end_index - num_new_tokens

            temp_k = kv_cache["k"].clone()
            temp_v = kv_cache["v"].clone()

            evicted_k_frames, evicted_v_frames = [], []
            if self.memory_size > 0 and num_evicted_tokens > 0:
                num_evicted_frames = num_evicted_tokens // frame_seqlen
                ev_k = temp_k[:, sink_tokens:sink_tokens + num_evicted_tokens]
                ev_v = temp_v[:, sink_tokens:sink_tokens + num_evicted_tokens]
                ev_k_split = ev_k.view(b, num_evicted_frames, frame_seqlen, n, d).split(1, dim=1)
                ev_v_split = ev_v.view(b, num_evicted_frames, frame_seqlen, n, d).split(1, dim=1)
                evicted_k_frames = [f.to("cpu", non_blocking=True) for f in ev_k_split]
                evicted_v_frames = [f.to("cpu", non_blocking=True) for f in ev_v_split]

            temp_k[:, sink_tokens:sink_tokens + num_rolled_tokens] = \
                temp_k[:, sink_tokens + num_evicted_tokens:sink_tokens + num_evicted_tokens + num_rolled_tokens].clone()
            temp_v[:, sink_tokens:sink_tokens + num_rolled_tokens] = \
                temp_v[:, sink_tokens + num_evicted_tokens:sink_tokens + num_evicted_tokens + num_rolled_tokens].clone()

            write_start_index = max(local_start_index, sink_tokens) if is_recompute else local_start_index
            roped_offset = max(0, write_start_index - local_start_index)
            write_len = max(0, local_end_index - write_start_index)
            if write_len > 0:
                temp_k[:, write_start_index:local_end_index] = k[:, roped_offset:roped_offset + write_len]
                temp_v[:, write_start_index:local_end_index] = v[:, roped_offset:roped_offset + write_len]

            query_relative_indices = torch.arange(
                self.local_attn_size - num_new_frames, self.local_attn_size, device=q.device)
            roped_query = block_relativistic_rope(
                q, grid_sizes, freqs, relative_frame_indices=query_relative_indices).type_as(v)

            num_cache_frames = local_end_index // frame_seqlen
            cache_relative_indices = torch.arange(0, num_cache_frames, device=k.device)
            cache_grid_sizes = grid_sizes.clone()
            cache_grid_sizes[0, 0] = num_cache_frames
            roped_temp_k = block_relativistic_rope(
                temp_k[:, :local_end_index].view(b, num_cache_frames, frame_seqlen, n, d).flatten(1, 2),
                cache_grid_sizes, freqs, relative_frame_indices=cache_relative_indices).type_as(v)

            cache_update_info = {
                "action": "roll_and_insert",
                "sink_tokens": sink_tokens,
                "num_rolled_tokens": num_rolled_tokens,
                "num_evicted_tokens": num_evicted_tokens,
                "local_start_index": local_start_index,
                "local_end_index": local_end_index,
                "write_start_index": write_start_index,
                "write_end_index": local_end_index,
                "new_k": k[:, roped_offset:roped_offset + write_len],
                "new_v": v[:, roped_offset:roped_offset + write_len],
                "current_end": current_end,
                "is_recompute": is_recompute,
                "evicted_k_frames": evicted_k_frames,
                "evicted_v_frames": evicted_v_frames,
            }
        else:
            # Direct insert path
            local_end_index = kv_cache["local_end_index"].item() + current_end - kv_cache["global_end_index"].item()
            local_start_index = local_end_index - num_new_tokens

            temp_k = kv_cache["k"].clone()
            temp_v = kv_cache["v"].clone()

            write_start_index = max(local_start_index, sink_tokens) if is_recompute else local_start_index
            if sink_recache_after_switch:
                write_start_index = local_start_index
            roped_offset = max(0, write_start_index - local_start_index)
            write_len = max(0, local_end_index - write_start_index)
            if write_len > 0:
                temp_k[:, write_start_index:local_end_index] = k[:, roped_offset:roped_offset + write_len]
                temp_v[:, write_start_index:local_end_index] = v[:, roped_offset:roped_offset + write_len]

            current_frame_in_window = local_start_index // frame_seqlen
            query_relative_indices = torch.arange(
                current_frame_in_window, current_frame_in_window + num_new_frames, device=q.device)
            roped_query = block_relativistic_rope(
                q, grid_sizes, freqs, relative_frame_indices=query_relative_indices).type_as(v)

            num_cache_frames = local_end_index // frame_seqlen
            cache_relative_indices = torch.arange(0, num_cache_frames, device=k.device)
            cache_grid_sizes = grid_sizes.clone()
            cache_grid_sizes[0, 0] = num_cache_frames
            roped_temp_k = block_relativistic_rope(
                temp_k[:, :local_end_index].view(b, num_cache_frames, frame_seqlen, n, d).flatten(1, 2),
                cache_grid_sizes, freqs, relative_frame_indices=cache_relative_indices).type_as(v)

            cache_update_info = {
                "action": "direct_insert",
                "local_start_index": local_start_index,
                "local_end_index": local_end_index,
                "write_start_index": write_start_index,
                "write_end_index": local_end_index,
                "new_k": k[:, roped_offset:roped_offset + write_len],
                "new_v": v[:, roped_offset:roped_offset + write_len],
                "current_end": current_end,
                "is_recompute": is_recompute,
            }

        # Use roped K for attention computation
        if sink_tokens > 0 or self.memory_size > 0:
            local_budget = self.max_attention_size - sink_tokens - (self.memory_size * frame_seqlen)
            k_sink = roped_temp_k[:, :sink_tokens]
            v_sink = temp_v[:, :sink_tokens]
            local_start_for_window = max(sink_tokens, local_end_index - local_budget)

            k_mem = None
            v_mem = None

            if self.memory_size > 0 and memory_indices is not None:
                cpu_k_list = kv_cache.get("cpu_k_frames", [])
                cpu_v_list = kv_cache.get("cpu_v_frames", [])
                cpu_k_list_len = len(cpu_k_list)

                if len(cpu_k_list) > 0:
                    k_sel_orig = memory_indices.shape[1]
                    device = q.device

                    anchor_count = 0
                    anchor_pool_indices = []
                    effective_indices_list = [
                        memory_indices[bi].tolist() for bi in range(b)
                    ]
                    k_sel_eff = k_sel_orig

                    # Build k_mem_unroped and v_mem from effective indices
                    k_mem_unroped_list = []
                    v_mem_list = []
                    for bi in range(b):
                        for k_idx in effective_indices_list[bi]:
                            k_mem_unroped_list.append(cpu_k_list[k_idx][bi, 0].to(device, non_blocking=True))
                            v_mem_list.append(cpu_v_list[k_idx][bi, 0].to(device, non_blocking=True))

                    k_mem_unroped = torch.stack(k_mem_unroped_list, dim=0).view(b, k_sel_eff * frame_seqlen, n, d)
                    v_mem = torch.stack(v_mem_list, dim=0).view(b, k_sel_eff * frame_seqlen, n, d)

                    mem_grid_sizes = grid_sizes.clone()
                    mem_grid_sizes[:, 0] = k_sel_eff
                    k_mem = block_relativistic_rope(
                        k_mem_unroped,
                        mem_grid_sizes, freqs,
                        relative_frame_indices=torch.zeros(k_sel_eff, dtype=torch.long, device=device)
                    ).type_as(v)

            # Build the query and memory region labels used by TetherMem.
            if getattr(self, "region_factorize", False) and k_mem is not None and v_mem is not None \
                    and getattr(self, "_sam2_masks", None) is not None:
                h_patches = int(grid_sizes[0, 1].item())
                w_patches = int(grid_sizes[0, 2].item())
                masks = self._sam2_masks
                q_global = current_start // frame_seqlen
                q_global = min(max(q_global, 0), masks.shape[0] - 1)
                subj = masks[q_global]
                if subj.shape != (h_patches, w_patches):
                    import cv2 as _cv2
                    subj = (_cv2.resize(subj.astype(np.float32), (w_patches, h_patches),
                                        interpolation=_cv2.INTER_NEAREST) > 0.5).astype(np.uint8)
                r = float(subj.sum()) / float(subj.size) if subj.size > 0 else 0.0
                anchor_w = float(getattr(self, "anchor_weight", 1.0))
                target_avg = float(getattr(self, "target_avg", 0.25))
                ctx_w = solve_context_weight(r, anchor_w, target_avg)
                subj1d = subj.reshape(-1).astype(np.float32)  # [h*w]
                if routing_mode == "tethermem":
                    self._selective_call_count = int(
                        getattr(self, "_selective_call_count", 0)
                    ) + 1

            k_parts = [k_sink]
            v_parts = [v_sink]
            if k_mem is not None:
                k_parts.append(k_mem)
                v_parts.append(v_mem)
            if local_budget > 0 and local_start_for_window < local_end_index:
                k_local = roped_temp_k[:, local_start_for_window:local_end_index]
                v_local = temp_v[:, local_start_for_window:local_end_index]
                k_parts.append(k_local)
                v_parts.append(v_local)

            k_cat = torch.cat(k_parts, dim=1)
            v_cat = torch.cat(v_parts, dim=1)

            # Count tokens for diagnostics
            mem_token_count = k_mem.shape[1] if k_mem is not None else 0
            local_token_count = (k_local.shape[1] if (local_budget > 0 and local_start_for_window < local_end_index) else 0)

            # Read-only diagnostics collected before attention.
            _fdiag = getattr(self, "fisher_diag", None)
            _selective_ran = ('subj' in locals() and subj is not None)

            # Shared query and memory labels for routing and diagnostics.
            subj_q_mask_bool = None
            mem_subj_keymask = None
            if _selective_ran:
                # subject-query mask  [S_q = num_new_frames * frame_seqlen]
                subj_q_mask_bool = np.tile(subj1d.astype(bool), num_new_frames)

                # Each retrieved frame uses its own historical subject mask.
                mem_subj_keymask = build_memory_subject_mask(
                    masks,
                    effective_indices_list,
                    k_sel_eff,
                    subj,
                    per_frame=True,
                )

            # TetherMem query-conditioned memory routing.
            bias_subj_t = None
            bias_bg_t = None
            if routing_mode == "tethermem" and k_mem is not None and _selective_ran and (
                    mem_subj_keymask is not None):
                device_local = q.device
                log_ctxw_val = max(ctx_w, 1e-9)
                log_ctxw_t = torch.log(torch.tensor(log_ctxw_val, device=device_local, dtype=torch.float32)).clamp(min=-1e9)

                K_total_local = k_cat.shape[1]
                bias_subj_t = torch.zeros(K_total_local, device=device_local, dtype=torch.float32)

                # bg-mem absolute indices in k_cat
                mem_start = sink_tokens
                bg_mem_local_mask = ~mem_subj_keymask  # bool [mem_tokens]
                bg_mem_abs_idx = np.where(bg_mem_local_mask)[0] + mem_start

                # Subject queries de-emphasize background memory.
                if len(bg_mem_abs_idx) > 0:
                    bg_mem_idx_t = torch.from_numpy(bg_mem_abs_idx).long().to(device_local)
                    bias_subj_t[bg_mem_idx_t] = log_ctxw_t

                # Background queries de-emphasize subject memory.
                bias_bg_t = torch.zeros(K_total_local, device=device_local, dtype=torch.float32)
                subj_mem_abs_idx = np.where(mem_subj_keymask)[0] + mem_start
                if len(subj_mem_abs_idx) > 0:
                    subj_mem_idx_t = torch.from_numpy(subj_mem_abs_idx).long().to(device_local)
                    bias_bg_t[subj_mem_idx_t] = log_ctxw_t

                # Recency decay prevents stale background memories from dominating.
                # Pool index 0 is the oldest memory; larger indices are more recent.
                age_max = max(min(cpu_k_list_len, 120), 1)
                age_floor = float(getattr(self, "age_decay_floor", 0.05))
                age_relative = bool(getattr(self, "age_relative", False))
                all_pool = [effective_indices_list[bi_][j]
                            for bi_ in range(b) for j in range(k_sel_eff)]
                min_pool = min(all_pool) if all_pool else 0
                max_pool = max(all_pool) if all_pool else 0
                age_weights_list = []

                # Relative decay is activated only when every retrieved memory is
                # stale, guaranteeing that the newest item in that set stays usable.
                stale_threshold = 0.15
                use_relative = age_relative and (
                    max_pool / float(age_max) < stale_threshold
                )
                for bi_ in range(b):
                    for j in range(k_sel_eff):
                        pool_idx = effective_indices_list[bi_][j]
                        if use_relative:
                            denom = max(max_pool - min_pool, 1)
                            age_weight = max(
                                (pool_idx - min_pool) / float(denom), age_floor
                            )
                        else:
                            age_weight = max(pool_idx / age_max, age_floor)
                        age_weights_list.append(
                            np.full(frame_seqlen, age_weight, dtype=np.float32)
                        )
                age_weights_np = np.concatenate(age_weights_list)
                log_age = torch.log(
                    torch.from_numpy(age_weights_np).clamp(min=1e-9)
                ).clamp(min=-1e9)
                log_age = log_age.to(device=device_local, dtype=torch.float32)
                if len(bg_mem_abs_idx) > 0:
                    bg_mem_idx_t = torch.from_numpy(bg_mem_abs_idx).long().to(device_local)
                    bg_mem_local_idx_t = torch.from_numpy(
                        np.where(bg_mem_local_mask)[0]
                    ).long().to(device_local)
                    bias_bg_t[bg_mem_idx_t] = log_age[bg_mem_local_idx_t]

            # --- Diagnostics recording ---
            if _fdiag is not None and _fdiag.get("active") and routing_mode == "tethermem" \
                    and k_mem is not None and memory_indices is not None and _selective_ran:
                try:
                    earliest_frame = -1
                    if effective_indices_list is not None and len(effective_indices_list) > 0:
                        all_indices = effective_indices_list[0]
                        if all_indices:
                            earliest_frame = min(all_indices) + 1

                    rec = _compute_fisher_diagnostics(
                        roped_query=roped_query,
                        k_cat=k_cat,
                        v_cat=v_cat,
                        log_w_cat=None,
                        sink_tokens=sink_tokens,
                        k_sel_eff=k_sel_eff,
                        frame_seqlen=frame_seqlen,
                        num_new_frames=num_new_frames,
                        subj=subj.copy(),
                        h_patches=h_patches,
                        w_patches=w_patches,
                        device=q.device,
                        head_dim=int(d),
                        anchor_count=anchor_count,
                        routing_mode=routing_mode,
                        cpu_k_list_len=cpu_k_list_len,
                        anchor_pool_indices=anchor_pool_indices,
                        ctx_w=ctx_w,
                        r=r,
                        memory_token_count=mem_token_count,
                    )
                    if rec is not None:
                        rec["layer_id"] = int(getattr(self, "_layer_id", -1))
                        rec["block"] = int(current_start // (num_new_frames * frame_seqlen))
                        rec["q_global"] = int(q_global)
                        rec["k_sel"] = int(k_sel_eff)
                        rec["k_sel_orig"] = int(k_sel_orig)
                        rec["mode"] = routing_mode
                        rec["earliest_retrieved_frame"] = int(earliest_frame)
                        rec["anchor_count"] = anchor_count
                        rec["anchor_available"] = bool(cpu_k_list_len >= 3)
                        rec["anchor_pool_indices"] = anchor_pool_indices
                        _fdiag["records"].append(rec)
                except Exception:
                    pass  # silent; diagnostics must not perturb generation
            # =====================================================================================

            # Read-only routing-mechanism diagnostics.
            _rdiag = getattr(self, "routing_diag", None)
            _rblk = int(current_start // (num_new_frames * frame_seqlen)) if (num_new_frames and frame_seqlen) else 0
            # SAMPLE the routing diag (every 4th layer x every 4th block) to bound overhead.
            # The routing pattern is consistent across layers/blocks, so a sample suffices and
            # cuts diag cost ~16x. Video output is UNAFFECTED (diag is read-only, no_grad).
            # DENSE mode (routing_diag_dense=True): log ALL layers for blocks 28-38 (switch
            # region, e.g. MV08 ~frame420=block35) + retrieval set + entropy. Else sampled.
            _dense = bool(getattr(self, "routing_diag_dense", False))
            if _dense:
                _layer_ok = True
                _blk_ok = (28 <= _rblk <= 38)
            else:
                _layer_ok = (int(getattr(self, "_layer_id", -1)) % 4 == 0)
                _blk_ok = (_rblk % 4 == 0)
            if _rdiag is not None and _rdiag.get("active") and k_mem is not None \
                    and memory_indices is not None and _selective_ran and subj_q_mask_bool is not None \
                    and mem_subj_keymask is not None \
                    and _layer_ok and _blk_ok:
                try:
                    rdiag_bias_subj = bias_subj_t
                    rdiag_bias_bg = bias_bg_t

                    rrec = _compute_routing_diagnostics(
                        roped_query=roped_query,
                        k_cat=k_cat,
                        bias_subj=rdiag_bias_subj,
                        bias_bg=rdiag_bias_bg,
                        subj_q_mask_bool=subj_q_mask_bool,
                        mem_subj_keymask=mem_subj_keymask,
                        sink_tokens=sink_tokens,
                        mem_token_count=mem_token_count,
                        local_token_count=local_token_count,
                        frame_seqlen=frame_seqlen,
                        num_new_frames=num_new_frames,
                        device=q.device,
                        head_dim=int(d),
                        routing_mode=routing_mode,
                        ctx_w=ctx_w,
                        r=r,
                    )
                    if rrec is not None:
                        rrec["layer_id"] = int(getattr(self, "_layer_id", -1))
                        rrec["block"] = int(current_start // (num_new_frames * frame_seqlen))
                        rrec["q_global"] = int(q_global)
                        rrec["k_sel"] = int(k_sel_eff)
                        rrec["ctx_w"] = float(ctx_w)
                        rrec["r"] = float(r)
                        rrec["mode"] = routing_mode
                        rrec["K_total"] = int(k_cat.shape[1])
                        # retrieval set + age (pool_idx = temporal age; 0=oldest/stale)
                        if effective_indices_list is not None and len(effective_indices_list) > 0:
                            _idxs = list(effective_indices_list[0])
                            rrec["retrieved_pool_indices"] = str(_idxs)
                            rrec["n_retrieved"] = len(_idxs)
                            rrec["mean_pool_idx"] = float(np.mean(_idxs)) if _idxs else 0.0
                            rrec["min_pool_idx"] = float(np.min(_idxs)) if _idxs else 0.0
                            rrec["max_pool_idx"] = float(np.max(_idxs)) if _idxs else 0.0
                        else:
                            rrec["retrieved_pool_indices"] = "[]"
                            rrec["n_retrieved"] = 0
                            rrec["mean_pool_idx"] = 0.0
                            rrec["min_pool_idx"] = 0.0
                            rrec["max_pool_idx"] = 0.0
                        _rdiag["records"].append(rrec)
                except Exception:
                    pass  # silent; diagnostics must not perturb generation
            # ==================================================================================================

            # TetherMem splits subject/background queries to apply their key bias.
            if routing_mode == "tethermem" and k_mem is not None and _selective_ran and (
                    subj_q_mask_bool is not None) and bias_subj_t is not None:
                x = _split_query_sdpa(roped_query, k_cat, v_cat, subj_q_mask_bool,
                                       bias_subj_t, bias_bg_t, v.dtype)
            else:
                # LongLive-RAG reference path, or a step without routed memory.
                x = attention(roped_query, k_cat, v_cat)
        else:
            window_start = max(0, local_end_index - self.max_attention_size)
            x = attention(
                roped_query,
                roped_temp_k[:, window_start:local_end_index],
                temp_v[:, window_start:local_end_index]
            )

    x = x.flatten(2)
    x = self.o(x)

    if kv_cache is not None:
        return x, (current_end, local_end_index, cache_update_info)
    else:
        return x


def apply_selective_patch(pipeline, config):
    """
    Install _selective_forward on all CausalWanSelfAttention modules and load
    the SAM2 subject mask. Reads from config:
      - routing_mode (str, default 'tethermem': baseline/tethermem)
      - anchor_weight (float, default 1.0)
      - target_avg (float, default 0.25)
      - selective_debug (bool, default False)
      - sam2_mask_path (str, path to npy [T,h,w] uint8 subject=1)
      - fisher_diag_active (bool, default False) -- enables diagnostics logger
    """
    routing_mode = getattr(config, "routing_mode", "tethermem")
    if routing_mode not in {"baseline", "tethermem"}:
        raise ValueError(f"unsupported routing mode: {routing_mode!r}")
    print(
        f"[ROUTING patch] Installing _selective_forward mode={routing_mode} "
        "on CausalWanSelfAttention"
    )
    CausalWanSelfAttention.forward = _selective_forward

    anchor_w = float(getattr(config, "anchor_weight", 1.0))
    target_avg = float(getattr(config, "target_avg", 0.25))
    if routing_mode == "baseline":
        target_avg = 1.0
    selective_debug = bool(getattr(config, "selective_debug", False))
    fisher_diag_active = bool(getattr(config, "fisher_diag_active", False))
    routing_diag_active = bool(getattr(config, "routing_diag_active", False))
    routing_diag_dense = bool(getattr(config, "routing_diag_dense", False))
    age_relative = bool(getattr(config, "age_relative", False))
    age_decay_floor = float(getattr(config, "age_decay_floor", 0.05))
    mask_path = getattr(config, "sam2_mask_path", None)
    masks = None
    if mask_path:
        from tethermem.masks import load_patch_mask

        masks = load_patch_mask(mask_path)
        print(f"[ROUTING patch] mask loaded {mask_path} shape={list(masks.shape)} "
              f"mean_area_frac={float(masks.reshape(masks.shape[0], -1).sum(1).mean())/masks[0].size:.4f}")

    count = 0
    for name, module in pipeline.generator.model.named_modules():
        if isinstance(module, CausalWanSelfAttention):
            module.region_factorize = True
            module.routing_mode = routing_mode
            module.anchor_weight = anchor_w
            module.target_avg = target_avg
            module.selective_debug = selective_debug
            module._selective_call_count = 0
            module._layer_id = count
            module.fisher_diag = {"active": fisher_diag_active, "records": []}
            module.routing_diag = {"active": routing_diag_active, "records": []}
            module.routing_diag_dense = routing_diag_dense
            module.age_relative = age_relative
            module.age_decay_floor = age_decay_floor
            if masks is not None:
                module._sam2_masks = masks
            count += 1

    print(f"[ROUTING patch] patched {count} modules mode={routing_mode} anchor={anchor_w} "
          f"target_avg={target_avg} fisher_diag={'on' if fisher_diag_active else 'off'} "
          f"routing_diag={'on' if routing_diag_active else 'off'} "
          f"debug={selective_debug} mask={'on' if masks is not None else 'OFF'}")
