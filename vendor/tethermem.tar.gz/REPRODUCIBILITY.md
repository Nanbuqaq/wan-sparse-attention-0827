# Reproducibility record

## Scope

This repository reproduces the public TetherMem execution path: the locally
modified LongLive-RAG/Wan source, frozen routing patch, portable model layout,
canonical config, subject-mask tooling, and matched reference/TetherMem commands.

It does not contain the private or blind evaluation inputs used in the original
experiment directory. Exact private prompt assignments, pair mappings, human
annotations, databases, generated baseline videos, SAM2 masks, and result
videos were deliberately excluded. Consequently:

- a centered, single-subject prompt can be run end to end with public models
  using automatic SAM2 selection and tracking;
- an explicit first-frame box can override automatic selection for a known
  off-center subject while retaining the rest of the one-command workflow;
- a same-machine LongLive-RAG versus TetherMem comparison can be reproduced;
- the original private evaluation table cannot be regenerated from this Git
  repository alone;
- no excluded result or metric is reconstructed or claimed.

## Method identity

The canonical method is TetherMem as implemented in `tethermem/routing.py` and
configured by `configs/tethermem.yaml`.

Canonical model and routing settings:

| Setting | Value |
| --- | --- |
| Wan model | `Wan2.1-T2V-1.3B` |
| generator checkpoint | `causal_forcing.pt` |
| retrieval AE checkpoint | `ae_latent_mem.pt` |
| latent frames per block | 3 |
| canonical latent output frames | 120 |
| local attention window | 12 |
| attention sink | 1 |
| retrieved memory size | 6 |
| recent-frame exclusion | 5 |
| retrieval compression | AE |
| subject anchor weight | 1.0 |
| target spatial average | 0.25 |
| background age floor | 0.05 |
| LoRA | none |

The complete machine-readable config is `configs/tethermem.yaml`.

The minimum default TetherMem routing smoke is 21 latent frames, not 18: the 12-frame
local window plus `recent_exclude=5` otherwise leaves no eligible historical
frame for retrieval. The validator computes this threshold from the config and
rejects a shorter run instead of silently exercising only local attention.

## Public reproduction stages

### 1. Install and download

Follow `README.md` and `docs/MODELS.md`. Keep model files under `MODEL_ROOT`.
Do not commit downloaded assets.

### 2. Run the automatic workflow

Use `scripts/run_tethermem_pipeline.py` with the intended prompt, seed, frame
count, and output directory. It generates the LongLive-RAG reference, chooses a first-frame SAM2
candidate with the center-subject prior, tracks that candidate, applies the mask
quality gate, generates TetherMem, and writes paired diagnostics. No separate
RAG-generation or mask-extraction command is required.

The reference mode applies no TetherMem routing weights. The wrapper passes only
the tracked mask to TetherMem; reference-video pixels are not conditioning input
to TetherMem.

### 3. Review automatic selection and tracking

Inspect `auto_subject_overlay.png` and the early, middle, and late images under
`sam2_overlays/`. The automatic selector is class-agnostic and center-biased; it
does not use open-vocabulary grounding to prove that the selected mask matches
the prompt. For a wrong or ambiguous selection, rerun the same wrapper with an
explicit `--box` or redesign the prompt around one centered main subject.

The extractor downsamples spatially to `30x52` and can apply budget-aware
dilation. If SAM2 drops the track, the default hold-last-mask fallback is
recorded in metadata. A high fallback count is a reason to reject or re-anchor
the mask, not proof of a successful track.

### 4. Check matched reference and TetherMem generations

The wrapper uses identical prompt text, seed, frame count, config, model files,
GPU, and software environment for both outputs. LongLive-RAG generates the
reference without needing a mask; TetherMem consumes the tracked SAM2 mask. Use
a distinct output directory for every prompt, seed, or config.

The launcher records runtime versions and GPU identity before model loading,
runs a real CUDA allocation and bf16 `Conv3d`, then verifies that TetherMem routing was
called in every patched attention layer. It writes completion metadata only
after decoding the final MP4.

### 5. Evaluate

The wrapper runs `scripts/evaluate_pair.py` for bounded structural and pixel
diagnostics. Inspect both videos after it completes. Pixel diagnostics do not
measure subject identity, motion semantics, visual quality, or state
persistence. Use a separately installed perceptual benchmark only with its own
versioned protocol and keep raw metric outputs outside Git unless they are
intentionally being published.

## Mask temporal alignment boundary

The frozen forward path uses:

```text
query mask:       masks[q_global]
historical mask:  masks[retrieved_pool_index]
```

`q_global` and the retrieval pool are latent-frame indices. The experimental
SAM2 artifacts, however, were stored with one row for each decoded pixel-video
frame. For a canonical run these files had 474 rows while generation used 120
latent frames. No factor-of-four temporal resampling occurred in the frozen
driver. This repository preserves that behavior because silently changing it
would define a different method.

The mapping from retrieval pool index to global latent frame is also a
first-order approximation based on eviction order. Spatial per-frame masks
avoid labeling every retrieved frame with the current query layout, but they
are not pixel-perfect temporal correspondence.

## Synthetic mask boundary

`scripts/make_toy_mask.py` produces a deterministic moving rectangle. It is
only suitable for config parsing, mask-shape tests, routing-hook smoke tests,
and CI. It is not a public toy research sample, SAM2 output, or substitute for
the real subject mask.

## Training boundary

TetherMem has no trainable routing component in this release. The available
training workflow belongs to LongLive-RAG:

1. `generate_latent.py` runs the frozen LongLive generator over the public
   prompt pool and atomically stores latent tensors.
2. `ae/train.py` fits the retrieval autoencoder with reconstruction, Window
   Temporal Delta, and smoothing losses.
3. The Wan generator checkpoint remains frozen.

`ae/train.py --resume` restores the model, optimizer, AMP scaler, and next
epoch. It does not restore sampler/dataloader position or RNG state, so the
operation is explicitly a warm resume. It must not be described as a strict
bit-exact resume.

The downloaded toy latent files can exercise the data/model contract. They are
not the full latent corpus used to train the published AE checkpoint.

## Randomness and numerical equivalence

The single-prompt launcher seeds Python, NumPy, and PyTorch before creating the
noise tensor. A seed only controls stochastic inputs within a fixed execution
stack. It does not guarantee bit-exact video across:

- different GPU architectures;
- different PyTorch, CUDA, or attention-kernel builds;
- Flash Attention versus SDPA fallback;
- compiler/autotuning choices;
- different checkpoint revisions;
- a changed mask or SAM2 version.

Use same-machine LongLive-RAG/TetherMem pairs for method comparisons. Record all deviations from
the canonical config.

## Output integrity

Generation writes the MP4 to a same-directory temporary file and atomically
renames it. It then opens the final media with PyAV and decodes a frame. A
decode failure does not delete or overwrite the materialized media; the run
record is marked `post_processing_failed` and no completion marker is written.

Training checkpoints, latent tensors, mask arrays, JSON metadata, and config
snapshots also use same-directory temporary files followed by atomic rename.

## Verification classes

This project uses these terms:

- **Static validation:** config parsing, compilation, imports, tests, shell
  syntax, and path checks.
- **Download dry-run:** confirms the public repositories, revisions, include
  patterns, and local layout without transferring weights.
- **GPU preflight:** confirms device visibility, allocation, cuDNN state, and a
  real bf16 `Conv3d`.
- **GPU smoke:** loads real checkpoints, generates a short media artifact,
  exercises retrieval/routing, and decodes the result.
- **Canonical inference:** uses 120 latent frames and a reviewed real mask,
  whether selected automatically or supplied explicitly.
- **Scientific reproduction:** additionally recreates the exact public
  evaluation inputs and protocol. The excluded private evaluation is not in
  this class.

The completed acceptance checks and their outcomes are recorded in
`AUDIT_REPORT.md`. A static check or synthetic-mask smoke is never reported as
a canonical experiment.

## Verified end-to-end public run

On 2026-08-18, the automatic workflow committed as `d487f94` executed the
README's public teapot example on one NVIDIA M403 with PyTorch 2.6.0+cu124 and
CUDA 12.4. This was not a config-only check:

| Stage | Result |
| --- | --- |
| LongLive-RAG reference | completed in 161.77 s; 120 latent frames; 474 fully decoded 832x480 frames at 16 fps; 34 retrieval events |
| automatic selection | SAM2 AMG returned 19 candidates; the center-subject prior selected `(179,85,653,414)`; the retained overlay covered the complete teapot |
| automatic SAM2 tracking | patch shape `[474,30,52]`; tracked fraction 1.0; zero held frames; mean pixel area 0.2838; consecutive IoU 0.9905 |
| mask review | automatic selection and early, middle, and late tracking overlays were directly inspected; the teapot remained covered without obvious subject loss or background leakage |
| canonical TetherMem | completed in 280.70 s; 120 latent frames; 474 fully decoded nonblank 832x480 frames at 16 fps; 34 retrieval events; all 30 patched modules recorded 170 routing calls |
| final-video review | decoded frames 0, 237, and 473 were directly inspected; all were visible and retained the intended red teapot |
| paired diagnostics | both videos had matching frame count, shape, and rate; normalized mean absolute pixel difference was 0.1132; no perceptual-quality claim was made |

The SAM2 track ran without its optional connected-components extension, so the
upstream predictor warned that hole-filling post-processing was skipped. The
base tracker completed and the real overlays passed review. Generated media,
masks, and metadata remain in the ignored `outputs/` tree and are not release
fixtures.

The separate one-command 21-latent-frame automatic smoke generated the reference, selected
box `(179,82,650,426)`, tracked 81/81 decoded frames with consecutive IoU
0.9932, passed its mask gate, and completed TetherMem plus paired diagnostics. The
earlier direct TetherMem code smoke completed in 10.92 seconds, recorded one retrieval
event, and exercised all 30 patched attention modules five times each.

These results classify one public 120-latent-frame automatic reference -> SAM2
-> TetherMem path as canonical-inference verified. They do not establish semantic
selection for arbitrary prompts, perceptual superiority, checkpoint retraining,
or scientific reproduction of the excluded private evaluation protocol.

## Known unverified items

Unless `AUDIT_REPORT.md` explicitly records a successful run, the following are
not claimed by this clean release process:

- full latent-corpus generation;
- retrieval AE retraining to the published checkpoint quality;
- SAM2 tracking and TetherMem generation for prompts or boxes other than the documented
  public teapot example;
- the original private/blind evaluation table;
- cross-GPU bit-exact output.
