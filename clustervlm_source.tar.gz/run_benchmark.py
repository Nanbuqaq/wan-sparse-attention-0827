"""
run_benchmark.py — Unified benchmark evaluation orchestrator for ClusterVLM.

Launches distributed video QA subprocesses across configurable GPU devices,
merges per-chunk CSV results, and runs downstream metric evaluation
(multiple-choice accuracy or open-ended LLM scoring).

Usage:
    python run_benchmark.py --model llava_ov_7b --dataset mlvu --num_chunks 1
"""

import os
import argparse
import subprocess
import multiprocessing
import pandas as pd


# ============================================================================
# Utility Functions
# ============================================================================

def exec_command(cmd, sub=False, device=None):
    """Execute a shell command, optionally within a subprocess on a specific GPU."""
    print(f'exec: {cmd}')
    if not sub:
        if isinstance(cmd, list):
            cmd = ' '.join(cmd)
        os.system(cmd)
    else:
        my_env = os.environ.copy()
        my_env["CUDA_VISIBLE_DEVICES"] = device
        subprocess.run(cmd, env=my_env)


def run_qa_chunk(cmd, gpu_env):
    """
    Execute an external command in a subprocess with the given GPU environment.
    Used as the target for multiprocessing.Process to run per-chunk QA.
    """
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = gpu_env
    try:
        subprocess.run(cmd, check=True, env=env)
        print(f"Process for GPUs {gpu_env} finished successfully.")
    except subprocess.CalledProcessError as e:
        print(f"Error executing command: {' '.join(cmd)}")
        print(f"Return code: {e.returncode}")
        print(f"Output: {e.output}")
        print(f"Stderr: {e.stderr}")
    except FileNotFoundError:
        print(f"Error: The command '{cmd[0]}' was not found.")


def merge_results(save_dir, num_chunks):
    """
    Merge per-chunk CSV files into a single results.csv using Pandas.
    This is a robust, cross-platform alternative to shell-based merging.
    """
    final_result_path = os.path.join(save_dir, "results.csv")
    chunk_files = [os.path.join(save_dir, f"{num_chunks}_{i}.csv") for i in range(num_chunks)]

    df_list = []
    for f in chunk_files:
        if os.path.exists(f):
            df_list.append(pd.read_csv(f))
        else:
            print(f"Warning: Chunk file not found: {f}")

    if not df_list:
        print("Error: No chunk files were found to merge.")
        return

    merged_df = pd.concat(df_list, ignore_index=True)
    merged_df.to_csv(final_result_path, index=False)
    print(f"Successfully merged {len(df_list)} chunk files into {final_result_path}")


# ============================================================================
# Benchmark Configuration Registry
# ============================================================================

# Each dataset entry specifies:
#   solver       — module name in benchmark/ (without .py extension)
#   eval_script  — evaluation script: "eval_multiple_choice" or "eval_open_ended"
#   eval_type    — "mc" (multiple-choice) or "open" (open-ended)
#   anno_path    — path to the annotation JSON file
#   save_tag     — unique tag for the results directory name
#   gpu_ids      — GPU assignment per chunk (list of strings); cycled if num_chunks > len
#   task_func    — subprocess target function (run_qa_chunk or exec_command)

BENCHMARK_CONFIGS = {
    'mlvu': {
        'solver': 'clustervlm_offline_benchmark',
        'eval_script': 'eval_multiple_choice',
        'eval_type': 'mc',
        'anno_path': '/kaimm-distill/zhouhe08/clustervlm/datasets/mlvu/mlvu_20_local.json',
        'save_tag': '0508_test_rebuild',
        'gpu_ids': ['0'],
        'task_func': run_qa_chunk,
    },
    'longvideobench': {
        'solver': 'clustervlm_offline_benchmark',
        'eval_script': 'eval_multiple_choice',
        'eval_type': 'mc',
        'anno_path': 'data/longvideobench/longvideobench_20_noT.json',
        'save_tag': '0407_test_lvb_qwen25vl7b_vram_256f',
        'gpu_ids': ['0'],
        'task_func': run_qa_chunk,
    },
    'videomme': {
        'solver': 'clustervlm_offline_benchmark',
        'eval_script': 'eval_multiple_choice',
        'eval_type': 'mc',
        'anno_path': 'data/videomme/videomme_50.json',
        'save_tag': '0403_test_videomme_clustervlm_llava_yessubtitle',
        'gpu_ids': ['0'],
        'task_func': run_qa_chunk,
    },
    'rvs_ego': {
        'solver': 'clustervlm_stream_benchmark',
        'eval_script': 'eval_open_ended',
        'eval_type': 'open',
        'anno_path': 'data/rvs/ego/rvsego_2.json',
        'save_tag': '0402_2_test_system_rvsego_clustervlm_qwen25vl7b',
        'gpu_ids': ['0'],
        'task_func': run_qa_chunk,
    },
    'rvs_movie': {
        'solver': 'clustervlm_stream_benchmark',
        'eval_script': 'eval_open_ended',
        'eval_type': 'open',
        'anno_path': 'data/rvs/movie/rvsmovie_2.json',
        'save_tag': '0402_2_test_system_rvsmovie_clustervlm_qwen25vl7b',
        'gpu_ids': ['0'],
        'task_func': run_qa_chunk,
    },
    'kuaishou': {
        'solver': 'clustervlm_stream_benchmark',
        'eval_script': 'eval_open_ended',
        'eval_type': 'open',
        'anno_path': 'data/kuaishou/kuaishou_10.json',
        'save_tag': '0402_test_kuaishou_clustervlm_qwen25vl3b',
        'gpu_ids': ['0'],
        'task_func': run_qa_chunk,
    },
}


# ============================================================================
# Unified Benchmark Evaluation Pipeline
# ============================================================================

def eval_benchmark(args):
    """
    Unified benchmark evaluation pipeline.

    Reads configuration from BENCHMARK_CONFIGS and runs three phases:
      1. Distributed QA — spawns multi-GPU subprocesses, one per chunk
      2. Result merging — cross-platform Pandas-based CSV merge
      3. Metric evaluation — MC accuracy or open-ended LLM scoring
    """
    cfg = BENCHMARK_CONFIGS[args.dataset]
    num_chunks = args.num_chunks

    # Build results directory: results/{model}/{dataset}/{retrieve_size}-{sample_fps}-{tag}
    save_dir = os.path.join(
        "results", args.model, args.dataset,
        f"{args.retrieve_size}-{args.sample_fps}-{cfg['save_tag']}"
    )
    os.makedirs(save_dir, exist_ok=True)

    solver = cfg['solver']
    gpu_ids = cfg['gpu_ids']
    task_func = cfg['task_func']

    # ------------------------------------------------------------------
    # Phase 1: Distributed QA across multiple GPU subprocesses
    # ------------------------------------------------------------------
    if not args.only_eval:
        processes = []
        for idx in range(num_chunks):
            # Cycle GPU IDs if there are more chunks than configured GPUs
            gpu_env = gpu_ids[idx % len(gpu_ids)] if gpu_ids else str(idx)

            cmd = [
                "python", f"benchmark/{solver}.py",
                "--model", args.model,
                "--sample_fps", str(args.sample_fps),
                "--n_local", str(args.n_local),
                "--retrieve_size", str(args.retrieve_size),
                "--save_dir", save_dir,
                "--anno_path", cfg['anno_path'],
                "--debug", str(args.debug),
                "--num_chunks", str(num_chunks),
                "--chunk_idx", str(idx),
            ]

            p = multiprocessing.Process(target=task_func, args=(cmd, gpu_env))
            processes.append(p)
            p.start()

        # Wait for all subprocesses to finish
        for p in processes:
            p.join()

        # ------------------------------------------------------------------
        # Phase 2: Merge per-chunk CSV results into a single results.csv
        # ------------------------------------------------------------------
        print("All QA processes finished. Starting merge...")
        merge_results(save_dir, num_chunks)

    # ------------------------------------------------------------------
    # Phase 3: Run metric evaluation
    # ------------------------------------------------------------------
    print("Merge complete. Starting evaluation...")
    eval_script = cfg['eval_script']
    eval_type = cfg['eval_type']

    if eval_type == 'mc':
        # Multiple-choice evaluation: compute accuracy, recall, precision, F1
        eval_cmd = ["python", f"benchmark/{eval_script}.py", "--save_dir", save_dir]
    else:
        # Open-ended evaluation: LLM-based scoring with local Qwen2.5-VL
        eval_cmd = [
            "python", f"benchmark/{eval_script}.py",
            "--pred_path", os.path.join(save_dir, "results.csv"),
            "--output_dir", os.path.join(save_dir, "tmp"),
            "--output_json", os.path.join(save_dir, "results.json"),
        ]

    try:
        subprocess.run(eval_cmd, check=True)
        print(f"Evaluation for {args.dataset} finished successfully.")
    except subprocess.CalledProcessError:
        print(f"Error during evaluation for save_dir: {save_dir}")


# ============================================================================
# CLI Entry Point
# ============================================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="ClusterVLM Benchmark Evaluation Orchestrator"
    )
    parser.add_argument("--model", type=str, default="llava_ov_7b",
                        choices=['llava_ov_7b', "qwen2_5_vl_7b", "qwen2_5_vl_3b"])
    parser.add_argument("--dataset", type=str, default=None,
                        choices=list(BENCHMARK_CONFIGS.keys()))
    parser.add_argument("--num_chunks", type=int, default=1,
                        help="Number of GPU processes for distributed evaluation")
    parser.add_argument("--only_eval", action="store_true",
                        help="Skip QA and only run evaluation on existing results")
    parser.add_argument("--sample_fps", type=float, default=1,
                        help="Frames per second to sample from video")
    parser.add_argument("--n_local", type=int, default=13720,
                        help="Local window size in tokens for KV-cache attention")
    parser.add_argument("--retrieve_size", type=int, default=64,
                        help="Number of frames to retrieve from KV-cache")
    parser.add_argument("--debug", type=str, default='false',
                        help="Enable debug mode (uses subset of data)")
    args = parser.parse_args()

    if args.dataset not in BENCHMARK_CONFIGS:
        print(f"Unknown dataset: '{args.dataset}'")
        print(f"Available datasets: {list(BENCHMARK_CONFIGS.keys())}")
        exit(1)

    print(f"Running {args.dataset} evaluation with model {args.model}")
    eval_benchmark(args)
