#!/bin/bash
set -e

conda create -n clustervlm python=3.11.13 -y
eval "$(conda shell.bash hook)"
conda activate clustervlm

pip install torch==2.8.0 torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128
pip install psutil
pip install flash-attn==2.8.3 --no-build-isolation
pip install -e .
