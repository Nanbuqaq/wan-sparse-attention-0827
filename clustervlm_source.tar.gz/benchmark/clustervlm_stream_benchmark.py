import os
import time
import torch
import numpy as np
import logzero
from logzero import logger
from decord import VideoReader, cpu

from benchmark.base import BaseVQA, work


class ClusterVLMStreamBenchmark(BaseVQA):
    def load_video(self, video_path):
        if video_path.endswith('.npy'):  # FPS=1
            video = np.load(video_path)
            assert self.sample_fps <= 1
            num_frames = len(video)
            frame_idx = np.linspace(0, num_frames-1, int(num_frames*self.sample_fps), dtype=int).tolist()
            video = video[frame_idx]
        else:
            vr = VideoReader(video_path, ctx=cpu(0), num_threads=1)
            fps = round(vr.get_avg_fps())
            frame_idx = [i for i in range(0, len(vr), int(fps / self.sample_fps))]
            video = vr.get_batch(frame_idx).asnumpy()
        return video

    def video_open_qa(self, question, max_new_tokens=1024):
        input_text = {
            "question": question,
            "prompt": self.qa_model.get_prompt(question)
        }
        pred_answer = self.qa_model.question_answering(input_text, max_new_tokens=max_new_tokens)

        return {
            'pred_answer': pred_answer.replace('\n', ''),
        }

    @torch.inference_mode()
    def analyze_a_video(self, video_sample):
        # Create a full-pipeline log file for each video
        log_dir = os.path.join(self.save_dir, "logs")
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, f"{video_sample['video_id']}.log")

        # Set up an independent log file (does not interfere with the global logger)
        file_logger = logzero.setup_logger(
            name=f"stream_logger_{video_sample['video_id']}",
            logfile=log_path,
            level=logzero.logging.INFO,
            formatter=logzero.LogFormatter(color=False)  # Disable color for readability
        )

        file_logger.info("="*60)
        file_logger.info(f"[START] Processing video_id: {video_sample['video_id']}")
        file_logger.info(f"Video path: {video_sample['video_path']}")

        video_path = video_sample['video_path']
        video_start_idx = video_end_idx = 0
        
        # Probe 1: Track video decoding latency
        file_logger.info("[Step 1] Loading video file into RAM...")
        load_st = time.time()
        video = self.load_video(video_path)
        video_tensor = torch.from_numpy(video)
        load_cost = time.time() - load_st
        file_logger.info(f"[Step 1 Done] Video loaded! Total frames extracted: {len(video_tensor)} | Cost: {load_cost:.2f}s")

        self.qa_model.clear_cache()
        self.qa_model.encode_init_prompt()
        file_logger.info("[Step 2] Init prompt encoded successfully. Entering Conversation Loop.")

        for round_idx, sample in enumerate(video_sample['conversations']):
            logger.debug(f'sample: {sample}')
            question = sample['question']
            answer = sample['answer']

            file_logger.info("-" * 40)
            file_logger.info(f"[Round {round_idx + 1}] New Conversation")
            file_logger.info(f"Question: {question}")
            file_logger.info(f"GT Answer: {answer}")

            temporal_windows = torch.tensor([sample['start_time'], sample['end_time']]) * self.sample_fps
            temporal_windows = temporal_windows.tolist()
            file_logger.info(f"Required Temporal Window (Frames): {temporal_windows}")

            # Encode video frames until reaching the required time window
            if temporal_windows[-1] > video_end_idx:
                old_video_end_idx = video_end_idx
                video_end_idx = temporal_windows[-1]
                
                # Probe 2: Track streaming encoding latency for incremental chunk
                # Core of streaming VQA: only encode unseen incremental frames (video_start_idx to video_end_idx)
                encode_chunk_len = int(video_end_idx) - int(video_start_idx)
                file_logger.info(f"[Encoding] Missing frames detected. Encoding new chunk: Frame {int(video_start_idx)} -> {int(video_end_idx)} (Total {encode_chunk_len} frames)")
                
                enc_st = time.time()
                self.qa_model.encode_video(video_tensor[int(video_start_idx):int(video_end_idx)])
                enc_cost = time.time() - enc_st
                
                file_logger.info(f"[Encoding Done] Chunk encoded | Cost: {enc_cost:.2f}s")
                video_start_idx = video_end_idx
            else:
                file_logger.info(f"[Skip Encoding] Current context already covers up to frame {int(video_end_idx)}. No new frames needed.")
        
            # OpenQA
            file_logger.info("[QA Inference] Starting Question Answering...")
            qa_st = time.time()
            qa_results = self.video_open_qa(question, max_new_tokens=256)
            qa_cost = time.time() - qa_st

            self.record[(self.retrieve_size, self.chunk_size)].append({
                'video_id': video_sample['video_id'],
                'question': question,
                'answer': answer,
                'pred_answer': qa_results['pred_answer'],
            })
            
            file_logger.info(f"Pred Answer: {qa_results['pred_answer']}")
            file_logger.info(f"[QA Done] Inference Cost: {qa_cost:.2f}s")

        file_logger.info("="*60)
        file_logger.info(f"[FINISHED] video_id: {video_sample['video_id']}")
        file_logger.handlers.clear()  # Release file handles (important, prevents OOM/file locks)


if __name__ == "__main__":
    work(ClusterVLMStreamBenchmark)