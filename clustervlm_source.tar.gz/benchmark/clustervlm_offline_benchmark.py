import torch
import os
import logzero
from logzero import logger
from benchmark.base import BaseVQA, work


class ClusterVLMOfflineBenchmark(BaseVQA):
    def video_open_qa(self, question, max_new_tokens=1024, retrieved_indices=None):
        input_text = {
            "question": question,
            "prompt": self.qa_model.get_prompt(question)
        }
        pred_answer = self.qa_model.question_answering(
            input_text, max_new_tokens=max_new_tokens, retrieved_indices=retrieved_indices
        )
        return {'pred_answer': pred_answer.replace('\n', '')}

    def video_close_qa(self, question, candidates, correct_choice, retrieved_indices=None):
        input_text = self.format_mcqa_prompt(question, candidates)
        pred_answer = self.qa_model.question_answering(
            input_text, max_new_tokens=16, retrieved_indices=retrieved_indices
        )
        pred_letter = self.extract_characters_regex(pred_answer)
        return {
            'pred_answer': pred_answer.replace('\n', ''),
            'pred_choice': pred_letter,
            'acc': float(pred_letter == correct_choice),
        }

    @torch.inference_mode()
    def analyze_a_video(self, video_sample):
        # Create a separate log file for each video
        log_dir = os.path.join(self.save_dir, "logs")
        os.makedirs(log_dir, exist_ok=True)
        log_path = os.path.join(log_dir, f"{video_sample['video_id']}.log")

        # Set up an independent log file (does not interfere with the global logger)
        file_logger = logzero.setup_logger(
            name=f"logger_{video_sample['video_id']}",
            logfile=log_path,
            level=logzero.logging.INFO,
            formatter=logzero.LogFormatter(color=False)  # Disable color codes in log file
        )

        file_logger.info(f"Processing video_id: {video_sample['video_id']}")
        file_logger.info(f"Video path: {video_sample['video_path']}")

        # Normal processing pipeline
        video_path = video_sample['video_path']
        video = self.load_video(video_path)
        if not isinstance(video, torch.Tensor):
            video_tensor = torch.from_numpy(video)
        else:
            video_tensor = video

        # --- VRAM statistics start ---
        torch.cuda.empty_cache()
        torch.cuda.reset_peak_memory_stats()  # Reset peak VRAM statistics
        base_memory = torch.cuda.memory_allocated() / (1024**3)
        file_logger.info(f"[VRAM] Base VRAM after model loading: {base_memory:.2f} GB")
        # --- VRAM statistics end ---

        self.qa_model.clear_cache()
        self.qa_model.encode_init_prompt()
        self.qa_model.encode_video(video_tensor)

        for sample in video_sample['conversations']:
            question = sample['question']
            answer = sample['answer']

            file_logger.info(f"Question: {question}")
            file_logger.info(f"GT Answer: {answer}")

            if 'choices' in sample:  # CloseQA
                choices = sample['choices']
                if answer is None:  # FIXME: an ugly fix for some benchmarks do not provide GT
                    answer = choices[0]
                correct_choice = self.choice_letters[choices.index(answer)]
                qa_results = self.video_close_qa(question, choices, correct_choice)
                self.record[(self.retrieve_size, self.chunk_size)].append({
                    'video_id': video_sample['video_id'],
                    'question': question,
                    'choices': choices,
                    'answer': answer,
                    'correct_choice': correct_choice,
                    'pred_answer': qa_results['pred_answer'],
                    'pred_choice': qa_results['pred_choice'],
                    'qa_acc': qa_results['acc'] * 100,
                })
                file_logger.info(f"Pred Answer: {qa_results['pred_answer']}")
                file_logger.info(f"Pred Choice: {qa_results['pred_choice']}")
                file_logger.info(f"Acc: {qa_results['acc'] * 100:.2f}%")
            else:  # OpenQA
                qa_results = self.video_open_qa(question)
                self.record[(self.retrieve_size, self.chunk_size)].append({
                    'video_id': video_sample['video_id'],
                    'question': question,
                    'answer': answer,
                    'pred_answer': qa_results['pred_answer'],
                })
                file_logger.info(f"Pred Answer: {qa_results['pred_answer']}")

            if 'question_type' in sample:
                self.record[(self.retrieve_size, self.chunk_size)][-1]['task'] = sample['question_type']

        # --- VRAM statistics end ---
        peak_allocated = torch.cuda.max_memory_allocated() / (1024**3)
        # Peak physical VRAM occupied by PyTorch (includes cache pool, fragments; close to nvidia-smi, excluding CUDA Context)
        peak_reserved = torch.cuda.max_memory_reserved() / (1024**3)

        print(f"[VRAM] Algorithm theoretical peak (Allocated): {peak_allocated:.2f} GB")
        print(f"[VRAM] Physical occupied peak (Reserved): {peak_reserved:.2f} GB")
        # --- End VRAM statistics ---

        file_logger.info(f"Finished processing video: {video_sample['video_id']}")
        file_logger.handlers.clear()  # Release file handles (important)

if __name__ == "__main__":
    work(ClusterVLMOfflineBenchmark)
