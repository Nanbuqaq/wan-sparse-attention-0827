# Run Benchmark

## Setup

```bash
conda activate clustervlm
cd <project_root>
```

## Supported Models

- `llava_ov_7b`
- `qwen2_5_vl_3b`
- `qwen2_5_vl_7b`

## Supported Datasets

- `longvideobench`
- `mlvu`
- `rvs_ego`
- `rvs_movie`
- `videomme`

## Run

```bash
num_chunks=1
model=<model_name>
dataset=<dataset_name>
PYTHONPATH=. python -m run_benchmark \
    --num_chunks $num_chunks \
    --model ${model} \
    --dataset ${dataset} \
    --sample_fps 0.5 \
    --n_local 13720 \
    --retrieve_size 64 > test_${model}_${dataset}.txt 2>&1
```
