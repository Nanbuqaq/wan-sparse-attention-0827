import json
import os
import torch

class RetrievalLogger:
    """
    A singleton class for collecting, managing, and writing detailed retrieval
    logs to help analyze and tune the retrieval strategy.
    """
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(RetrievalLogger, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def setup(self, filename, strategy, threshold):
        """
        Initialize or reset the logger.
        """
        if self._initialized and self.filename == filename:
            return

        self.filename = filename
        self.stats = {
            "strategy_info": {
                "strategy": strategy,
                "cluster_threshold": threshold if "clustering" in strategy else None
            },
            "final_cluster_state": {
                "total_clusters": 0,
                "clusters": []
            },
            "encoding_log": [],
            "qa_log": []
        }
        self._initialized = True
        # Per-QA buffer to accumulate per-layer retrieval results
        self._buffered_layer_results = [] 

        if os.path.exists(self.filename):
            print(f"Retrieval log file {self.filename} exists. It will be overwritten.")
        else:
            print(f"Creating new retrieval log file: {self.filename}")

    @staticmethod
    def get_instance():
        if RetrievalLogger._instance is None:
            RetrievalLogger()
        return RetrievalLogger._instance

    def log_encoding_similarity(self, frame_idx, max_similarity, assigned_cluster_idx):
        """Log the maximum similarity score for each frame during the encoding (clustering) phase."""
        if not self._initialized: return
        self.stats["encoding_log"].append({
            "frame_index": frame_idx,
            "max_similarity": max_similarity,
            "assigned_cluster_index": assigned_cluster_idx
        })

    def buffer_layer_retrieval(self, layer_idx, similarities, retrieved_indices):
        """Buffer retrieval results from a single layer during the QA phase."""
        if not self._initialized: return
        
        sim_list = similarities.cpu().tolist() if isinstance(similarities, torch.Tensor) else similarities
        
        self._buffered_layer_results.append({
            "layer_index": layer_idx,
            "query_cluster_similarities": sim_list,
            "retrieved_frame_indices": retrieved_indices
        })

    def log_qa_retrieval(self, question_text):
        """Flush the per-layer buffer and record a complete QA retrieval entry."""
        if not self._initialized: return
        if not self._buffered_layer_results:
            # Do not record an empty entry if no layers were buffered for some reason
            return
            
        self.stats["qa_log"].append({
            "question": question_text,
            "per_layer_results": self._buffered_layer_results
        })
        # Reset the buffer for the next QA turn
        self._buffered_layer_results = []

    def log_final_cluster_state(self, retrieval_manager):
        """Record the final cluster state at the end of frame encoding."""
        if not self._initialized or not retrieval_manager.strategy.startswith('clustering'):
            return
        
        # Record the cluster state for the first batch item as a representative sample
        clusters_data = []
        clusters_for_unit0 = retrieval_manager.cluster_members[0]
        for i, members in enumerate(clusters_for_unit0):
            clusters_data.append({
                "cluster_index": i,
                "num_frames": len(members),
                "frame_indices": sorted(members)
            })

        self.stats["final_cluster_state"]["total_clusters"] = len(clusters_data)
        self.stats["final_cluster_state"]["clusters"] = clusters_data

    def write_log(self):
        """Write all accumulated log data to the output file."""
        if not self._initialized:
            print("Warning: RetrievalLogger not set up. Cannot write log.")
            return
            
        try:
            with open(self.filename, 'w') as f:
                json.dump(self.stats, f, indent=4)
        except Exception as e:
            print(f"Error writing retrieval log to {self.filename}: {e}")
