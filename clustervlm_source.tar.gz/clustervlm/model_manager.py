# model_manager.py
"""
Model Manager (Singleton)
- Centrally loads and manages all deep learning models, ensuring each model
  has exactly one instance in memory.
- Uses a thread-safe lazy-loading pattern: models are loaded only on first request.
- Conserves GPU memory and improves resource utilization.
"""

import logging
import torch
import threading
from transformers import (
    AutoProcessor, 
    AutoConfig,
    CLIPProcessor, 
    CLIPModel,
    LlavaOnevisionForConditionalGeneration
)

logger = logging.getLogger(__name__)

class ModelManager:
    """
    A singleton class for centralized model instance management.
    """
    _instance = None
    _lock = threading.Lock()

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            with cls._lock:
                if not cls._instance:
                    cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not hasattr(self, 'initialized'):
            self.models = {}
            self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
            self.initialized = True
            logger.info(f"✅ ModelManager initialized on device: {self.device}")

    def _load_model(self, model_key: str, load_func, *args, **kwargs):
        with self._lock:
            if model_key not in self.models:
                logger.info(f"🔍 Model cache miss for key: '{model_key}'. Loading model...")
                try:
                    self.models[model_key] = load_func(*args, **kwargs)
                    logger.info(f"✅ Model '{model_key}' loaded and cached successfully.")
                except Exception as e:
                    logger.error(f"❌ Failed to load model for key '{model_key}': {e}", exc_info=True)
                    self.models[model_key] = None
            else:
                logger.info(f"✅ Model cache hit for key: '{model_key}'. Reusing existing instance.")
        
        if self.models[model_key] is None:
            raise RuntimeError(f"Model '{model_key}' failed to load previously and is unavailable.")
            
        return self.models[model_key]

    def _load_clip_model(self, model_path: str):
        logger.info(f"Loading CLIP from {model_path}...")
        model = CLIPModel.from_pretrained(model_path).to(self.device).eval()
        processor = CLIPProcessor.from_pretrained(model_path)
        return model, processor

    def _load_llava_onevision_model(self, model_path: str, attn_implementation: str):
        """Private loader for LLaVA-OneVision model."""
        logger.info(f"Loading LLaVA-OneVision from {model_path}...")
        config = AutoConfig.from_pretrained(model_path)
        model = LlavaOnevisionForConditionalGeneration.from_pretrained(
            model_path,
            config=config,
            torch_dtype=torch.float16,
            attn_implementation=attn_implementation,
            device_map="auto"
        ).eval()
        processor = AutoProcessor.from_pretrained(model_path)
        return model, processor

    def get_clip_model(self, model_path: str):
        """Get CLIP model and processor."""
        return self._load_model(
            model_key=f"clip_{model_path}",
            load_func=self._load_clip_model,
            model_path=model_path
        )

    def get_llava_onevision_model(self, model_path: str, attn_implementation: str = "flash_attention_2"):
        """Get LLaVA-OneVision model and processor."""
        key = f"llava_onevision_{model_path}_{attn_implementation}"
        return self._load_model(
            model_key=key,
            load_func=self._load_llava_onevision_model,
            model_path=model_path,
            attn_implementation=attn_implementation
        )

# Global singleton instance
model_manager = ModelManager()
