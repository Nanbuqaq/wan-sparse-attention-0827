import torch
import random
import numpy as np
import time
from PIL import Image
from typing import List, Optional

# [Phase 2] Qwen2.5-VL dependencies
from transformers import Qwen2_5_VLForConditionalGeneration, Qwen2_5_VLProcessor, Qwen2_5_VLConfig
from transformers.models.qwen2_5_vl.modeling_qwen2_5_vl import Qwen2_5_VLVisionConfig

from logzero import logger

from clustervlm.patch import patch_hf
from clustervlm.abstract_clustervlm import AbstractClusterVLM
from clustervlm.timing import TimingStats
from clustervlm.retrieval_logger import RetrievalLogger
from clustervlm.profiler import Profiler

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    logger.info(f"Set Seed={seed}")

# Call before loading the model
set_seed(2025)

class Qwen2_5_VL_ClusterVLM(Qwen2_5_VLForConditionalGeneration, AbstractClusterVLM):
    """
    Qwen2.5-VL adaptation of ClusterVLM.
    Core strategy: Fixed Resolution (392x392) -> 196 tokens per frame (14x14 grid),
    which allows reuse of ClusterVLM's fixed-length chunk retrieval logic.
    """
    def __init__(self, config, n_frame_tokens, init_prompt_ids, n_local, topk, chunk_size,
                 processor=None,  # Allow late injection via load_model
                 external_model_path=None, external_model_type='clip',
                 pixel_similarity_threshold=1.0
                 ):
        
        Qwen2_5_VLForConditionalGeneration.__init__(self, config)
        
        # processor may be None here; it will be injected later in load_model
        AbstractClusterVLM.__init__(self, processor, n_frame_tokens, init_prompt_ids, n_local, topk, chunk_size,
                               external_model_path=external_model_path,
                               external_model_type=external_model_type,
                               pixel_similarity_threshold=pixel_similarity_threshold
                               )

        # Explicitly cache n_init for use by question_answering (init_prompt_ids is List[int])
        self.n_init = len(init_prompt_ids) if init_prompt_ids is not None else 0

        self.stats_manager = TimingStats.get_instance()
        self.retrieval_logger = RetrievalLogger.get_instance()
        
        # [Phase 2] Qwen2.5-VL specific: force resize to produce exactly 196 tokens per frame
        self.force_resize_size = 392 # 392 = 14 * 28 (Patch * Stride) -> 14x14 Grid
        logger.info(f"[Qwen2.5-VL ClusterVLM] Initialized with Fixed Resolution Strategy: {self.force_resize_size}x{self.force_resize_size}")


    def finalize_logging(self):
        """
        Call after all video encoding and QA rounds to log the final cluster state and flush to disk.
        """
        print("Finalizing and writing logs...")
        if self.kv_cache and hasattr(self.kv_cache[0], 'retrieval_manager'):
            try:
                from clustervlm.attention.kv_cache_manager import CONTEXT_MANAGER_INSTANCE_COUNTER
                globals()['CONTEXT_MANAGER_INSTANCE_COUNTER'] = 0
            except ImportError:
                 print("Warning: Could not reset CONTEXT_MANAGER_INSTANCE_COUNTER.")
            retrieval_manager = self.kv_cache[0].retrieval_manager
            self.retrieval_logger.log_final_cluster_state(retrieval_manager)
        
        self.retrieval_logger.write_log()
        self.stats_manager.write_stats()
        print(f"Logs written to {self.retrieval_logger.filename} and {self.stats_manager.filename}")

    def get_prompt(self, query, mc=False):
        # Strict alignment with the Qwen2.5-VL official prompt format:
        # 1. <|vision_end|>: close the vision_start opened in init_prompt
        # 2. {query}: user question
        # 3. <|im_end|>: end of user turn
        # 4. <|im_start|>assistant\n: open assistant turn
        # Note: do NOT prepend <|im_start|>user again — init_prompt already contains it.
        prompt = f"<|vision_end|>{query}<|im_end|>\n<|im_start|>assistant\n"
        
        if mc:
            prompt += 'Best option: ('
        return prompt

    def _get_video_features(self, pixel_values_videos, video_grid_thw):
        """
        Override visual feature extraction. Qwen2.5-VL requires grid_thw parameters.
        """
        # Calls Qwen2_5_VLForConditionalGeneration.get_video_features internally;
        # it invokes the visual module and handles split merging.
        video_embeds = super().get_video_features(
            pixel_values_videos=pixel_values_videos,
            video_grid_thw=video_grid_thw
        )
        # Qwen2.5 returns List[Tensor] (one per video segment); concat back to a single tensor.
        # Since we process one chunk at a time, there is normally only one segment.
        video_features = torch.cat(video_embeds, dim=0) 
        
        return video_features

    def _encode_video_chunk(self, video_chunk):
        """
        Override encoding logic to accommodate Qwen2.5-VL's dynamic-resolution input.
        Pipeline: Manual Resize -> Processor -> Feature Extraction -> LLM Forward
        """
        # video_chunk: (Frames, H, W, C) numpy array or tensor
        
        # 1. [Phase 2] Preprocessing and Force Resize (CPU)
        with Profiler.get_instance().timer("Enc: Preprocessing (Resize)", "cpu"):
            
            # Convert input to PIL Image list and force-resize to 392x392
            pil_images = []
            if isinstance(video_chunk, torch.Tensor):
                video_chunk = video_chunk.cpu().numpy()
            
            for frame in video_chunk:
                # Input assumed to be (H, W, 3) uint8
                img = Image.fromarray(frame.astype('uint8'))
                # Force resize to ensure exactly 196 tokens per frame
                img_resized = img.resize((self.force_resize_size, self.force_resize_size), resample=Image.BICUBIC)
                
                pil_images.append(img_resized)

            
            # Call processor: pass videos=[pil_images] so it treats them as a single video.
            # Pass text=[" "] (a dummy space) to satisfy the processor's internal checks
            # without triggering video-token replacement logic.
            inputs = self.processor(
                text=[" "], 
                videos=[pil_images], 
                padding=True, 
                return_tensors="pt"
            )

            pixel_values_videos = inputs["pixel_values_videos"].to(self.device, self.dtype)
            video_grid_thw = inputs["video_grid_thw"].to(self.device)


            # print(f"[ClusterVLM Node 2.1: Pixel Values] Shape: {pixel_values_videos.shape}, Mean: {pixel_values_videos.mean().item():.6f}, Sum: {pixel_values_videos.sum().item():.2f}")
            # print(f"[ClusterVLM Node 2.2: Grid THW] Value: {video_grid_thw.tolist()}")

        # 2. Vision encoding (Vision Tower Forward)
        with Profiler.get_instance().timer("Enc: Vision Encoder (GPU)", "compute"):
            # Qwen2.5-VL requires grid_thw to compute 3D RoPE
            video_features = self._get_video_features(pixel_values_videos, video_grid_thw)
            
            # print(f"[ClusterVLM Node 3: Vision Features] Shape: {video_features.shape}, Mean: {video_features.mean().item():.6f}, Sum: {video_features.sum().item():.2f}")
            # if video_features.dim() == 2:
            #     print(f"   => Slice [:5]: {video_features[0, :5].tolist()}")
            # else:
            #     print(f"   => Slice [0, 0, :5]: {video_features[0, 0, :5].tolist()}")

            # Qwen2.5-VL typically outputs 2D (Total_Tokens, Dim);
            # ClusterVLM requires 3D (Batch, Total_Tokens, Dim).
            if video_features.dim() == 2:
                video_features = video_features.unsqueeze(0)
            
            # Now guaranteed to be 3D; safe to unpack
            B, L, D = video_features.shape

        assert self.n_local >= video_features.shape[1], f'n_local: {self.n_local}, video_features: {video_features.shape[1]}'

        # External Encoder (CLIP) or built-in ViT path
        external_model_type = getattr(self, "external_model_type", "clip")
        
        if external_model_type == 'llmvit':
            with Profiler.get_instance().timer("Enc: Built-in Vision Extractor", "compute"):
                # Qwen2.5-VL applies temporal_patch_size=2 downsampling (3D Conv3d).
                # Back-calculate the actual output block count (Nv_out) from n_frame_tokens.
                tokens_per_frame = self.n_frame_tokens 
                Nv_out = video_features.shape[1] // tokens_per_frame
                
                # (B, Nv_out, 196, D) -> (B, Nv_out, D): mean-pool tokens to get per-frame feature
                frame_level_embeds = video_features.view(B, Nv_out, tokens_per_frame, D).mean(dim=2)
                
                # Expand to match the downstream token-level slicing
                external_embeddings = frame_level_embeds.unsqueeze(2).expand(B, Nv_out, tokens_per_frame, D)
                external_embeddings = external_embeddings.reshape(B, -1, D)
                
                if self.kv_cache is not None:
                    for layer_past in self.kv_cache:
                        if hasattr(layer_past, 'update_external_embeddings'):
                            layer_past.update_external_embeddings(external_embeddings)
        else:
            self._ensure_external_encoder()
            if self.external_encoder:
                with Profiler.get_instance().timer("Enc: External Encoder", "compute"):
                    external_embeddings = self.external_encoder.encode_frames(video_chunk) # (B, Nv, D_ext)
                    
                    # Align CLIP feature count with LLM output block count
                    tokens_per_frame = self.n_frame_tokens
                    Nv_out = video_features.shape[1] // tokens_per_frame
                    B, Nv, D_ext = external_embeddings.shape
                    
                    # If 3D temporal downsampling occurred (Nv != Nv_out),
                    # use adaptive avg-pooling to losslessly align CLIP features with LLM
                    if Nv != Nv_out:
                        import torch.nn.functional as F
                        # (B, Nv, D_ext) -> (B, D_ext, Nv) -> pool -> (B, D_ext, Nv_out) -> (B, Nv_out, D_ext)
                        external_embeddings = external_embeddings.permute(0, 2, 1)
                        external_embeddings = F.adaptive_avg_pool1d(external_embeddings, Nv_out)
                        external_embeddings = external_embeddings.permute(0, 2, 1)
                    
                    external_embeddings = external_embeddings.unsqueeze(2).expand(B, Nv_out, tokens_per_frame, D_ext)
                    external_embeddings = external_embeddings.reshape(B, -1, D_ext)
                    
                    if self.kv_cache is not None:
                        for layer_past in self.kv_cache:
                            if hasattr(layer_past, 'update_external_embeddings'):
                                layer_past.update_external_embeddings(external_embeddings)

        # 3. LLM full forward pass
        with Profiler.get_instance().timer("Enc: LLM Forward (Total)", "compute"):
            # Qwen2.5-VL forward requires video_grid_thw to compute RoPE,
            # even when inputs_embeds is provided.
            output = self.language_model(
                inputs_embeds=video_features,
                past_key_values=self.kv_cache,
                use_cache=True,
                return_dict=True,
                video_grid_thw=video_grid_thw  # Required by Qwen2.5-VL for RoPE
            )
        
        self.kv_cache = output.past_key_values

    def _get_valid_anchor_indices(self):
        """Extract the raw frame indices of currently stored Global Anchors from the KV-cache manager."""
        if (self.kv_cache is not None and len(self.kv_cache) > 0 and 
            hasattr(self.kv_cache[0], 'retrieval_manager')):
            
            mgr = self.kv_cache[0].retrieval_manager
            # anchor_block_indices shape: (Batch, Max_Anchors)
            if mgr.anchor_block_indices is not None:
                # Take batch 0; filter out -1 (empty slots)
                valid_mask = mgr.anchor_block_indices[0] != -1
                return mgr.anchor_block_indices[0][valid_mask].tolist()
        return []

    def _generate_3d_ids(self, anchor_indices: List[int], retrieved_indices: List[int], text_length: int, past_text_length: int):
        """
        Generate full 3D position IDs for: [Anchors] + [Retrieved] + [Text].
        Must align strictly with the token layout produced by ContextManager.
        """
        ids_list = []
        tokens_per_frame = 196  # 392x392
        
        # Precompute 14x14 spatial grid coordinates
        grid_h = torch.arange(14, device=self.device).view(14, 1).expand(14, 14).flatten()
        grid_w = torch.arange(14, device=self.device).view(1, 14).expand(14, 14).flatten()
        
        # Helper: generate 3D position IDs for a sequence of frame indices
        def make_frame_ids(indices):
            f_ids = []
            for t_idx in indices:
                # Safety guard: coerce nested sequences to scalar
                if isinstance(t_idx, (list, tuple, torch.Tensor)):
                    try:
                        t_val = int(t_idx)
                    except:
                        continue  # Skip malformed entries
                else:
                    t_val = t_idx
                
                t_ids = torch.full((tokens_per_frame,), t_val, dtype=torch.long, device=self.device)
                f_ids.append(torch.stack([t_ids, grid_h, grid_w], dim=0))
            return f_ids

        # 1. Video Anchors
        if len(anchor_indices) > 0:
            ids_list.extend(make_frame_ids(anchor_indices))
            
        # 2. Video Retrieved Blocks (Middle Part)
        if len(retrieved_indices) > 0:
            # Note: ContextManager concatenates Anchor and Retrieved directly without deduplication;
            # we mirror that behavior here.
            ids_list.extend(make_frame_ids(retrieved_indices))

        # 3. Text (tail section)
        # Text IDs follow all video tokens to maintain monotonic position ordering.
        # Offset = (num_anchors + num_retrieved) * 196 + accumulated text from past turns.

        # Compute text start offset
        video_token_count = (len(anchor_indices) + len(retrieved_indices)) * tokens_per_frame
        
        # text_start = total_video_tokens + past_text_length (accumulated from multi-turn history)
        absolute_start = video_token_count + past_text_length
        
        if text_length > 0:
            text_pos = torch.arange(absolute_start, absolute_start + text_length, device=self.device)
            text_ids = torch.stack([text_pos, text_pos, text_pos], dim=0)
            ids_list.append(text_ids)

        if not ids_list:
            return None
            
        return torch.cat(ids_list, dim=1).unsqueeze(1)

    def _get_retrieved_indices(self):
        """Return the retrieved block indices from Layer 0 (Batch 0)."""
        if self.kv_cache and len(self.kv_cache) > 0:
            indices = self.kv_cache[0].retrieved_block_indices
            if indices is None:
                return []
            
            # Case 1: Tensor
            if isinstance(indices, torch.Tensor):
                if indices.dim() >= 2:  # (Batch, Num_Blocks) -> take Batch 0
                    return indices[0].cpu().tolist()
                return indices.cpu().tolist()  # 1D: convert directly
            
            # Case 2: List
            if isinstance(indices, list):
                if len(indices) == 0:
                    return []
                if isinstance(indices[0], list):  # nested [[0, 1, 2]]: take Batch 0
                    return indices[0]
                if isinstance(indices[0], torch.Tensor):
                    if indices[0].dim() > 0:
                         return indices[0].tolist()
                    else:
                         return [x.item() for x in indices]
                return indices  # Already a flat list
                
        return []

    def _get_video_boundary(self, force_max_retrieval=False):
        """
        Compute the video token boundary (total video tokens in context).
        force_max_retrieval: if True (Prefill phase), assume topk blocks have been retrieved.
        """
        # 1. Determine retrieved block count
        retrieved_cnt = 0
        
        if force_max_retrieval:
            # Prefill phase: anticipate that the upcoming Forward will fill topk slots
            retrieved_cnt = self.topk
        elif self.kv_cache and self.kv_cache[0].retrieved_block_indices is not None:
            # Decoding phase: read actual retrieved state
            indices = self.kv_cache[0].retrieved_block_indices
            if isinstance(indices, torch.Tensor):
                retrieved_cnt = indices.shape[-1]
                if indices.dim() == 2: retrieved_cnt = indices.shape[1]
            elif isinstance(indices, list):
                if len(indices) > 0 and isinstance(indices[0], list): 
                    retrieved_cnt = len(indices[0])
                else:
                    retrieved_cnt = len(indices)
        else:
            retrieved_cnt = self.topk

        # 2. Total video tokens (anchors are NOT counted here)
        total_video_tokens = retrieved_cnt * 196
        
        # Debug Log
        logger.info(f"[Video Boundary Fix] Retrieved={retrieved_cnt}, Boundary={total_video_tokens}")
        
        return total_video_tokens

    @torch.inference_mode()
    def question_answering(self, input_text, max_new_tokens=128, retrieved_indices=None):
        TimingStats.get_instance().start_qa()
        device = self.device
        
        stop_token_ids = [self.processor.tokenizer.eos_token_id]
        if hasattr(self.generation_config, "eos_token_id"):
             if isinstance(self.generation_config.eos_token_id, list):
                 stop_token_ids.extend(self.generation_config.eos_token_id)
             else:
                 stop_token_ids.append(self.generation_config.eos_token_id)

        # 1. Encode query: External encoder (CLIP) or built-in LLM text embedding
        question_text = input_text['question']
        external_query = None
        external_model_type = getattr(self, "external_model_type", "clip")
        
        if external_model_type == 'llmvit':
            with torch.inference_mode():
                # Use the LLM's own text embedding as the external query
                query_input_ids = self.processor.tokenizer(question_text, return_tensors="pt").input_ids.to(device)
                query_embeds = self.get_input_embeddings()(query_input_ids)
                # (1, L, D) -> (1, 1, D): mean-pool to sentence vector
                external_query = query_embeds.mean(dim=1, keepdim=True)
        else:
            # Use CLIP encoder
            self._ensure_external_encoder()
            if self.external_encoder:
                external_query = self.external_encoder.encode_text([question_text])
        
        # Activate retrieval mode for all layers
        for layer_kv in self.kv_cache:
            layer_kv.set_retrieval()
            if external_query is not None and hasattr(layer_kv, 'update_external_embeddings'):
                layer_kv.update_external_embeddings(external_query)

        self.retrieval_logger.log_qa_retrieval(question_text)

        # Build a clean question-only prompt (system + video are already in the KV cache).
        question_prompt = f"<|vision_end|>\n{input_text['prompt'].split('<|vision_end|>')[-1]}"


        output_ids =[]
        stopped = False
        past_key_values = self.kv_cache
        
        for i in range(max_new_tokens):
            if i == 0:
                # Prefill: this forward triggers ContextManager retrieval and generates the first token
                input_ids = self.processor.tokenizer(question_prompt, return_tensors="pt").input_ids.to(device)

                # print(f"[ClusterVLM Node 2.3: Input IDs] Shape: {input_ids.shape}, First 20: {input_ids[0, :20].tolist()}, Last 20: {input_ids[0, -20:].tolist()}")


                inputs_embeds = self.get_input_embeddings()(input_ids)
                
                out = self.language_model(
                    inputs_embeds=inputs_embeds, 
                    use_cache=True, 
                    past_key_values=past_key_values,
                    external_embeddings=external_query 
                )
                past_key_values = out.past_key_values
                
                if hasattr(out, 'logits'): logits = out.logits
                else: logits = self.lm_head(out.last_hidden_state).float()
                

  
                TimingStats.get_instance().record_first_token()

            else:
                # [Decoding]
                curr_input_ids = torch.as_tensor([[token]], device=device)
                out = self.language_model(
                    input_ids=curr_input_ids,
                    use_cache=True,
                    past_key_values=past_key_values,
                )
                past_key_values = out.past_key_values
                if hasattr(out, 'logits'): logits = out.logits
                else: logits = self.lm_head(out.last_hidden_state).float()

            last_token_logits = logits[0, -1, :]
            _, indices = torch.topk(last_token_logits, 2)
            token = int(indices[0])

            output_ids.append(token)
            if token in stop_token_ids: stopped = True
            if i == max_new_tokens - 1 or stopped: break

        for layer_kv in self.kv_cache:
            layer_kv.reset_retrieval()

        output = self.processor.tokenizer.decode(
            output_ids, skip_special_tokens=True, clean_up_tokenization_spaces=True
        )
        
        actual_generated = i + 1
        TimingStats.get_instance().end_qa(generated_tokens_count=actual_generated)
        # Flush stats after each QA to prevent data loss on crash
        TimingStats.get_instance().write_stats()


        print("Generating Profile...")
        Profiler.get_instance().print_stats()
        Profiler.get_instance().export("stage1_trace.json")

        return output
    
def load_model(model_path, n_init=None, n_local=None, topk=64, chunk_size=1):
    device = 'cuda'
    
    # [Phase 2] Qwen2.5-VL fixed resolution configuration
    # Resolution: 392x392 | Patch: 14 | Merge: 2x2 (stride 28) | Grid: 14x14 = 196 tokens
    n_frame_tokens = 196 
    
    logger.info(f"Loading Qwen2.5-VL from {model_path}...")
    
    # 1. Load Processor (default, not fast — ClusterVLM requires stability over speed)
    processor = Qwen2_5_VLProcessor.from_pretrained(model_path, min_pixels=392*392, max_pixels=392*392)
    
    # 2. Build system prompt token IDs
    # Structure: System... -> User start -> Vision start -> (afterwards ClusterVLM will fill video)
    init_prompt = '<|im_start|>system\nYou are a helpful assistant.<|im_end|>\n<|im_start|>user\n<|vision_start|>'
    # Use plain Python list (not a Tensor) to avoid JSON serialization errors in from_pretrained
    init_prompt_ids = processor.tokenizer(init_prompt).input_ids 


    # 3. Configure ClusterVLM parameters
    inf_llm_config = {
        # init_prompt_ids is now a Python list, so use len()
        'n_init': len(init_prompt_ids) if n_init is None else n_init,

        'n_local': 13720,  # Recommended: smaller when Anchors are enabled; up to 15000 otherwise
        'fattn': True,
        'block_size': n_frame_tokens,
        'topk': topk,
        'chunk_size': chunk_size,

        # Encoding enhancement config (Global Anchors)
        # Options: 'default' (original logic) or 'cluster_global_anchors'
        'encoding_strategy': 'cluster_global_anchors', 
        
        # Anchor parameters
        'max_anchors': 64,  # How many Global Anchors to retain
        'anchor_selection_method': 'closest_to_centroid',  # 'closest_to_centroid' or 'random'
        'anchors_per_cluster': 1,

        # Alternative retrieval strategies: 'chunking', 'clustering', 'clustering_weighted'
        # 'clustering' = simple mean-pooling cluster; 'clustering_weighted' = attention-weighted
        'retrieval_strategy': 'external_internal',

        # External + Internal retrieval method:
        # 'hierarchical': strict EC -> IC quota-based selection
        # 'global_sort':  select Top-K ECs, then rank all their frames globally by Internal similarity
        # 'IC_sort':      select Top-K ECs, then rank all their ICs globally by Internal similarity
        'external_internal_retrieve_method': 'IC_sort',

        # External encoder configuration (CLIP or built-in ViT)
        'external_threshold': 0.7,
        'external_variance_threshold': 1,
        'topk_external': 64,
        'external_model_path': None,  # None = use built-in ViT
        'external_model_type': 'llmvit',  # 'clip' or 'llmvit'
        
        'max_frames_per_external': 64,  # Max frames per EC
        'max_frames_per_internal': 64,  # Max frames per IC
        
        # Internal Configure
        'cluster_threshold': 0.6,
        'variance_threshold': 0.001,



        # ================= System efficiency optimization =================
        # [P0: Global linear storage] When enabled, data is in GlobalLinearStorage (O(1) access)
        'enable_cluster_storage': False, 

        # [P1: GPU-vectorized clustering] When enabled, K-Means and split index ops run on GPU
        'enable_gpu_clustering': False,


        # [P2: I/O-computation overlap pipeline]
        'enable_fast_io': True,
        'enable_pipeline': True,
        'prefetch_factor': 1.0,  # Superset prefetch factor (1.0 = exact topk)

        # [Batch-oriented execution] Greatly reduces CPU-GPU scheduling stalls during encoding
        'enable_batch_clustering': True,
        
        # [Deferred split (lazy split)] Defers cluster splits within a batch to reduce overhead
        # True: one deferred pass (cuts ~80% of redundant K-Means checks)
        # False: immediate per-frame splits (strict Markov causality)
        'enable_lazy_split': True,
        'enable_cluster_lru': True,
        
        # Set to 1.0 to disable; set to 0.95 to discard near-duplicate consecutive frames
        'pixel_similarity_threshold': 1,

        # clustervlm_attention.pyupdate_kv_cache in
        'clustervlm_attention_update_kv_cache': True,

        # Controls GPU cache block limit; higher = better hit rate but more VRAM
        # 'max_cached_block': max(topk, 64),
        'max_cached_block': max(topk * 8, 512),
        'exc_block_size': n_frame_tokens,
        'pin_memory': True,

        # Cluster-uniform sampling (alternative retrieval method)
        'use_cluster_sampling': False,  # Enable cluster-aware uniform sampling
        'frames_per_cluster': 6,         # Max frames sampled per cluster
    }

    logger.info("ClusterVLM Inference LLM Config:")
    logger.info("-" * 40)
    for key, value in inf_llm_config.items():
        logger.info(f"{key}: {value}")
    logger.info("-" * 40)

    strategy = inf_llm_config.get('retrieval_strategy', 'chunking')
    threshold = inf_llm_config.get('cluster_threshold')
    
    stats_filename = f"timing_qwen25_{strategy}.json"
    retrieval_log_filename = f"retrieval_log_qwen25_{strategy}.json"
    inf_llm_config['stats_filename'] = stats_filename
    inf_llm_config['retrieval_log_filename'] = retrieval_log_filename
    
    # Initialize timing and retrieval loggers
    stats_filename = "timing_qwen25vl.json"
    TimingStats.get_instance().setup(filename=stats_filename)
    RetrievalLogger.get_instance().setup(filename=retrieval_log_filename, strategy=strategy, threshold=threshold)
    
    # 4. Load model
    model = Qwen2_5_VL_ClusterVLM.from_pretrained(
        model_path, 
        device_map="auto",
        torch_dtype=torch.bfloat16,  # Qwen2.5-VL recommended dtype
        # ClusterVLM Params
        # processor is NOT passed to from_pretrained (avoids JSON serialization errors)

        n_frame_tokens=n_frame_tokens,
        init_prompt_ids=init_prompt_ids,
        n_local=inf_llm_config['n_local'],
        topk=topk,
        chunk_size=chunk_size,
        external_model_path=inf_llm_config['external_model_path'],
        external_model_type=inf_llm_config.get('external_model_type', 'clip'), 
        pixel_similarity_threshold=inf_llm_config['pixel_similarity_threshold']
    )

    # Manually inject processor after from_pretrained (bypasses serialization check)
    model.processor = processor
    if hasattr(model, "processor"):
        model.processor = processor
    
    # 5. Patch model in-place (do NOT reassign to a submodule to avoid circular references)
    patch_hf(model, **inf_llm_config)
    
    logger.info(f"Qwen2.5-VL ClusterVLM Model Loaded. Block Size: {n_frame_tokens}")
    model.eval()

    return model, processor
