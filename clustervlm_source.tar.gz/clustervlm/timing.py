# timing.py

import time
import json
import torch  # Required for accurate GPU synchronization

class TimingStats:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(TimingStats, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def setup(self, filename="simple_timing_stats.json"):
        if self._initialized:
            return
        
        self.filename = filename
        self.all_records = []
        self.current_video_stat = None
        self._t_start = 0
        
        self._initialized = True
        print(f"[TimingStats] Logging to: {self.filename}")

    @staticmethod
    def get_instance():
        if TimingStats._instance is None:
            TimingStats()
        return TimingStats._instance

    def _archive_current_video(self):
        if self.current_video_stat is not None:
            self.all_records.append(self.current_video_stat)
            self.write_stats() 
            self.current_video_stat = None

    # ================= Phase 1: Frame Encoding =================
    # Supports cumulative timing for the streaming scenario.
    def start_new_video(self):
        """Declare the start of a new video."""
        self._archive_current_video()
        self.current_video_stat = {
            "encoding_time_s": 0.0,  # Initialized to 0; accumulated incrementally
            "queries": []
        }

    def start_video_encoding(self):
        if self.current_video_stat is None:
            self.start_new_video()
        # Synchronize GPU before starting the timer
        if torch.cuda.is_available(): torch.cuda.synchronize()
        self._t_start = time.perf_counter() 

    def end_video_encoding(self):
        if self.current_video_stat is not None:
            if torch.cuda.is_available(): torch.cuda.synchronize()
            duration = time.perf_counter() - self._t_start
            # Accumulate instead of overwrite to handle multi-chunk streaming encoding
            self.current_video_stat["encoding_time_s"] += duration

    # ================= Phase 2: Query Retrieval (Key Latency Metric) =================
    def start_qa(self):
        # Must synchronize GPU to establish a fair start time
        if torch.cuda.is_available(): torch.cuda.synchronize()
        self._t_qa_start = time.perf_counter()
        self._t_first_token = 0

    def record_first_token(self):
        """Record the moment the first output token is generated (used to compute TTFT)."""
        if torch.cuda.is_available(): torch.cuda.synchronize()
        self._t_first_token = time.perf_counter()

    def end_qa(self, generated_tokens_count=128):
        """End the QA phase and decompose into TTFT and per-token decoding time (TPOT)."""
        if torch.cuda.is_available(): torch.cuda.synchronize()
        t_end = time.perf_counter()
        
        if self.current_video_stat is not None:
            # 1. Time-to-First-Token (TTFT): covers all retrieval overhead
            ttft = self._t_first_token - self._t_qa_start if self._t_first_token > 0 else 0
            
            # 2. Total QA latency
            total_qa_time = t_end - self._t_qa_start
            
            # 3. Time-Per-Output-Token (TPOT): average decoding time per subsequent token
            decode_time = total_qa_time - ttft
            decode_tokens = max(generated_tokens_count - 1, 1)  # Guard against division by zero
            tpot = decode_time / decode_tokens if ttft > 0 else 0

            self.current_video_stat["queries"].append({
                "total_qa_time_s": total_qa_time,
                "TTFT_s": ttft,
                "TPOT_s": tpot,
                "generated_tokens": generated_tokens_count
            })

    # ================= Deprecated pipeline compatibility stubs =================
    def start_pipeline_wait(self): pass
    def end_pipeline_wait(self): pass

    # ================= File I/O =================
    def write_stats(self):
        try:
            data_to_write = self.all_records.copy()
            if self.current_video_stat:
                data_to_write.append(self.current_video_stat)
            with open(self.filename, 'w') as f:
                json.dump(data_to_write, f, indent=4)
        except Exception as e:
            print(f"[TimingStats] Write Error: {e}")

    def finalize(self):
        self._archive_current_video()
