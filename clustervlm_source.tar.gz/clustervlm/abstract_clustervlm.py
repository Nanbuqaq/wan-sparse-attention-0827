import torch
import numpy as np
from logzero import logger
from clustervlm.external_encoder import ExternalEncoder
from clustervlm.timing import TimingStats

from clustervlm.profiler import Profiler


class AbstractClusterVLM:
    processor = None
    kv_cache = None

    def __init__(self, processor, n_frame_tokens, init_prompt_ids, n_local, topk, chunk_size, 
                 external_model_path=None, external_model_type='clip',
                 pixel_similarity_threshold=1.0
                 ):
        self.processor = processor
        self.n_frame_tokens = n_frame_tokens
        self.init_prompt_ids = init_prompt_ids
        self.n_local = n_local
        self.topk = topk
        self.chunk_size = chunk_size
        
        self.external_encoder = None
        self.external_model_path = external_model_path
        self.external_model_type = external_model_type
            
        self.pixel_similarity_threshold = pixel_similarity_threshold
            
    def _ensure_external_encoder(self):
        if hasattr(self, 'external_model_path') and self.external_model_path and self.external_encoder is None:
             self.external_encoder = ExternalEncoder.get_instance(
                 self.external_model_path, 
                 self.device, 
                 self.external_model_type
             )

    def clear_cache(self):
        self.kv_cache = None
        torch.cuda.empty_cache()
        torch.cuda.ipc_collect()
        # Reset timing stats for the new video
        TimingStats.get_instance().start_new_video()

    @torch.inference_mode()
    def encode_init_prompt(self):
        self._ensure_external_encoder()
        if not isinstance(self.init_prompt_ids, torch.Tensor):
            self.init_prompt_ids = torch.as_tensor([self.init_prompt_ids], device=self.device)
        output = self.language_model(input_ids=self.init_prompt_ids, use_cache=True, return_dict=True)
        self.kv_cache = output.past_key_values

    def _get_video_features(self, pixel_values_videos):
        pass

    def _filter_video_frames(self, video, k=0.95):
        """
        GPU-accelerated pixel-level cosine similarity filter to discard near-duplicate frames.
        Uses frame-by-frame comparison to avoid OOM on long videos.
        When k >= 1.0, the filter is disabled and the original video is returned unchanged.
        """
        # Degenerate case: threshold >= 1.0 means no filtering
        if k >= 1.0:
            return video
            
        N = len(video)
        if N <= 1:
            return video
            
        kept_indices = [0]  # Always keep the first frame as the initial baseline
        
        # Helper closure: compute the L2-normalized flat vector for a given frame index
        def get_norm_vec(idx):
            frame = video[idx]
            if isinstance(frame, np.ndarray):
                t = torch.from_numpy(frame)
            else:
                t = frame
            # Move to GPU, flatten to 1D, cast to float for computation
            t_flat = t.to(self.device).float().view(-1)
            return torch.nn.functional.normalize(t_flat, p=2, dim=0)

        # Feature vector of the most recently retained frame
        last_kept_vec = get_norm_vec(0)
        
        for i in range(1, N):
            curr_vec = get_norm_vec(i)
            # Fast dot product = pixel-level cosine similarity
            sim = torch.dot(last_kept_vec, curr_vec).item()
            
            # Keep the frame if it differs sufficiently (potential scene change)
            if sim < k:
                kept_indices.append(i)
                last_kept_vec = curr_vec
                
        # Log pre-filtering statistics
        filtered_N = len(kept_indices)
        if filtered_N < N:
            logger.info(f"[Frame Filtering] Pixel-level pre-filter triggered (threshold={k}). "
                        f"Dropped {N - filtered_N} redundant frames. "
                        f"Retention: {filtered_N}/{N} ({filtered_N/N*100:.1f}%)")

        if isinstance(video, list):
            return [video[i] for i in kept_indices]
        else:
            return video[kept_indices]

    def _encode_video_chunk(self, video_chunk):
        # 1. Preprocessing (CPU Resize + Normalize)
        with Profiler.get_instance().timer("Enc: Preprocessing (CPU)", "cpu"):
            # Workaround for transformers >= 4.52.1:
            # The VideoProcessor skips normalization on 4D Tensor/Array inputs (bug),
            # but processes List[Array] correctly. Forcibly convert to List[np.ndarray].
            video_input = video_chunk
            if isinstance(video_chunk, torch.Tensor):
                video_input = list(video_chunk.cpu().numpy())
            elif isinstance(video_chunk, np.ndarray):
                video_input = list(video_chunk)
            
            inputs = self.processor.video_processor(video_input, return_tensors="pt")
            pixel_values_videos = inputs.pixel_values_videos.to(self.device, self.dtype)

        # 2. Vision encoding (Vision Encoder forward pass)
        with Profiler.get_instance().timer("Enc: Vision Encoder (GPU)", "compute"):
            video_features = self._get_video_features(pixel_values_videos)
        
        assert self.n_local >= video_features.shape[1], f'n_local: {self.n_local}, video_features: {video_features.shape[1]}'

        external_embeddings = None
        external_model_type = getattr(self, "external_model_type", "clip")
        
        if external_model_type == 'llmvit':
            with Profiler.get_instance().timer("Enc: Built-in Vision Extractor", "compute"):
                B = video_features.shape[0]
                D = video_features.shape[2]
                Nv = len(video_chunk) if isinstance(video_chunk, list) else video_chunk.shape[0]
                tokens_per_frame = video_features.shape[1] // Nv
                
                # (B, Nv, tokens_per_frame, D) -> (B, Nv, D) via mean pooling
                frame_level_embeds = video_features.view(B, Nv, tokens_per_frame, D).mean(dim=2)
                
                external_embeddings = frame_level_embeds.unsqueeze(2).expand(B, Nv, tokens_per_frame, D)
                external_embeddings = external_embeddings.reshape(B, -1, D) 
                
                if self.kv_cache is not None:
                    for layer_past in self.kv_cache:
                        if hasattr(layer_past, 'update_external_embeddings'):
                            layer_past.update_external_embeddings(external_embeddings)
        else:
            self._ensure_external_encoder()
            if self.external_encoder:
                with Profiler.get_instance().timer("Enc: External Encoder", "compute"):
                    external_embeddings = self.external_encoder.encode_frames(video_chunk)
                    B, Nv, D_ext = external_embeddings.shape
                    tokens_per_frame = video_features.shape[1] // Nv
                    external_embeddings = external_embeddings.unsqueeze(2).expand(B, Nv, tokens_per_frame, D_ext)
                    external_embeddings = external_embeddings.reshape(B, -1, D_ext) 
                    
                    # Inject external embeddings into ContextManagers
                    if self.kv_cache is not None:
                        for layer_past in self.kv_cache:
                            if hasattr(layer_past, 'update_external_embeddings'):
                                layer_past.update_external_embeddings(external_embeddings)
        
        # 3. LLM full forward pass (Attention + FFN + Linear)
        with Profiler.get_instance().timer("Enc: LLM Forward (Total)", "compute"):
            output = self.language_model(
                inputs_embeds=video_features, 
                past_key_values=self.kv_cache, 
                use_cache=True, 
                return_dict=True,
            )
        
        self.kv_cache = output.past_key_values

    @torch.inference_mode()
    def encode_video(self, video, encode_chunk_size=64):  # video: (Nv, H, W, 3)
        Profiler.get_instance().start()  # Reset profiler timer

        with Profiler.get_instance().timer("E2E: Encode Video", "top"):

            # Start recording video encoding time
            TimingStats.get_instance().start_video_encoding()
            
            # Pre-filter redundant frames at the source
            with Profiler.get_instance().timer("Enc: Pixel Level Filter", "cpu"):
                video = self._filter_video_frames(video, k=self.pixel_similarity_threshold)
            
            num_frames = video.shape[0]
            num_chunks = num_frames // encode_chunk_size
            for chunk_idx in range(num_chunks):
                start_idx = chunk_idx * encode_chunk_size
                end_idx = start_idx + encode_chunk_size
                chunk_video = video[start_idx:end_idx]
                with Profiler.get_instance().timer("E2E: Encode Chunk", "step"):
                    self._encode_video_chunk(chunk_video)
                logger.debug(f'KV-Cache RAM usage: {self.calc_memory_usage() / (1024**3):.1f} GB')
            remaining_frames = num_frames % encode_chunk_size
            if remaining_frames > 0:
                start_idx = num_chunks * encode_chunk_size
                end_idx = start_idx + remaining_frames
                remaining_video = video[start_idx:end_idx]
                with Profiler.get_instance().timer("E2E: Encode Chunk", "step"):
                    self._encode_video_chunk(remaining_video)
            logger.debug(f'KV-Cache RAM usage: {self.calc_memory_usage() / (1024**3):.1f} GB')
            
            # Post-encoding finalization: build GPU-resident index and warm up cache
            if self.kv_cache is not None:
                for layer_idx, layer in enumerate(self.kv_cache):
                    if hasattr(layer, 'retrieval_manager') and layer.retrieval_manager is not None:
                        # 1. Build the GPU-resident retrieval index (one-time)
                        layer.retrieval_manager._index_ready = False
                        layer.retrieval_manager._freeze_hierarchy_index()
                        
                        # 2. Warm up the GPU cache (one-time)
                        if layer.init_exc and getattr(layer, 'enable_pipeline', True):
                            u = 0  # Warm up only batch 0
                            mgr = layer.retrieval_manager
                            total_blocks = len(layer.global_blocks[u])
                            if total_blocks > 0:
                                # Reserve cache slots for QA-phase prefetch (default 0.0 = full warm-up).
                                reserve_ratio = getattr(layer, 'prefetch_reserve_ratio', 0.0)
                                reserve_ratio = max(0.0, min(0.95, reserve_ratio))
                                budget = layer.max_cached_block - int(layer.max_cached_block * reserve_ratio)
                                budget = max(1, budget)

                                final_warm_indices = []
                                if getattr(layer, 'enable_cluster_lru', False):
                                    # ==================================
                                    # Strategy A: Cluster-size-aware LRU warm-up
                                    # Prefer blocks belonging to smaller clusters (they are less likely
                                    # to be retrieved later and benefit most from being pre-cached).
                                    # ==================================
                                    frame_to_size = {}
                                    gpu_data = mgr._gpu_hierarchy[u] if mgr._gpu_hierarchy[u] is not None else None
                                    if gpu_data and 'frame_to_cluster_size' in gpu_data:
                                        frame_to_size = gpu_data['frame_to_cluster_size']

                                    scored_blocks = [(b_idx, frame_to_size.get(b_idx, 1)) for b_idx in range(total_blocks)]
                                    scored_blocks.sort(key=lambda x: x[1])

                                    warm_count = min(budget, total_blocks)
                                    smart_indices = [x[0] for x in scored_blocks[:warm_count]]
                                    head_tail = list(range(min(2, total_blocks))) + list(range(max(0, total_blocks-2), total_blocks))
                                    final_warm_indices = list(set(smart_indices + head_tail))[:budget]

                                else:
                                    # ==================================
                                    # Strategy B: Pure temporal LRU warm-up
                                    # Pre-load the most recent blocks into GPU cache.
                                    # ==================================
                                    warm_count = min(budget, total_blocks)
                                    head_count = 0
                                    tail_count = warm_count - head_count
                                    head_indices = list(range(head_count))
                                    tail_indices = list(range(total_blocks - tail_count, total_blocks))
                                    final_warm_indices = head_indices + tail_indices

                                # Physical pre-load (shared by both strategies)
                                for b_idx in final_warm_indices:
                                    unit = layer.global_blocks[u][b_idx]
                                    if unit.gpu_data is None and len(unit.cache.idle_set) > 0:
                                        g_data, g_id = unit.cache.alloc()
                                        g_data = g_data.view((2,) + unit.cpu_data[0].shape)
                                        g_data[0].copy_(unit.cpu_data[0], non_blocking=True)
                                        g_data[1].copy_(unit.cpu_data[1], non_blocking=True)
                                        unit.gpu_data = g_data
                                        unit.gpu_data_id = g_id
                                        unit.event = None
                                        
                                        layer.cached_blocks[u][b_idx] = 0
                                        if hasattr(layer, 'block_access_freq'):
                                            layer.block_access_freq[u][b_idx] = 1
                                            
                    # 3. Release temporary VRAM used by Global Anchors during encoding
                    if hasattr(layer, 'free_encoding_memory'):
                        layer.free_encoding_memory()
            
            torch.cuda.synchronize()

            # End video encoding time recording
            TimingStats.get_instance().end_video_encoding()

    @torch.inference_mode()
    def question_answering(self, input_text, max_new_tokens=128):
        pass

    def calc_memory_usage(self):
        n_layers = len(self.kv_cache)
        memory = n_layers * self.kv_cache[0].calculate_cpu_memory()
        return memory
