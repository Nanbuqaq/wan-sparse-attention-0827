import time
import torch
import json
import os
from collections import defaultdict
from logzero import logger

# Global profiling toggle.
# True  = enabled (records events and generates a trace)
# False = disabled (no-op; zero performance overhead; use when measuring accuracy)
ENABLE_PROFILING = True
logger.info(f"[Profiler] Global switch set to {'ENABLED' if ENABLE_PROFILING else 'DISABLED'}")

# No-op timer used when profiling is disabled to prevent AttributeErrors.
class DummyTimer:
    """A stub context manager that does nothing. Used when ENABLE_PROFILING is False."""
    def __enter__(self):
        return self
    def __exit__(self, exc_type, exc_val, exc_tb):
        pass

class Profiler:
    _instance = None
    
    @staticmethod
    def get_instance():
        if Profiler._instance is None:
            Profiler._instance = Profiler()
        return Profiler._instance

    def __init__(self):
        self.events = [] 
        self.enabled = True
        self.start_time_ref = time.time_ns()

    def start(self):
        if not ENABLE_PROFILING: return
        
        self.events = []
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        self.start_time_ref = time.time_ns()

    def timer(self, name, category="default"):
        """Return a scoped timer context manager, or a no-op if profiling is disabled."""
        if not ENABLE_PROFILING:
            return DummyTimer()
        return ScopeTimer(name, category, self)

    def export(self, filename="trace.json"):
        """
        Export events in Chrome Tracing format (.json).
        GPU events that would visually overlap are assigned separate track IDs.
        """
        if not ENABLE_PROFILING: 
            return

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        
        trace_events = []
        
        # Track map for GPU events: each unique event name gets its own row (TID).
        gpu_track_map = {} 
        gpu_track_counter = 0

        for evt in self.events:
            # 1. CPU event
            cpu_start_us = (evt['cpu_start'] - self.start_time_ref) / 1000.0
            cpu_dur_us = (evt['cpu_end'] - evt['cpu_start']) / 1000.0
            
            trace_events.append({
                "name": evt['name'],
                "cat": evt['cat'],
                "ph": "X",
                "ts": cpu_start_us,
                "dur": cpu_dur_us,
                "pid": 1,
                "tid": "Main Thread"
            })

            # 2. GPU event (only if timing data is available)
            if 'gpu_start' in evt:
                gpu_ms = evt['gpu_start'].elapsed_time(evt['gpu_end'])
                gpu_dur_us = gpu_ms * 1000.0
                
                # Ignore very short noise events.
                if gpu_dur_us > 1:
                    # Assign a unique TID per event name to avoid visual overlap.
                    evt_name = evt['name']
                    
                    if evt_name not in gpu_track_map:
                        gpu_track_map[evt_name] = gpu_track_counter
                        gpu_track_counter += 1
                    
                    track_id = gpu_track_map[evt_name]

                    trace_events.append({
                        "name": evt['name'],
                        "cat": "gpu",
                        "ph": "X",
                        "ts": cpu_start_us,
                        "dur": gpu_dur_us,
                        "pid": 1,
                        "tid": f"GPU Stream {track_id}" 
                    })

        with open(filename, 'w') as f:
            json.dump({"traceEvents": trace_events}, f)
        print(f"[Profiler] Trace exported to {os.path.abspath(filename)}")

    def print_stats(self):
        if not ENABLE_PROFILING:
            print("[Profiler] Profiling is DISABLED.")
            return

        if torch.cuda.is_available():
            torch.cuda.synchronize()
        stats = {}
        for evt in self.events:
            name = evt['name']
            if name not in stats:
                stats[name] = {'count': 0, 'cpu_sum': 0, 'gpu_sum': 0}
            stats[name]['count'] += 1
            stats[name]['cpu_sum'] += (evt['cpu_end'] - evt['cpu_start'])
            
            # Support pure-CPU timers that have no GPU events.
            if 'gpu_start' in evt:
                stats[name]['gpu_sum'] += evt['gpu_start'].elapsed_time(evt['gpu_end'])

        print(f"\n{'Name':<35} | {'Count':<6} | {'CPU (ms)':<10} | {'GPU (ms)':<10} | {'Gap':<10}")
        print("-" * 90)
        for name, s in sorted(stats.items(), key=lambda x: x[1]['cpu_sum'], reverse=True):
            print(f"{name:<35} | {s['count']:<6} | {s['cpu_sum']/1e6:<10.2f} | {s['gpu_sum']:<10.2f} | {(s['cpu_sum']/1e6 - s['gpu_sum']):<10.2f}")
        print("-" * 90)

class ScopeTimer:
    def __init__(self, name, category, profiler):
        self.name = name
        self.cat = category
        self.profiler = profiler
        self.gpu_start = torch.cuda.Event(enable_timing=True)
        self.gpu_end = torch.cuda.Event(enable_timing=True)

    def __enter__(self):
        self.cpu_start = time.time_ns()
        self.gpu_start.record()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.gpu_end.record()
        self.cpu_end = time.time_ns()
        self.profiler.events.append({
            "name": self.name, "cat": self.cat,
            "cpu_start": self.cpu_start, "cpu_end": self.cpu_end,
            "gpu_start": self.gpu_start, "gpu_end": self.gpu_end
        })
