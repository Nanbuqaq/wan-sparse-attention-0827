import torch
import numpy as np
from PIL import Image
from .model_manager import model_manager

class ExternalEncoder:
    _instance = None

    @classmethod
    def get_instance(cls, model_path=None, device="cuda", model_type="clip"):
        if cls._instance is None:
            if model_path is None:
                raise ValueError("ExternalEncoder not initialized. Please provide model_path for the first call.")
            cls._instance = cls(model_path, device, model_type)
        return cls._instance

    def __init__(self, model_path, device, model_type):
        self.device = device
        self.model_type = model_type
        self.processor = None
        
        print(f"Loading External Encoder ({model_type}) via ModelManager from {model_path} ...")
        
        if model_type == 'clip':
            # Get CLIP model and processor
            self.model, self.processor = model_manager.get_clip_model(model_path)
        else:
            raise ValueError(f"Unknown model_type: {model_type}")
        # TODO: gme model

    @torch.inference_mode()
    def encode_frames(self, frames):
        """
        Input: frames (N, H, W, 3) numpy/tensor or List[PIL.Image]
        Output: embeddings (1, N, Hidden_Dim)
        """
        # Uniformly convert input to List[PIL.Image]
        pil_images = []
        if isinstance(frames, (np.ndarray, torch.Tensor)):
            if isinstance(frames, torch.Tensor):
                frames = frames.cpu().numpy()
            for i in range(frames.shape[0]):
                img = Image.fromarray(frames[i].astype('uint8'))
                pil_images.append(img)
        elif isinstance(frames, list):
            for frame in frames:
                if isinstance(frame, Image.Image):
                    pil_images.append(frame)
                elif isinstance(frame, (np.ndarray, str)):
                    val = Image.fromarray(frame.astype('uint8')) if isinstance(frame, np.ndarray) else frame
                    pil_images.append(val)

        if self.model_type == 'clip':
            # CLIP inference: process images -> (B, 3, 224, 224)
            inputs = self.processor(images=pil_images, return_tensors="pt", padding=True).to(self.device)
            # Extract image features
            embeddings = self.model.get_image_features(**inputs)
            # L2 normalize
            embeddings = embeddings / embeddings.norm(p=2, dim=-1, keepdim=True)
        else:
            raise ValueError(f"Unknown model_type: {self.model_type}")

        # Reshape: (N, D) -> (1, N, D)
        if embeddings.dim() == 2:
            embeddings = embeddings.unsqueeze(0)
            
        return embeddings

    @torch.inference_mode()
    def encode_text(self, text_list):
        """
        Input: List[str] of query strings
        Output: embeddings (B, 1, Hidden_Dim)
        """
        if self.model_type == 'clip':
            # CLIP text inference; truncation=True is required to avoid length errors
            inputs = self.processor(
                text=text_list, 
                return_tensors="pt", 
                padding=True, 
                truncation=True
            ).to(self.device)
            
            embeddings = self.model.get_text_features(**inputs)
            # L2 normalize
            embeddings = embeddings / embeddings.norm(p=2, dim=-1, keepdim=True)
        else:
            raise ValueError(f"Unknown model_type: {self.model_type}")
        
        # Reshape: (B, D) -> (B, 1, D)
        if embeddings.dim() == 2:
            embeddings = embeddings.unsqueeze(1)
            
        return embeddings
