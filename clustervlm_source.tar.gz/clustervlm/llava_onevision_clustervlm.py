import torch
import random
import numpy as np
from transformers import LlavaOnevisionProcessor, LlavaOnevisionForConditionalGeneration
from logzero import logger
import time

from clustervlm.patch import patch_hf
from clustervlm.abstract_clustervlm import AbstractClusterVLM
from clustervlm.timing import TimingStats
from clustervlm.retrieval_logger import RetrievalLogger

from clustervlm.profiler import Profiler


def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    # Ensure deterministic cuDNN convolution algorithms (slight speed trade-off)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    logger.info(f"Set Seed={seed}")

# Set seed before model loading
set_seed(2025)

class LlavaOneVisionClusterVLM(LlavaOnevisionForConditionalGeneration, AbstractClusterVLM):
    def __init__(self, config, processor, n_frame_tokens, init_prompt_ids, n_local, topk, chunk_size,
                 external_model_path=None, external_model_type='clip',
                 pixel_similarity_threshold=1.0
                 ):
        LlavaOnevisionForConditionalGeneration.__init__(self, config)
        # Forward all parameters to the AbstractClusterVLM base class
        AbstractClusterVLM.__init__(self, processor, n_frame_tokens, init_prompt_ids, n_local, topk, chunk_size,
                               external_model_path=external_model_path, 
                               external_model_type=external_model_type,
                               pixel_similarity_threshold=pixel_similarity_threshold
                               )
        
        self.stats_manager = TimingStats.get_instance()
        self.retrieval_logger = RetrievalLogger.get_instance()

    def finalize_logging(self):
        """
        Call after all video processing and QA rounds are complete.
        Records the final cluster state and flushes all logs to disk.
        """
        print("Finalizing and writing logs...")
        if self.kv_cache and hasattr(self.kv_cache[0], 'retrieval_manager'):
            # Reset the ContextManager instance counter so that the next video
            # starts layer indexing from 0.
            try:
                from clustervlm.attention.kv_cache_manager import CONTEXT_MANAGER_INSTANCE_COUNTER
                globals()['CONTEXT_MANAGER_INSTANCE_COUNTER'] = 0
            except ImportError:
                 print("Warning: Could not reset CONTEXT_MANAGER_INSTANCE_COUNTER.")
            retrieval_manager = self.kv_cache[0].retrieval_manager
            self.retrieval_logger.log_final_cluster_state(retrieval_manager)
        
        self.retrieval_logger.write_log()
        self.stats_manager.write_stats()
        print(f"Logs written to {self.retrieval_logger.filename} and {self.stats_manager.filename}")

    def get_prompt(self, query, mc=False):
        prompt = f"\n{query}<|im_end|><|im_start|>assistant\n"
        if mc:
            prompt += 'Best option: ('
        return prompt

    def _get_video_features(self, pixel_values_videos):
        batch_size, frames, channels, height, width = pixel_values_videos.shape
        pixel_values_videos = pixel_values_videos.view(batch_size * frames, channels, height, width)
        video_features = self.vision_tower(pixel_values_videos, output_hidden_states=True)
        selected_video_feature = video_features.hidden_states[self.config.vision_feature_layer]

        if self.config.vision_feature_select_strategy == "default":
            selected_video_feature = selected_video_feature[:, 1:]
        elif self.config.vision_feature_select_strategy == "full":
            selected_video_feature = selected_video_feature
        video_features = self.multi_modal_projector(selected_video_feature)

        # Compatibility for transformers >= 4.52.1:
        # apply_pooling was moved from ForConditionalGeneration into the inner Model.
        if hasattr(self, "apply_pooling"):
            video_features = self.apply_pooling(video_features)
        else:
            video_features = self.model.apply_pooling(video_features)

        video_features = video_features.reshape(batch_size, frames * video_features.shape[1], -1)  # (B, Nv*196, D)
        return video_features

    @torch.inference_mode()
    def question_answering(self, input_text, max_new_tokens=128, retrieved_indices=None):
        # Start recording QA latency
        TimingStats.get_instance().start_qa()
        start_time_qa = time.time()
        
        device = self.device
        stop_token_ids = [self.processor.tokenizer.eos_token_id]

        output_ids = []
        stopped = False

        # NOTE: Only the question text is used for retrieval.
        question_text = input_text['question']
        input_ids = self.processor.tokenizer(question_text).input_ids
        input_ids = torch.as_tensor([input_ids], device=device)
        
        # Obtain query embedding for cross-modal retrieval
        external_query = None
        external_model_type = getattr(self, "external_model_type", "clip")
        
        if external_model_type == 'llmvit':
            with torch.inference_mode():
                # Use the LLM's own token embeddings as the external query
                query_embeds = self.get_input_embeddings()(input_ids)
                # (1, L, D) -> (1, 1, D) via mean pooling
                external_query = query_embeds.mean(dim=1, keepdim=True)
        else:
            self._ensure_external_encoder()
            if self.external_encoder:
                external_query = self.external_encoder.encode_text([question_text])  # (1, 1, D)
        
        # Activate retrieval mode and inject the external query into each KVCache layer
        for layer_kv in self.kv_cache:
            layer_kv.set_retrieval()
            if external_query is not None and hasattr(layer_kv, 'update_external_embeddings'):
                layer_kv.update_external_embeddings(external_query)

        if retrieved_indices is None:  # Internal retrieval
            out = self.language_model(input_ids=input_ids, use_cache=True, past_key_values=self.kv_cache)
            past_key_values = out.past_key_values  # Retrieved KVCache: L x 2 x (B, h, N, Dh)
        else:  # External retrieval
            for layer_kv in self.kv_cache:
                assert layer_kv.block_size == self.n_frame_tokens, f'block_size: {layer_kv.block_size}, n_frame_tokens: {self.n_frame_tokens}'
                layer_kv.set_retrieved_block_indices(retrieved_indices)
            out = self.language_model(input_ids=input_ids, use_cache=True, past_key_values=self.kv_cache)
            past_key_values = out.past_key_values  # Retrieved KVCache: L x 2 x (B, h, N, Dh)
        
        # Log all per-layer retrieval results for this QA turn
        self.retrieval_logger.log_qa_retrieval(question_text)

        for layer_kv in self.kv_cache:  # reset to default
            layer_kv.reset_retrieval()

        for i in range(max_new_tokens):
            if i == 0:  # prefill
                input_ids = self.processor.tokenizer(input_text['prompt']).input_ids
                input_ids = torch.as_tensor([input_ids], device=device)
                inputs_embeds = self.get_input_embeddings()(input_ids)
                out = self.language_model(inputs_embeds=inputs_embeds, use_cache=True, past_key_values=past_key_values)
                past_key_values = out.past_key_values
                # Compatibility for transformers >= 4.52.1 (backbone mode)
                if hasattr(out, 'logits'):
                    logits = out.logits
                else:
                    logits = self.lm_head(out.last_hidden_state).float()
                
                # Record the moment the first token is generated (for TTFT measurement)
                TimingStats.get_instance().record_first_token()
                            
            else:  # decoding
                out = self.language_model(
                    input_ids=torch.as_tensor([[token]], device=device),
                    use_cache=True,
                    past_key_values=past_key_values,
                )
                # Compatibility for transformers >= 4.52.1 (backbone mode)
                if hasattr(out, 'logits'):
                    logits = out.logits
                else:
                    logits = self.lm_head(out.last_hidden_state).float()
                past_key_values = out.past_key_values

            last_token_logits = logits[0, -1, :]
            
            _, indices = torch.topk(last_token_logits, 2)
            tokens = [int(index) for index in indices.tolist()]
            token = tokens[0]

            output_ids.append(token)

            if token in stop_token_ids:
                stopped = True
            else:
                stopped = False

            if i == max_new_tokens - 1 or stopped:
                break

        output = self.processor.tokenizer.decode(
            output_ids,
            skip_special_tokens=True,
            spaces_between_special_tokens=False,
            clean_up_tokenization_spaces=True,
        )
        
        # Finalize QA timing: pass the actual number of generated tokens
        actual_generated = i + 1
        TimingStats.get_instance().end_qa(generated_tokens_count=actual_generated)
        # Flush timing stats to disk after each QA turn for data safety
        TimingStats.get_instance().write_stats() 
        
        print("Generating Profile...")
        Profiler.get_instance().print_stats()
        Profiler.get_instance().export("stage1_trace.json")
        
        return output


def load_model(model_path='/kaimm-distill/zhouhe08/clustervlm/models/llava-onevision-qwen2-7b-ov-hf',
               n_init=None, n_local=None, topk=64, chunk_size=1):
    device = 'cuda'
    n_frame_tokens = 196
    
    processor = LlavaOnevisionProcessor.from_pretrained(model_path)
    
    init_prompt = '<|im_start|>system \nYou are a helpful assistant.<|im_end|><|im_start|>user '
    init_prompt_ids = processor.tokenizer(init_prompt, return_tensors="pt").input_ids.to(device)
    inf_llm_config = {
        'n_init': init_prompt_ids.shape[1] if n_init is None else n_init,
        'n_local': 13720,  # Recommendation: use a smaller value when Global Anchors are enabled
        'fattn': True,
        'block_size': n_frame_tokens,
        'topk': topk,
        'chunk_size': chunk_size,

        # Encoding enhancement config (Global Anchors)
        # Options: 'default' (original logic) or 'cluster_global_anchors' (cluster-based)
        'encoding_strategy': 'cluster_global_anchors', 
        
        # Global Anchor parameters
        'max_anchors': 64,  # Number of Global Anchors to retain
        'anchor_selection_method': 'closest_to_centroid',  # Options: 'closest_to_centroid', 'random'
        'anchors_per_cluster': 1,

        # Retrieval strategy: 'external_internal' uses Cross-Modal clustering
        'retrieval_strategy': 'external_internal',

        # Two-stage retrieval method:
        # 'hierarchical': strict EC -> IC quota-based selection
        # 'global_sort':  select top-K ECs, then rank all their frames globally by internal similarity
        # 'IC_sort':      select top-K ECs, then rank all their ICs globally by internal similarity
        'external_internal_retrieve_method': 'IC_sort',

        # External (visual) encoder configuration
        'external_threshold': 0.7,
        'external_variance_threshold': 1,
        'topk_external': 64,
        'external_model_path': None,  # None = use built-in vision encoder (llmvit)
        'external_model_type': 'llmvit',  # Options: 'clip' / 'llmvit'
        
        # Per-cluster frame quota
        'max_frames_per_external': 64,  # Max frames per External Cluster (EC)
        'max_frames_per_internal': 64,  # Max frames per Internal Cluster (IC)
        
        # Internal (semantic) clustering configuration
        'cluster_threshold': 0.6,
        'variance_threshold': 0.001,

        # System optimizations
        # [P0: Global linear storage] When enabled, data is stored in GlobalLinearStorage (O(1) access)
        'enable_cluster_storage': False, 

        # [P1: GPU-vectorized clustering] When enabled, K-Means and split index ops run on GPU
        'enable_gpu_clustering': False,

        # [P2: I/O-computation overlap pipeline]
        'enable_fast_io': True,
        'enable_pipeline': True, 
        'prefetch_factor': 1.0,  # Prefetch 1x the candidate count to ensure accuracy

        # [Batch-oriented execution] Greatly reduces CPU-GPU scheduling stalls during encoding
        'enable_batch_clustering': True,

        # [Deferred split (lazy split)] Defers cluster splits within a batch to reduce overhead
        # True: batch-deferred; False: immediately split (strict causal order)
        'enable_lazy_split': True,

        'enable_cluster_lru': True,
        
        # Pixel-level frame pre-filter threshold
        # Set to 1.0 to disable; set to 0.95 to drop frames with >95% pixel-level similarity
        'pixel_similarity_threshold': 1, 

        'clustervlm_attention_update_kv_cache': False,

        # GPU cache block limit (controls GPU cache hit rate)
        'max_cached_block': max(topk * 8, 512),
        'exc_block_size': n_frame_tokens,
        'pin_memory': True,

        # Cluster-uniform sampling configuration
        'use_cluster_sampling': False,  # Whether to enable cluster-uniform sampling
        'frames_per_cluster': 6,        # Max frames to sample per cluster under the new method
    }
    
    strategy = inf_llm_config.get('retrieval_strategy', 'chunking')
    threshold = inf_llm_config.get('cluster_threshold')
    
    # Generate log filenames and initialize loggers
    stats_filename = f"timing_stats_{strategy}.json"
    retrieval_log_filename = f"retrieval_log_{strategy}_threshold{threshold}.json"
    inf_llm_config['stats_filename'] = stats_filename
    inf_llm_config['retrieval_log_filename'] = retrieval_log_filename
    
    stats_filename = f"timing_llava.json" 
    TimingStats.get_instance().setup(filename=stats_filename)
    RetrievalLogger.get_instance().setup(filename=retrieval_log_filename, strategy=strategy, threshold=threshold)
    
    model = LlavaOneVisionClusterVLM.from_pretrained(
        model_path, 
        device_map="auto",
        low_cpu_mem_usage=True, 
        torch_dtype=torch.float16,
        processor=processor,
        n_frame_tokens=n_frame_tokens,
        init_prompt_ids=init_prompt_ids,
        n_local=n_local,
        topk=topk,
        chunk_size=chunk_size,
        external_model_path=inf_llm_config['external_model_path'],
        external_model_type=inf_llm_config.get('external_model_type', 'clip'), 
        pixel_similarity_threshold=inf_llm_config['pixel_similarity_threshold']
    )
    model.language_model = patch_hf(model.language_model, **inf_llm_config)
    
    for k, v in inf_llm_config.items():
        logger.info(f'{k}: {v}')
    logger.info(f'n_frame_tokens: {n_frame_tokens}')

    model.eval()

    return model, processor
