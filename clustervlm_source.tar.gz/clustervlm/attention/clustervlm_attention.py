import copy
import torch
from typing import Optional

from .kv_cache_manager import ContextManager
from .dot_production_attention import get_multi_stage_dot_production_attention

from clustervlm.profiler import Profiler
from logzero import logger


def clustervlm_attention_forward(
    n_local, n_init, topk, chunk_size,
    block_size, max_cached_block,
    exc_block_size, fattn,
    retrieval_strategy='chunking',
    cluster_threshold=0.9,
    async_global_stream=True,
    pin_memory=True,
    stats_filename="timing_stats.json",
    retrieval_log_filename="retrieval_log.json",
    use_cluster_sampling=False,
    frames_per_cluster=4,
    variance_threshold=None,
    external_threshold=0.7,
    external_variance_threshold=0.1,
    topk_external=5,
    max_frames_per_external=32,
    max_frames_per_internal=8,
    enable_pipeline=True,
    enable_cluster_storage=False,
    enable_gpu_clustering=False,
    enable_batch_clustering=False,
    enable_lazy_split=True,
    prefetch_factor=5.0,
    enable_fast_io=True,
    enable_cluster_lru=True,
    clustervlm_attention_update_kv_cache=False,
    encoding_strategy='default',
    max_anchors=64,
    anchor_selection_method='closest_to_centroid',
    anchors_per_cluster=1,
    external_internal_retrieve_method='hierarchical',
    *args, **kwargs
):
    Attn, _ = get_multi_stage_dot_production_attention(fattn)

    def forward(self, query : torch.Tensor,
                    key_value : torch.Tensor,
                    position_bias : Optional[torch.Tensor],
                    use_cache: bool,
                    past_key_value,
                    project_q, project_k, project_v, attention_out,
                    dim_head, num_heads, num_heads_kv,
                    external_embeddings: Optional[torch.Tensor] = None,
    ):

        """ 1. Project QKV """
        batch_size = query.size(0)
        len_q = query.size(1)
        len_k = key_value.size(1)

        assert use_cache

        h_q = project_q(query)
        h_k = project_k(key_value)
        h_v = project_v(key_value)

        h_q = h_q.view(batch_size, len_q, num_heads, dim_head).permute(0, 2, 1, 3).contiguous()
        h_k = h_k.view(batch_size, len_k, num_heads_kv, dim_head).permute(0, 2, 1, 3).contiguous()
        h_v = h_v.view(batch_size, len_k, num_heads_kv, dim_head).permute(0, 2, 1, 3).contiguous()

        if position_bias._cos_cached is not None and position_bias._cos_cached.device != h_q.device:
            position_bias = copy.deepcopy(position_bias)
            if position_bias.inv_freq.device != h_q.device:
                position_bias.inv_freq = position_bias.inv_freq.to(h_q.device)
            if position_bias._cos_cached is not None:
                position_bias._cos_cached = position_bias._cos_cached.to(h_q.device)
            if position_bias._sin_cached is not None:
                position_bias._sin_cached = position_bias._sin_cached.to(h_q.device)

        if past_key_value is None:
            current_layer_idx = getattr(self, 'layer_idx', -1)
            past_key_value = ContextManager(
                position_bias,
                n_init, n_local,
                block_size, max_cached_block, topk, chunk_size, exc_block_size,
                fattn,
                retrieval_strategy=retrieval_strategy,
                cluster_threshold=cluster_threshold,
                async_global_stream=async_global_stream,
                pin_memory=pin_memory,
                stats_filename=stats_filename,
                retrieval_log_filename=retrieval_log_filename,
                use_cluster_sampling=use_cluster_sampling,
                frames_per_cluster=frames_per_cluster,
                variance_threshold=variance_threshold,
                external_threshold=external_threshold,
                external_variance_threshold=external_variance_threshold,
                topk_external=topk_external,
                max_frames_per_external=max_frames_per_external,
                max_frames_per_internal=max_frames_per_internal,
                layer_idx=current_layer_idx,
                enable_pipeline=enable_pipeline,
                enable_cluster_storage=enable_cluster_storage,
                enable_gpu_clustering=enable_gpu_clustering,
                enable_batch_clustering=enable_batch_clustering,
                enable_lazy_split=enable_lazy_split,
                prefetch_factor=prefetch_factor,
                enable_fast_io=enable_fast_io,
                enable_cluster_lru=enable_cluster_lru,
                encoding_strategy=encoding_strategy,
                max_anchors=max_anchors,
                anchor_selection_method=anchor_selection_method,
                anchors_per_cluster=anchors_per_cluster,
                external_internal_retrieve_method=external_internal_retrieve_method,
            )

        local_q, local_k, local_v = h_q, h_k, h_v
        global_q, global_k, global_v = h_q, h_k, h_v

        # NOTE: Question-answering
        if type(past_key_value) is not ContextManager or past_key_value.to_retrieve:

            # [Instrumentation] Retrieval phase (Search + Load)
            with Profiler.get_instance().timer("E2E: Retrieval Phase", "phase"):
                # [Pipeline] The next-layer prefetch is now triggered inside
                # `get_retrieved_kv` AFTER this layer's load has been queued.
                # That ordering ensures the next-layer H2D overlaps with the
                # upcoming FlashAttention compute on `current_stream` rather
                # than competing with this layer's own load for PCIe bandwidth.
                if type(past_key_value) is ContextManager:
                    past_k, past_v = past_key_value.get_retrieved_kv(
                        global_q, external_query=external_embeddings
                    )
                    updata_kv_cache = clustervlm_attention_update_kv_cache
                else:  # sliding-window attention
                    past_k = past_key_value[0]
                    past_v = past_key_value[1]
                    updata_kv_cache = True

            """ 2. Update KV w/ past KV cache """
            h_k = torch.cat([past_k, h_k], dim=-2)
            h_v = torch.cat([past_v, h_v], dim=-2)
            len_k += past_k.shape[2]

            """ 3. Update KV cache """
            if updata_kv_cache:
                if len_k <= n_local + n_init:
                    h_k_cache = h_k
                    h_v_cache = h_v
                else:
                    h_k_cache = torch.cat([h_k[:,:, :n_init, :], h_k[:, :, max(0, h_k.size(-2) - n_local):, :]], dim=2)
                    h_v_cache = torch.cat([h_v[:,:, :n_init, :], h_v[:, :, max(0, h_k.size(-2) - n_local):, :]], dim=2)
                current_key_value = (h_k_cache, h_v_cache)
            else:
                current_key_value = (past_k, past_v)

            """ 4. Get local QKV and apply RoPE to local QK """
            h_q_, h_k_, h_v_ = h_q, h_k, h_v
            if len_q + n_local < h_k_.size(-2):
                h_k_ = h_k_[:, :, h_k_.size(-2) - len_q - n_local:, :]
                h_v_ = h_v_[:, :, h_v_.size(-2) - len_q - n_local:, :]

            # Mark QA phase to prevent back-projection logic interference
            if hasattr(position_bias, "is_qa_phase"):
                position_bias.is_qa_phase = True

            local_h_q, local_h_k = position_bias(h_q_, h_k_)
            local_h_v = h_v_

            """ 5. Get init QKV and apply RoPE to init Q """
            if len_k > n_local:

                # [Core isolation fix]
                if getattr(position_bias, "is_3d_rope", False):
                    init_h_q = local_h_q
                    init_h_k = h_k[:, :, :n_init, :].contiguous()
                    init_h_v = h_v[:, :, :n_init, :].contiguous()
                    # [Safe rotation]
                    if init_h_k.size(2) > 0:
                        sys_len = init_h_k.size(2)
                        sys_indices = torch.arange(sys_len, device=init_h_k.device, dtype=torch.long)
                        sys_ids = torch.stack([sys_indices, sys_indices, sys_indices], dim=0).unsqueeze(1).expand(3, init_h_k.shape[0], -1)
                        init_h_k = position_bias.rotate_k_only(init_h_k, sys_ids)
                else:
                    # [Original baseline logic] Keep LLaVA and other legacy models unaffected
                    init_h_q = position_bias.apply_rotary_pos_emb_one_angle(h_q, n_local)
                    init_h_k = h_k[:, :, :n_init, :].contiguous()
                    init_h_v = h_v[:, :, :n_init, :].contiguous()

            else:
                init_h_q = h_q
                init_h_k = torch.empty(
                    (batch_size, num_heads_kv, 0, dim_head),
                    device=h_k.device,
                    dtype=h_k.dtype
                )
                init_h_v = torch.empty(
                    (batch_size, num_heads_kv, 0, dim_head),
                    device=h_v.device,
                    dtype=h_v.dtype
                )

            # [Instrumentation] Attention computation
            with Profiler.get_instance().timer("E2E: FlashAttention", "compute"):
                """ 6. Sliding Window Attention """
                attn = Attn(local_h_q.shape, local_h_q.dtype, local_h_q.device)
                attn.append(local_h_q, local_h_k, local_h_v, sliding_window=n_local)
                attn.append(init_h_q, init_h_k, init_h_v, end=True, sliding_window=(len_k - len_q, n_local), complement_sliding_window=True)

                # [Key] Trigger GPU computation; the next-layer prefetch H2D
                # is already queued on `prefetch_stream`, overlapping with this
                # FlashAttention kernel.
                score, _ = attn.get_result()

                score = score.view(batch_size, num_heads, len_q, dim_head).permute(0, 2, 1, 3)
                score = score.reshape(batch_size, len_q, num_heads * dim_head)
                score = attention_out(score)

            return score, current_key_value

        # NOTE: Encode video
        else:
            o = past_key_value.append(
                local_q, local_k, local_v,
                global_q, global_k, global_v,
                external_embeddings=external_embeddings
            )
            o = o.view(batch_size, num_heads, len_q, dim_head).permute(0, 2, 1, 3)
            o = o.reshape(batch_size, len_q, dim_head * num_heads)
            o = attention_out(o)

            return o, past_key_value

    return forward
