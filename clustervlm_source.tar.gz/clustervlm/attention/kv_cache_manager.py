# model/attention/kv_cache_manager.py

import math
import time
import torch
from typing import Optional, Tuple, List, Dict
import numpy as np
import random

from .dot_production_attention import get_multi_stage_dot_production_attention
from clustervlm.timing import TimingStats
from clustervlm.retrieval_logger import RetrievalLogger
from logzero import logger

from clustervlm.profiler import Profiler
import threading

# Clustering debug log switch; when enabled, prints the cluster path (Path A-E) assigned to each frame
DEBUG_CLUSTER = False
# When enabled, prints detailed logs of Layer 0 Anchor fetching and concatenation dimensions
DEBUG_ATTENTION = False 
# System optimization DEBUG switch
DEBUG_SYSTEM = False
# IC DEBUG switch
DEBUG_IC = False
# Cache hit rate switch
DEBUG_CACHE = False
# Prefetch hit-rate switch
DEBUG_PREFETCH_RATIO = False
# Qwen2.5-VL debug switch
DEBUG_QWEN = False

# [New Debug] Enable retrieval comparison mode
# Only effective when retrieve_method == 'global_sort'
# Will simulate hierarchical results in the background and compare differences
DEBUG_RETRIEVAL_COMPARE = False

# =============================================================================
# Class: CudaCache
# Function: Manage GPU memory pool to avoid frequent cudaMalloc/cudaFree overhead
# =============================================================================
class CudaCache:
    def __init__(self, num_units, unit_size, dtype):
        """
        Initialize GPU memory pool.
        Args:
            num_units (int): Number of blocks in the pool (n_block * batch_size)
            unit_size (int): Size of each block (block_size * hidden_dim * 2 * heads)
            dtype: Data type
        """
        self.num_units = num_units  
        self.unit_size = unit_size  
        self.dtype = dtype
        # Pre-allocate one large block of GPU memory
        self.data = torch.empty(
            (num_units, unit_size),
            device = "cuda",
            dtype=dtype
        )
        # Maintain a set of free indices
        self.idle_set = set(list(range(num_units)))

    def alloc(self):
        """Allocate a free block, return Tensor and index ID"""
        assert len(self.idle_set) > 0
        idx = self.idle_set.pop()
        return self.data[idx], idx

    def delete(self, idx):
        """Recycle block"""
        assert idx not in self.idle_set
        self.idle_set.add(idx)


# =============================================================================
# Class: MemoryUnit
# Function: Minimum management unit for KV-Cache; responsible for CPU <-> GPU data movement
# =============================================================================
class MemoryUnit:
    def __init__(
        self, 
        kv: Tuple[torch.Tensor, torch.Tensor], 
        cache: CudaCache, 
        load_to_cache: bool = False, 
        pin_memory: bool = False,
    ):
        """
        Args:
            kv: (Key, Value) tensor pair, usually on CPU
            cache: Reference to CudaCache instance
            load_to_cache: Whether to immediately load to GPU (usually False)
            pin_memory: Whether to use Page-Locked (Pin) Memory for accelerated transfer
        """
        self.cache = cache

        # Ensure data is stored on CPU; Pin Memory is preferred if available
        if kv[0].is_cuda:
            cpu_data = tuple(_t.contiguous().to("cpu", non_blocking=True) for _t in kv)
        else:
            cpu_data = tuple(_t.contiguous() for _t in kv)

        if pin_memory:
            # [System optimization] Explicitly call pin_memory to ensure subsequent non_blocking=True can truly achieve async DMA transfer
            cpu_data = tuple(_t.pin_memory() for _t in cpu_data)

        # Initial state: not loaded to GPU
        self.cpu_data = cpu_data
        self.gpu_data = None
        self.gpu_data_id = None
        self.event = None  # Used for CUDA Stream synchronization

        if load_to_cache:
            self.load()

    def load(self, target: Optional[Tuple[torch.Tensor, torch.Tensor]] = None) -> bool:
        """
        Load data from CPU to GPU.
        
        Args:
            target: If provided, directly copy data to target GPU Buffer (Streaming optimization)
        Returns:
            bool: Whether an actual H2D copy occurred (True means Cache Miss triggered loading)
        """
        # If already on GPU (Cache Hit), directly Copy to Target
        if self.gpu_data is not None:
            if target is not None:
                target[0].copy_(self.gpu_data[0], non_blocking=True)
                target[1].copy_(self.gpu_data[1], non_blocking=True)
                
                # System debug disabled to reduce overhead
            else:
                target_event = None
            return False, None  # Return None directly, saving massive overhead

        # Cache Miss: allocate GPU memory from CudaCache
        gpu_data, gpu_data_id = self.cache.alloc()
        gpu_data = gpu_data.view((2,) + self.cpu_data[0].shape)
        
        # Execute H2D copy
        if target is not None:
            # [System optimization] Direct async copy to target Buffer (Streaming optimization), reducing one GPU memory read/write
            target[0].copy_(self.cpu_data[0], non_blocking=True)
            target[1].copy_(self.cpu_data[1], non_blocking=True)
            target_event = torch.cuda.Event()
            target_event.record(torch.cuda.current_stream())
            
            # Also back up a copy to the LRU cache for potential reuse
            gpu_data[0].copy_(target[0], non_blocking=True)
            gpu_data[1].copy_(target[1], non_blocking=True)
        else:
            gpu_data[0].copy_(self.cpu_data[0], non_blocking=True)
            gpu_data[1].copy_(self.cpu_data[1], non_blocking=True)

        event = torch.cuda.Event()
        event.record(torch.cuda.current_stream())
        self.event = event
        self.gpu_data = gpu_data
        self.gpu_data_id = gpu_data_id

        return True, target_event

    def get(self):
        """Retrieve GPU data (blocks until transfer completes)."""
        assert self.gpu_data is not None
        self.event.wait()
        return self.gpu_data

    def offload(self):
        """Offload data from GPU back to CudaCache."""
        if self.gpu_data is None:
            return
        # Wait for any pending CUDA event before releasing
        if getattr(self, 'event', None) is not None:
            self.event.wait()
        self.gpu_data = None
        self.cache.delete(self.gpu_data_id)
        self.gpu_data_id = None

    def calculate_cpu_memory(self):
        return len(self.cpu_data) * self.cpu_data[0].numel() * self.cpu_data[0].element_size()


# =============================================================================
# Class: VectorTensor
# Function: Dynamically maintains a set of vectors on GPU (e.g., frame embeddings),
#           with automatic capacity expansion.
# =============================================================================
class VectorTensor:
    def __init__(self, hidden_size, element_dtype, device):
        init_cached_size = 16 
        self.data = torch.empty((init_cached_size, hidden_size), dtype=element_dtype, device=device)
        self.length = 0
        self.cache_size = init_cached_size
        self.hidden_size = hidden_size

    def append_cache(self):
        """Double the internal buffer capacity."""
        new_cache_size = self.cache_size * 2
        data_shape = self.data.shape
        new_data = torch.empty((new_cache_size,) + data_shape[1:], device=self.data.device, dtype=self.data.dtype)
        new_data[:self.cache_size,...].copy_(self.data)
        self.data = new_data
        self.cache_size = new_cache_size

    def append(self, tensor: torch.Tensor):
        """Append new vectors to the storage."""
        assert tensor.dtype == self.data.dtype
        assert tensor.size(1) == self.hidden_size
        append_l = tensor.size(0)
        while self.length + append_l > self.cache_size:
            self.append_cache()
        self.data[self.length: self.length+append_l, ...].copy_(tensor)
        self.length += append_l

    def get_true_cosine_similarity(self, tensor: torch.Tensor, eps: float = 1e-8):
        """
        Compute cosine similarity between the input vector and all stored vectors.
        Args:
            tensor: Query vector (D,)
        Returns:
            Similarities: (N,)
        """
        if self.length == 0:
            return torch.tensor([], device=tensor.device)
        
        query = tensor.unsqueeze(0).float()  # (1, D)
        keys = self.data[:self.length].float()  # (T, D)
        
        # Apply LayerNorm before computing similarity to reduce anisotropy in LLM key vectors
        if self.hidden_size > 1024:
            query = torch.nn.functional.layer_norm(query, query.shape[1:])
            keys = torch.nn.functional.layer_norm(keys, keys.shape[1:])
        
        similarities = torch.nn.functional.cosine_similarity(query, keys, dim=1, eps=eps)
        return similarities

    def __len__(self):
        return self.length

# =============================================================================
# Classes: Cluster Structures
# Function: Lightweight metadata containers for Internal Clusters (IC) and External Clusters (EC).
# =============================================================================
class InternalCluster:
    def __init__(self, centroid, members_indices, external_emb_sum=None, int_vector_sum=None):
        self.centroid = centroid
        self.member_indices = members_indices
        self.size = len(members_indices)
        self.external_emb_sum = external_emb_sum 
        self.int_vector_sum = int_vector_sum     

class ExternalCluster:
    def __init__(self, centroid, ext_vector_sum=None):
        self.centroid = centroid
        self.sub_clusters = [] 
        self.size = 0
        self.ext_vector_sum = ext_vector_sum 

    def add_internal_cluster(self, ic):
        self.sub_clusters.append(ic)
        self.size += ic.size
        
    def get_all_members(self):
        members = []
        for ic in self.sub_clusters: members.extend(ic.member_indices)
        return members


# =============================================================================
# Class: RetrievalManager
# Function: Core manager responsible for:
#   1. Streaming clustering of video frames (add_block)
#   2. Selection and maintenance of Global Anchors (_update_anchor)
#   3. Top-K retrieval during the QA phase (retrieve_topk)
# =============================================================================
class RetrievalManager:

    # Class-level cache shared across all layer instances to avoid redundant computation
    _shared_cache_sig = None
    _shared_cache_indices = None

    @classmethod
    def reset_class_cache(cls):
        """Reset the shared class-level cache. Called when ContextManager initializes a new video."""
        cls._shared_cache_sig = None
        cls._shared_cache_indices = None

    def __init__(self, strategy, threshold, num_units, rep_dim, dtype, device, 
                 variance_threshold=None, eps=1e-8,
                 external_threshold=0.7, external_variance_threshold=0.1, topk_external=5,
                 max_frames_per_external=16, max_frames_per_internal=8, 
                 layer_idx=-1,
                 # --- Addedparameters ---
                 encoding_strategy='default',
                 max_anchors=64,
                 anchor_params=None,
                 retrieve_method='hierarchical',
                 enable_cluster_storage=False,
                 kv_shape_params=None,
                 # [Stage 1] Enable GPU-based clustering to reduce CPU synchronization overhead
                 enable_gpu_clustering=False,
                 # Enable lazy split: defer IC/EC splitting within a batch
                 enable_lazy_split=True
                 ):
        self.strategy = strategy
        self.threshold = threshold
        self.num_units = num_units
        self.eps = eps
        self.logger = RetrievalLogger.get_instance()
        self.stats_manager = TimingStats.get_instance()
        self.layer_idx = layer_idx
        self.max_frames_per_external = max_frames_per_external
        self.max_frames_per_internal = max_frames_per_internal
        self.device = device
        self.topk_external = topk_external

        self.retrieve_method = retrieve_method
        self.enable_gpu_clustering = enable_gpu_clustering
        self.enable_lazy_split = enable_lazy_split
        if DEBUG_SYSTEM and self.layer_idx == 0 and self.enable_gpu_clustering:
            logger.info(f"[RetrievalManager] GPU Clustering Optimization Enabled.")

        # Structured GPU index for accelerating retrieve_topk
        self._index_ready = False
        self._gpu_hierarchy = [None] * num_units

        # Store per-frame vector representations for Internal Cluster (IC) assignment
        self.all_frame_reps = [VectorTensor(rep_dim, dtype, device) for _ in range(num_units)]

        # --- Global Anchor storage initialization ---
        self.encoding_strategy = encoding_strategy

        # Target number of Global Anchors to expose to the LLM (e.g., 64)
        self.target_anchor_count = max_anchors

        # Internal buffer capacity is 2x the target to guard against cutoff attrition
        internal_buffer_size = max_anchors * 2

        if anchor_params:
            self.anchor_params = anchor_params
            # Override max_total with the enlarged internal capacity
            self.anchor_params['max_total'] = internal_buffer_size
        else:
            self.anchor_params = {
                'method': 'closest_to_centroid',
                'per_cluster': 1,
                'max_total': internal_buffer_size
            }

        # Global Anchor buffer: stores representative frame KV pairs selected during encoding
        # Shape: (Num_Units, Max_Total, Heads, Block_Size, Head_Dim)
        self.anchor_buffer_k = None
        self.anchor_buffer_v = None
        self.anchor_current_count = 0

        # Must be initialized here to avoid AttributeError in get_current_anchor_kv
        self.anchor_block_indices = None

        # Metadata for managing Global Anchor updates and eviction
        self.ic_to_anchors = {}    # Map: InternalCluster ID -> [anchor slot indices]
        self.ic_anchor_scores = {}  # Map: InternalCluster ID -> [anchor scores]
        # Records the most recent active block index per IC (used for macro-level LRU eviction)
        self.ic_last_seen = {}


        if self.strategy == 'external_internal':
            self.external_clusters = [[] for _ in range(num_units)] 
            self.all_external_reps = [VectorTensor(1024, torch.float32, device) for _ in range(num_units)]
            self.external_threshold = external_threshold
            self.external_variance_threshold = external_variance_threshold
            self.variance_threshold = variance_threshold if variance_threshold is not None else 100
            
        elif self.strategy.startswith('clustering'):
            self.cluster_representatives = [VectorTensor(rep_dim, dtype, device) for _ in range(num_units)]
            self.cluster_members = [[] for _ in range(num_units)]
            self.cluster_sizes = [[] for _ in range(num_units)]
            self.variance_threshold = variance_threshold if variance_threshold is not None else 100

        else: # chunking
            self.block_k = self.all_frame_reps
            
    # --- Global Anchor management (Phase 2 & 3) ---
    def _update_anchor(self, u, ic, new_k, new_v, new_embedding, block_idx):
        """
        Update the Global Anchor buffer.
        Strategy:
        - Macro level (Inter-Cluster): Survival-of-the-fittest + LRU eviction.
          When the buffer is full, evict the anchor from the least recently active cluster.
        - Micro level (Intra-Cluster): Keep-the-best.
          Within the same cluster, retain the frame closest to the cluster centroid.
        """
        # --- [Lazy initialization of the Anchor buffer] ---
        if self.anchor_buffer_k is None:
            heads, blk_size, dim = new_k.shape
            max_total = self.anchor_params['max_total']

            # Physical storage: (Batch, Max, Heads, Block, Dim)
            self.anchor_buffer_k = torch.empty((self.num_units, max_total, heads, blk_size, dim),
                                               dtype=new_k.dtype, device=new_k.device)
            self.anchor_buffer_v = torch.empty((self.num_units, max_total, heads, blk_size, dim),
                                               dtype=new_v.dtype, device=new_v.device)

            # Index storage: records the block ID corresponding to each anchor slot
            self.anchor_block_indices = torch.full((self.num_units, max_total), -1,
                                                   dtype=torch.long, device=new_k.device)
            self.anchor_current_count = 0

        # --- [Prepare metadata] ---
        ic_id = id(ic)
        method = self.anchor_params.get('method', 'closest_to_centroid')
        limit = self.anchor_params.get('per_cluster', 1)  # per-cluster slot limit

        # Initialize metadata dicts for this IC if not present
        if ic_id not in self.ic_to_anchors:
            self.ic_to_anchors[ic_id] = []
            self.ic_anchor_scores[ic_id] = []

        # Update the "last active time" of this cluster (used for macro-level LRU)
        if not hasattr(self, 'ic_last_seen'):
            self.ic_last_seen = {}
        self.ic_last_seen[ic_id] = block_idx

        # --- 1. Compute micro-score ---
        score = 0.0
        if method == 'closest_to_centroid':
            if ic.int_vector_sum is not None:
                # Normalize centroid
                centroid = torch.nn.functional.normalize(ic.int_vector_sum.to(new_embedding.dtype), p=2, dim=0)
                # Normalize current frame (LayerNorm + L2)
                emb_ln = torch.nn.functional.layer_norm(new_embedding.float(), new_embedding.shape)
                emb_norm = torch.nn.functional.normalize(emb_ln, p=2, dim=0, eps=1e-6).to(new_embedding.dtype)
                # Compute cosine similarity
                score = torch.dot(emb_norm.view(-1), centroid.view(-1)).item()
        elif method == 'random':
            score = random.random()
        elif method == 'fifo':
            score = float(block_idx)  # In FIFO mode, score equals timestamp

        indices = self.ic_to_anchors[ic_id]    # Physical slots already occupied by this IC
        scores = self.ic_anchor_scores[ic_id]

        target_slot_idx = -1

        # --- 2. Decision logic (Hybrid) ---

        # === Scenario A: Intra-Cluster competition ===
        # This cluster already has slots in the buffer
        if len(indices) > 0:
            # A1. Slot not full and global buffer not full -> add directly
            if len(indices) < limit and self.anchor_current_count < self.anchor_params['max_total']:
                target_slot_idx = self.anchor_current_count
                self.anchor_current_count += 1
                indices.append(target_slot_idx)
                scores.append(score)

            # A2. Slot is full -> internal competition (keep the best)
            else:
                # Find the weakest anchor in this cluster
                min_score = min(scores)
                min_idx = scores.index(min_score)

                # Replace if the new one is better
                if score > min_score:
                    target_slot_idx = indices[min_idx]
                    scores[min_idx] = score
                else:
                    return  # New frame lost; discard

        # === Scenario B: Inter-Cluster competition ===
        # This cluster has no slots yet
        else:
            # B1. Global buffer has free slots -> allocate directly
            if self.anchor_current_count < self.anchor_params['max_total']:
                target_slot_idx = self.anchor_current_count
                self.anchor_current_count += 1
                indices.append(target_slot_idx)
                scores.append(score)

            # B2. Global buffer full -> trigger macro-level LRU eviction
            else:
                # Find the least recently active victim cluster
                victim_ic_id = None
                victim_last_seen = float('inf')

                # Iterate over all clusters that hold slots (typically < 128 entries)
                for existing_id in self.ic_to_anchors:
                    if not self.ic_to_anchors[existing_id]: continue

                    last_seen = self.ic_last_seen.get(existing_id, -1)
                    if last_seen < victim_last_seen:
                        victim_last_seen = last_seen
                        victim_ic_id = existing_id

                if victim_ic_id is not None:
                    # Evict the worst-scoring anchor from the victim cluster
                    vic_indices = self.ic_to_anchors[victim_ic_id]
                    vic_scores = self.ic_anchor_scores[victim_ic_id]

                    min_vic_score = min(vic_scores)
                    min_vic_idx_in_list = vic_scores.index(min_vic_score)

                    target_slot_idx = vic_indices[min_vic_idx_in_list]

                    # Clean up victim's metadata record
                    vic_indices.pop(min_vic_idx_in_list)
                    vic_scores.pop(min_vic_idx_in_list)

                    # Remove victim's key entirely if it lost all slots
                    if not vic_indices:
                        del self.ic_to_anchors[victim_ic_id]

                    # Register the new owner
                    indices.append(target_slot_idx)
                    scores.append(score)

        # --- 3. Execute physical write (zero-copy on GPU) ---
        if target_slot_idx != -1:
            self.anchor_buffer_k[u, target_slot_idx].copy_(new_k, non_blocking=True)
            self.anchor_buffer_v[u, target_slot_idx].copy_(new_v, non_blocking=True)
            # Record block ID as timestamp
            self.anchor_block_indices[u, target_slot_idx] = block_idx

    def get_current_anchor_kv(self, cutoff_block_idx=None):
        """
        [Phase 3] Retrieve all currently valid Global Anchors.
        Called from ContextManager.append before computing attention.
        """
        if self.anchor_buffer_k is None or self.anchor_current_count == 0:
            return None, None
            
        # 1. Slice out the valid region
        valid_k = self.anchor_buffer_k[:, :self.anchor_current_count]
        valid_v = self.anchor_buffer_v[:, :self.anchor_current_count]
        valid_indices = self.anchor_block_indices[:, :self.anchor_current_count]

        # 2. Apply cutoff filter (exclude frames too recent to be outside the local window)
        if cutoff_block_idx is not None:
            mask = (valid_indices < cutoff_block_idx) & (valid_indices != -1)
            mask_0 = mask[0]
            
            if not mask_0.any():
                return None, None
            
            valid_k = valid_k[:, mask_0]
            valid_v = valid_v[:, mask_0]
            valid_indices = valid_indices[:, mask_0]
            
            if valid_k.size(1) == 0:
                return None, None

        # --- [Debug Log: After cutoff filter] ---
        if DEBUG_ATTENTION and self.layer_idx % 5 == 0:
            logger.info(f"DEBUG [layer {self.layer_idx}] After local-window cutoff: {valid_k.size(1)} anchors remaining")
            raw_ids = valid_indices[0].tolist()
            logger.info(f"      [layer {self.layer_idx}] IDs before sort (Top 10): {raw_ids[:10]} ...")

        # Sort by block index (ascending) to ensure temporal order for RoPE
        sorted_ids = torch.argsort(valid_indices[0])
        valid_k = valid_k[:, sorted_ids]
        valid_v = valid_v[:, sorted_ids]
        valid_indices = valid_indices[:, sorted_ids]

        # --- [Debug Log: After sort] ---
        if DEBUG_ATTENTION and self.layer_idx % 5 == 0:
            sorted_raw_ids = valid_indices[0].tolist()
            logger.info(f"      [layer {self.layer_idx}] IDs after sort (Top 10): {sorted_raw_ids[:10]} ... (check monotonicity)")

        # 3. Quantity control: truncate to the target anchor count
        current_len = valid_k.size(1)
        target_len = getattr(self, 'target_anchor_count', 64)

        if current_len > target_len:
            # Retain the most recent target_len anchors (tail of the sorted list)
            valid_k = valid_k[:, -target_len:]
            valid_v = valid_v[:, -target_len:]
            valid_indices = valid_indices[:, -target_len:]

        # --- [Debug Log: Final output] ---
        if DEBUG_ATTENTION and self.layer_idx % 5 == 0:
            final_ids = valid_indices[0].tolist()
            logger.info(f"      [layer {self.layer_idx}] Final output: {valid_k.size(1)} anchors (target: {target_len})")
            logger.info(f"      [layer {self.layer_idx}] Final IDs range: {final_ids[0]} -> {final_ids[-1]}")

        # 4. Dimension rearrangement: flatten Anchors x Block into a single sequence
        k_trans = valid_k.permute(0, 2, 1, 3, 4)
        v_trans = valid_v.permute(0, 2, 1, 3, 4)

        batch, heads, count, blk, dim = k_trans.shape
        anchor_k = k_trans.reshape(batch, heads, count * blk, dim)
        anchor_v = v_trans.reshape(batch, heads, count * blk, dim)
        
        return anchor_k, anchor_v

    def free_anchor_memory(self):
        """[Phase 4] Release GPU memory used by the Global Anchor buffer. Called after video encoding completes."""
        if self.anchor_buffer_k is not None:
            self.anchor_buffer_k = None
            self.anchor_buffer_v = None
            self.anchor_current_count = 0
            self.ic_to_anchors.clear()
            self.ic_anchor_scores.clear()

    # --- Clustering helper functions ---
    def _perform_2_means_split(self, vectors, max_iter=5):
        """
        Spherical K-Means with Max-Min initialization and balance check.
        Goal: split vectors into two clusters with maximum semantic divergence.
        Key design choices:
        1. Spherical K-Means (forced normalization) because LLM attention keys are direction-only.
        2. Max-Min initialization instead of random init for determinism and maximum initial divergence.
        3. Balance check: if a split produces a singleton cluster (size < 2), discard the split.
        """
        n, d = vectors.shape
        # Too few points to split meaningfully (need at least 2+2)
        if n < 4: return None 
        
        # 1. Preprocessing: project onto the unit hypersphere (cosine space).
        #    This eliminates the influence of vector magnitude on distance.
        vectors_norm = torch.nn.functional.normalize(vectors, p=2, dim=1)
        
        # 2. Initialization: Max-Min Strategy (find the axis of maximum semantic divergence).
        #    More stable than KMeans++ for small samples (n<32); directly locks onto the
        #    two extremes of the distribution's principal axis.
        
        # A. Compute global centroid
        global_center = torch.mean(vectors_norm, dim=0, keepdim=True)
        # B. Find the point farthest from the centroid (extreme point 1)
        sim_to_global = torch.matmul(vectors_norm, global_center.T).squeeze()
        c1_idx = torch.argmin(sim_to_global)
        c1 = vectors_norm[c1_idx].unsqueeze(0)
        # C. Find the point farthest from C1 (extreme point 2)
        sim_to_c1 = torch.matmul(vectors_norm, c1.T).squeeze()
        c2_idx = torch.argmin(sim_to_c1)
        c2 = vectors_norm[c2_idx].unsqueeze(0)
        
        # Initial centroids
        centroids = torch.cat([c1, c2], dim=0)
        
        # 3. Iteration (typically 2-3 steps to converge; max_iter=5 is sufficient)
        prev_labels = None
        for _ in range(max_iter):
            # E-Step: assign each point to the nearest centroid (Matmul = cosine similarity)
            sim_matrix = torch.matmul(vectors_norm, centroids.T)
            labels = torch.argmax(sim_matrix, dim=1)
            
            # Convergence check
            if prev_labels is not None and torch.equal(labels, prev_labels):
                break
            prev_labels = labels
            
            # M-Step: update centroids (vectorized)
            mask0 = (labels == 0).unsqueeze(1)
            mask1 = (labels == 1).unsqueeze(1)
            
            # Guard against empty clusters (unlikely with Max-Min init, but defensive)
            if mask0.sum() == 0 or mask1.sum() == 0:
                return None
                
            sum0 = (vectors_norm * mask0).sum(dim=0)
            sum1 = (vectors_norm * mask1).sum(dim=0)
            
            # Critical: re-normalize centroids after each update (spherical K-Means)
            new_c1 = torch.nn.functional.normalize(sum0, p=2, dim=0).unsqueeze(0)
            new_c2 = torch.nn.functional.normalize(sum1, p=2, dim=0).unsqueeze(0)
            centroids = torch.cat([new_c1, new_c2], dim=0)

        # 4. Generate final cluster assignments
        final_sim = torch.matmul(vectors_norm, centroids.T)
        final_labels = torch.argmax(final_sim, dim=1)
        
        if self.enable_gpu_clustering:
            # Return GPU boolean masks directly (avoids CPU sync on tolist)
            mask0 = (final_labels == 0)
            mask1 = (final_labels == 1)

            # Empty-cluster safety check (triggers a sync but is a necessary guard in Stage 1)
            if mask0.sum() == 0 or mask1.sum() == 0:
                return None

            # Returns: centroids, (mask0, mask1)
            return centroids, (mask0, mask1)

        else:
            # Original logic: convert back to CPU lists
            indices1 = torch.where(final_labels == 0)[0].cpu().tolist()
            indices2 = torch.where(final_labels == 1)[0].cpu().tolist()

            if len(indices1) == 0 or len(indices2) == 0:
                return None
            return centroids, (indices1, indices2)
        
    def _split_ec(self, u, ec_idx):
        """Split an External Cluster (EC) into two child ECs using Spherical K-Means."""
        target_ec = self.external_clusters[u][ec_idx]
        all_members = target_ec.get_all_members()
        if len(all_members) < 2: return

        # External embeddings (e.g., CLIP) do not need LayerNorm; keep as-is
        idx_tensor = torch.tensor(all_members, device=self.device, dtype=torch.long)
        ext_vectors = self.all_external_reps[u].data[idx_tensor].float()

        split_res = self._perform_2_means_split(ext_vectors)
        if split_res is None: return 
        
        if self.enable_gpu_clustering:
            # Use GPU masks directly to avoid list conversion
            centroids, (mask0, mask1) = split_res
            members1_t = torch.masked_select(idx_tensor, mask0)
            members2_t = torch.masked_select(idx_tensor, mask1)
            members1 = members1_t.tolist()
            members2 = members2_t.tolist()
        else:
            centroids, (idxs1, idxs2) = split_res
            members1 = [all_members[i] for i in idxs1]
            members2 = [all_members[i] for i in idxs2]
        
        # [Helper] Reconstruct an EC with its ICs from a given member set
        def create_ec_from_members(members, ec_centroid):
            mem_tensor = torch.tensor(members, device=self.device, dtype=torch.long)

            # 1. Retrieve raw Internal frame vectors
            int_vectors_raw = self.all_frame_reps[u].data[mem_tensor].float()

            # Apply LayerNorm for data consistency with the IC state built during add_block
            int_vectors_ln = torch.nn.functional.layer_norm(int_vectors_raw, int_vectors_raw.shape[1:])

            # L2-normalize before accumulating to obtain the IC centroid sum
            int_vectors_norm = torch.nn.functional.normalize(int_vectors_ln, p=2, dim=1, eps=1e-6)
            int_sum = int_vectors_norm.sum(dim=0)
            ic_centroid = torch.nn.functional.normalize(int_sum, p=2, dim=0).to(self.all_frame_reps[u].data.dtype)

            # External embedding attributes
            ext_vecs_subset = self.all_external_reps[u].data[mem_tensor].float()
            ext_sum = ext_vecs_subset.sum(dim=0)

            new_ic = InternalCluster(ic_centroid, members, external_emb_sum=ext_sum, int_vector_sum=int_sum)
            new_ec = ExternalCluster(ec_centroid.to(target_ec.centroid.dtype), ext_vector_sum=ext_sum)
            new_ec.add_internal_cluster(new_ic)

            # Recursively check whether the new IC needs further splitting
            self._check_and_split_ic(u, new_ec, 0)
            return new_ec

        # Create the two new ECs resulting from the split
        ec1 = create_ec_from_members(members1, centroids[0])
        ec2 = create_ec_from_members(members2, centroids[1])
        
        self.external_clusters[u][ec_idx] = ec1
        self.external_clusters[u].append(ec2)

    def _check_and_split_ic(self, u, ec, ic_idx):
        """
        Adaptive IC splitting based on Relative Separation.
        Core idea: only split when the inter-cluster divergence is significantly
        larger than the intra-cluster background noise.
        This adapts well across both shallow layers (low noise, low divergence)
        and deep layers (high noise, high divergence).
        """
        ic = ec.sub_clusters[ic_idx]
        # 1. Hard minimum: fewer than 4 frames cannot form two non-trivial sub-clusters
        if ic.size < 4: return 
        
        # 2. Compute baseline variance (background noise).
        #    ic.int_vector_sum is accumulated from LN-normalized data and can be used directly.
        current_avg_sim = torch.norm(ic.int_vector_sum) / ic.size
        current_var = 1.0 - current_avg_sim.item()
        
        # Variance threshold: if the cluster is nearly uniform (mostly duplicate frames), skip split.
        if current_var < self.variance_threshold: return

        # 3. Prepare data (consistency rule: apply LayerNorm before computing cosine distances)
        idx_tensor = torch.tensor(ic.member_indices, device=self.device, dtype=torch.long)
        int_vectors_raw = self.all_frame_reps[u].data[idx_tensor].float()
        
        # Must operate in spherical space (cosine distance)
        int_vectors_ln = torch.nn.functional.layer_norm(int_vectors_raw, int_vectors_raw.shape[1:])

        # 4. Trial split via Spherical K-Means (with empty-cluster guard)
        split_res = self._perform_2_means_split(int_vectors_ln)
        
        # Unsplittable (e.g. 1 vs N-1): abort
        if split_res is None: return

        if self.enable_gpu_clustering:
            centroids, (mask0, mask1) = split_res  # centroids already on GPU
        else:
            centroids, (idxs1, idxs2) = split_res
        
        # 5. Compute Relative Separation Ratio (core metric)
        c1 = centroids[0]
        c2 = centroids[1]
        
        # Cosine distance between the two new centroids: range [0, 2].
        # 0 = perfectly overlapping, 2 = diametrically opposed.
        inter_centroid_dist = 1.0 - torch.dot(c1.view(-1), c2.view(-1)).item()
        
        # Separation ratio = inter-centroid distance / intra-cluster variance (dimensionless SNR)
        separation_ratio = inter_centroid_dist / (current_var + 1e-9)
        
        # 6. Dynamic split threshold.
        # Small clusters use a strict threshold; large clusters use a relaxed threshold.
        # Exponential decay provides a smooth transition between the two extremes.
        
        SIZE_SAFE = 8.0    # Lower bound of the safe zone (high threshold below this)
        SIZE_HUGE = 32.0   # Upper bound of the easy-split zone (low threshold above this)
        RATIO_STRICT = 1.1 # Strict threshold (small clusters: hard to split)
        RATIO_LOOSE = 0.5  # Relaxed threshold (large clusters: easy to split)
        DECAY_FACTOR = 8.0 # Exponential decay rate (smaller = faster decay)

        # if DEBUG_IC:
        #     logger.info(f"[IC Split Check] SIZE_SAFE={SIZE_SAFE}, SIZE_HUGE={SIZE_HUGE}, RATIO_STRICT={RATIO_STRICT}, RATIO_LOOSE={RATIO_LOOSE}")
        
        ic_size_f = float(ic.size)
        
        if ic_size_f <= SIZE_SAFE:
            threshold_ratio = RATIO_STRICT
        elif ic_size_f >= SIZE_HUGE:
            threshold_ratio = RATIO_LOOSE
        else:
            # Exponential decay:
            #   threshold = tau_min + (tau_max - tau_min) * exp(-(size - size_safe) / decay)
            # At size = SIZE_SAFE: threshold = RATIO_STRICT (left-continuous)
            threshold_ratio = RATIO_LOOSE + (RATIO_STRICT - RATIO_LOOSE) * math.exp(
                -(ic_size_f - SIZE_SAFE) / DECAY_FACTOR
            )
        def make_child_ic(members, local_indices, centroid):
            # Normalize input: unify Tensor/List to Tensor for indexing
            if isinstance(members, torch.Tensor):
                mem_t = members
            else:
                mem_t = torch.tensor(members, device=self.device, dtype=torch.long)
            
            # Extract External data
            ev = self.all_external_reps[u].data[mem_t].float()
            e_sum = ev.sum(dim=0)
            
            # Extract Internal data
            iv_subset = int_vectors_ln[local_indices]
            iv_subset_norm = torch.nn.functional.normalize(iv_subset, p=2, dim=1, eps=1e-6)
            i_sum = iv_subset_norm.sum(dim=0)
            
            # Convert storage indices back to List (InternalCluster.member_indices must be List,
            # otherwise .append() in add_block will raise a TypeError)
            if isinstance(members, torch.Tensor):
                members_list = members.tolist()
            else:
                members_list = members
            
            return InternalCluster(centroid.to(ic.centroid.dtype), members_list, external_emb_sum=e_sum, int_vector_sum=i_sum)
        
        if separation_ratio > threshold_ratio:
            # Perform the IC split
            if self.enable_gpu_clustering:
                # GPU path: pass Tensors directly to avoid .tolist() overhead
                members1_t = torch.masked_select(idx_tensor, mask0)
                members2_t = torch.masked_select(idx_tensor, mask1)
                local_idxs1_t = torch.nonzero(mask0, as_tuple=True)[0]
                local_idxs2_t = torch.nonzero(mask1, as_tuple=True)[0]
                ic1 = make_child_ic(members1_t, local_idxs1_t, centroids[0])
                ic2 = make_child_ic(members2_t, local_idxs2_t, centroids[1])
            else:
                # CPU path (original logic)
                m1 = [ic.member_indices[i] for i in idxs1]
                m2 = [ic.member_indices[i] for i in idxs2]
                ic1 = make_child_ic(m1, idxs1, centroids[0])
                ic2 = make_child_ic(m2, idxs2, centroids[1])
            
            ec.sub_clusters[ic_idx] = ic1
            ec.sub_clusters.append(ic2)
            # return
            
            # No recursive split: return immediately.
            # If ic1 or ic2 remain impure, the next frame that joins them will trigger another check.
            return
    
    def _freeze_hierarchy_index(self):
        """Build the structured GPU index used to accelerate retrieve_topk."""
        if self._index_ready: return
        
        # Guard: if the current strategy did not build an External cluster tree
        # (e.g. chunking mode), exit early to avoid breaking the baseline.
        if not hasattr(self, 'external_clusters'):
            self._index_ready = True
            return

        for u in range(self.num_units):
            unit_ecs = self.external_clusters[u]
            if not unit_ecs: 
                self._gpu_hierarchy[u] = None
                continue
            
            ec_centroids_list = [ec.centroid for ec in unit_ecs]
            if not ec_centroids_list: 
                self._gpu_hierarchy[u] = None
                continue
            
            ec_centroids_tensor = torch.stack(ec_centroids_list).float()
            ec_structs =[]
            
            # Pre-build flattened index for fast EC-to-frame lookup (eliminates per-EC for-loops)
            ec_frame_indices_list = []  # frame IDs per EC
            frame_to_cluster_size = {}  # IC size for each frame (used for cluster-aware LRU)
            
            for ec in unit_ecs:
                ic_centroids_list =[ic.centroid for ic in ec.sub_clusters]
                if not ic_centroids_list:
                    ec_structs.append(None)
                    ec_frame_indices_list.append(torch.tensor([], device=self.device, dtype=torch.long))
                    continue
                
                ic_centroids_tensor = torch.stack(ic_centroids_list).float()
                ic_structs = []
                
                current_ec_frames =[]
                
                for ic in ec.sub_clusters:
                    member_indices = ic.member_indices
                    if not member_indices:
                        ic_structs.append(None)
                        continue
                    
                    idx_tensor = torch.tensor(member_indices, device=self.device, dtype=torch.long)
                    frame_vectors = self.all_frame_reps[u].data[idx_tensor].float()
                    
                    ic_structs.append({
                        'frame_vectors': frame_vectors, 
                        'real_indices': idx_tensor      
                    })
                    
                    current_ec_frames.extend(member_indices)
                    
                    # Record IC size for cluster-aware retrieval / LRU
                    c_size = len(member_indices)
                    for fid in member_indices:
                        frame_to_cluster_size[int(fid)] = c_size
                
                ec_structs.append({
                    'ic_centroids': ic_centroids_tensor, 
                    'ic_structs': ic_structs             
                })
                
                if current_ec_frames:
                    ec_frame_indices_list.append(torch.tensor(current_ec_frames, device=self.device, dtype=torch.long))
                else:
                    ec_frame_indices_list.append(torch.tensor([], device=self.device, dtype=torch.long))
                
            # Pre-compute global LayerNorm + L2 normalization in one pass.
            # LayerNorm is per-feature-dimension, so global pre-computation is 100% mathematically
            # equivalent to computing it per-slice at retrieval time.
            valid_len = self.all_frame_reps[u].length
            global_cand_norm = None
            if valid_len > 0:
                raw_vecs = self.all_frame_reps[u].data[:valid_len].float()
                if raw_vecs.shape[-1] > 1024:
                    v_ln = torch.nn.functional.layer_norm(raw_vecs, raw_vecs.shape[1:])
                    global_cand_norm = torch.nn.functional.normalize(v_ln, p=2, dim=-1, eps=self.eps)
                else:
                    global_cand_norm = torch.nn.functional.normalize(raw_vecs, p=2, dim=-1, eps=self.eps)
            # --- MODIFICATION END ---
            
            self._gpu_hierarchy[u] = {
                'ec_centroids': ec_centroids_tensor, 
                'ec_structs': ec_structs,
                    'ec_frame_indices': ec_frame_indices_list,
                'global_cand_norm': global_cand_norm,
                'global_cand_indices': torch.arange(valid_len, device=self.device, dtype=torch.long),
                'frame_to_cluster_size': frame_to_cluster_size
            }
            
        self._index_ready = True

    def add_block(self, block_k_raw, block_idx, external_emb=None, kv_pair=None):
        """
        [Encoding Phase] Process an incoming video block and perform streaming clustering.
        Args:
            block_k_raw: Mean K vector of the current block (used for Internal clustering)
            external_emb: External embedding of the current block (e.g. CLIP)
            kv_pair: (K, V) raw tensors used to update the Global Anchor
        """
        # Record start time for latency measurement
        torch.cuda.synchronize()
        t0 = time.time()

        # Compute block representative key vector
        if self.strategy == 'clustering_weighted':
            k_mean = block_k_raw.mean(dim=-2, keepdim=True)
            scores = torch.matmul(block_k_raw.float(), k_mean.float().transpose(-1, -2))
            weights = torch.nn.functional.softmax(scores, dim=-2)
            weighted_k = (block_k_raw * weights).sum(dim=-2)
            representative_k = weighted_k.reshape(self.num_units, -1)
        else:  # 'clustering', 'chunking', 'external_internal'
            representative_k = block_k_raw.mean(dim=-2, keepdim=False)
            representative_k = representative_k.reshape(self.num_units, -1)
        
        target_dtype = self.all_frame_reps[0].data.dtype
        # rep_k_normalized = torch.nn.functional.normalize(representative_k.float(), p=2, dim=-1, eps=self.eps)
        # rep_k_normalized = rep_k_normalized.to(target_dtype)
        
        # if self.strategy.startswith('clustering') or self.strategy == 'external_internal':
        #      for u in range(self.num_units):
        #         self.all_frame_reps[u].append(rep_k_normalized[u].unsqueeze(0))

        # 1. Keep the raw block representation for VectorTensor storage
        # 2. Prepare a LayerNorm + L2 normalized version for clustering (Path A-E)

        # Internal: LayerNorm -> L2
        temp_ln = torch.nn.functional.layer_norm(representative_k.float(), representative_k.shape[1:])
        rep_k_for_clustering = torch.nn.functional.normalize(temp_ln, p=2, dim=-1, eps=self.eps)

        # Store raw representation (NOT the normalized version — keeps VectorTensor clean)
        if self.strategy.startswith('clustering') or self.strategy == 'external_internal':
            for u in range(self.num_units):
                self.all_frame_reps[u].append(representative_k[u].unsqueeze(0)) 

        if self.strategy == 'external_internal':
            assert external_emb is not None, "External embedding missing for external_internal strategy"
            
            external_emb_norm = torch.nn.functional.normalize(external_emb.float(), p=2, dim=-1, eps=self.eps)
            
            if self.all_external_reps[0].hidden_size != external_emb_norm.shape[-1]:
                 for u in range(self.num_units):
                     self.all_external_reps[u] = VectorTensor(external_emb_norm.shape[-1], torch.float32, self.device)
            
            for u in range(self.num_units):
                self.all_external_reps[u].append(external_emb_norm[u].unsqueeze(0))
            
            start_event_cluster = torch.cuda.Event(enable_timing=True)
            end_event_cluster = torch.cuda.Event(enable_timing=True)
            start_event_cluster.record()

            for u in range(self.num_units):
                unit_ext_emb = external_emb_norm[u] 
                unit_int_emb = rep_k_for_clustering[u]  # LayerNorm + L2 normalized  
                
                # ... (Path A-E Clustering Logic) ...
                best_ec_idx = -1; max_ec_sim = -1.0
                num_ec = len(self.external_clusters[u])
                target_ec = None 
                target_ic = None 
                
                if num_ec > 0:
                    ec_centroids = torch.stack([ec.centroid for ec in self.external_clusters[u]]) 
                    sims = torch.matmul(unit_ext_emb.unsqueeze(0), ec_centroids.T).squeeze(0) 
                    best_val, best_idx = torch.max(sims, dim=0)
                    max_ec_sim = best_val.item()
                    best_ec_idx = best_idx.item()
                
                debug_path = ""
                
                if num_ec > 0 and max_ec_sim >= self.external_threshold:
                    target_ec = self.external_clusters[u][best_ec_idx]
                    
                    # 1. Accept the frame first: update EC statistics before any split decision
                    if target_ec.ext_vector_sum is None: target_ec.ext_vector_sum = target_ec.centroid.float()
                    
                    # Accumulate External vector
                    temp_ext_sum = target_ec.ext_vector_sum + unit_ext_emb.float()
                    target_ec.ext_vector_sum = temp_ext_sum
                    target_ec.size += 1
                    # Update EC centroid in real time
                    target_ec.centroid = torch.nn.functional.normalize(temp_ext_sum, p=2, dim=0).to(target_ec.centroid.dtype)
                    
                    # 2. Internal Cluster assignment: Path A (join) or Path C (new IC)
                    best_ic_idx = -1; max_ic_sim = -1.0
                    num_ic = len(target_ec.sub_clusters)
                    
                    if num_ic > 0:
                        ic_centroids = torch.stack([ic.centroid.float() for ic in target_ec.sub_clusters])
                        # Compute similarity between the current frame and all existing IC centroids
                        ic_sims = torch.matmul(unit_int_emb.float().unsqueeze(0), ic_centroids.T).squeeze(0)
                        best_ic_val, best_ic_t = torch.max(ic_sims, dim=0)
                        max_ic_sim = best_ic_val.item()
                        best_ic_idx = best_ic_t.item()

                        if DEBUG_IC:
                            l2_dists_list = []
                            if num_ic > 0:
                                l2_dists_list = torch.norm(unit_int_emb.float().unsqueeze(0) - ic_centroids, p=2, dim=1).tolist()
                            cos_sims_list = ic_sims.tolist() if isinstance(ic_sims, torch.Tensor) else []
                            payload = {
                                "Frame_ID": block_idx,
                                "Target_EC": best_ec_idx,
                                "Num_ICs": num_ic,
                                "Max_Cosine": f"{max_ic_sim:.6f}",
                                "Decision": "JOIN" if max_ic_sim >= self.threshold else "NEW_IC",
                                "All_Cosines": [f"{x:.4f}" for x in cos_sims_list],
                                "All_L2_Dists": [f"{x:.4f}" for x in l2_dists_list]
                            }
                            logger.info(f"payload={payload}")

                    # Decision: join existing IC (Path A) or create new IC (Path C)
                    if max_ic_sim >= self.threshold:
                        # Path A: Join IC
                        target_ic = target_ec.sub_clusters[best_ic_idx]
                        
                        # Update IC statistics
                        if target_ic.int_vector_sum is None: target_ic.int_vector_sum = target_ic.centroid.float()
                        target_ic.int_vector_sum += unit_int_emb.float()
                        target_ic.member_indices.append(block_idx)
                        
                        if target_ic.external_emb_sum is None: target_ic.external_emb_sum = unit_ext_emb
                        else: target_ic.external_emb_sum += unit_ext_emb
                        
                        target_ic.size += 1
                        target_ic.centroid = torch.nn.functional.normalize(target_ic.int_vector_sum, p=2, dim=0).to(target_dtype)
                        
                        debug_path = f"A (Join IC, Sim={max_ic_sim:.4f})"
                        
                        # Path B: Check if the IC needs splitting after accepting the new frame
                        torch.cuda.synchronize()
                        t_split_start = time.time()
                        self._check_and_split_ic(u, target_ec, best_ic_idx)
                        if DEBUG_SYSTEM and self.layer_idx % 5 == 0 and u == 0:
                            torch.cuda.synchronize()
                            t_split_cost = (time.time() - t_split_start) * 1000
                            logger.info(f"[System efficiency Layer {self.layer_idx}] IC split latency: {t_split_cost:.2f} ms")

                    else:
                        # Path C: New IC
                        debug_path = "C (New IC)"
                        new_ic = InternalCluster(unit_int_emb, [block_idx], external_emb_sum=unit_ext_emb, int_vector_sum=unit_int_emb.float())
                        target_ec.add_internal_cluster(new_ic)
                        target_ic = new_ic

                    # 3. Post-assignment check: Path D (EC-level split)
                    # The new frame has been placed; now check if the EC has become too heterogeneous.
                    # Splitting is based on the existing IC structure, so no singleton fragments arise.
                    
                    # Recompute EC variance
                    temp_avg_sim = torch.norm(target_ec.ext_vector_sum) / target_ec.size
                    ec_var = 1.0 - temp_avg_sim.item()
                    
                    if target_ec.size > 2 and ec_var > self.external_variance_threshold:
                        if DEBUG_CLUSTER:
                            logger.info(f"Layer{self.layer_idx} Frame {block_idx} -> Path D (Split EC, Var={ec_var:.4f})")
                        debug_path = f"D (Split EC, Var={ec_var:.4f})"
                        self._split_ec(u, best_ec_idx)

                else:
                    # Path E: New EC
                    debug_path = "E (New EC)"
                    new_ic = InternalCluster(unit_int_emb, [block_idx], external_emb_sum=unit_ext_emb, int_vector_sum=unit_int_emb.float())
                    new_ec = ExternalCluster(unit_ext_emb, ext_vector_sum=unit_ext_emb.float())
                    new_ec.add_internal_cluster(new_ic)
                    self.external_clusters[u].append(new_ec)
                    target_ic = new_ic
                
                if self.encoding_strategy == 'cluster_global_anchors' and target_ic and kv_pair is not None:
                    curr_k = kv_pair[0][u]
                    curr_v = kv_pair[1][u]
                    curr_len = self.all_frame_reps[u].length
                    if curr_len > 0:
                        curr_emb = self.all_frame_reps[u].data[curr_len - 1]
                        self._update_anchor(u, target_ic, curr_k, curr_v, curr_emb, block_idx)

                if self.layer_idx == 0 and u == 0 and DEBUG_CLUSTER:
                    logger.info(f"Layer{self.layer_idx} Frame {block_idx} -> {debug_path}")
            
            end_event_cluster.record()
            torch.cuda.synchronize()

            if DEBUG_SYSTEM and self.layer_idx % 5 == 0 and u == 0:
                torch.cuda.synchronize()
                total_cost = (time.time() - t0) * 1000
                logger.info(f"[System efficiency Layer {self.layer_idx}] Encoding latency (Frame {block_idx}): {total_cost:.2f} ms")

            return
        
        elif self.strategy.startswith('clustering'):
            # ... (Existing Clustering Logic) ...
            start_event_cluster = torch.cuda.Event(enable_timing=True)
            end_event_cluster = torch.cuda.Event(enable_timing=True)
            start_event_cluster.record()

            for u in range(self.num_units):
                # new_frame_rep_normalized = rep_k_normalized[u]
                new_frame_rep_normalized = rep_k_for_clustering[u]
                
                max_sim = -1.0
                best_cluster_idx = -1
                
                if self.cluster_representatives[u].length > 0:
                    similarities = self.cluster_representatives[u].get_true_cosine_similarity(new_frame_rep_normalized, eps=self.eps)
                    if similarities.numel() > 0:
                        max_sim_tensor, best_cluster_idx_tensor = torch.max(similarities, dim=0)
                        max_sim = max_sim_tensor.item()
                        best_cluster_idx = best_cluster_idx_tensor.item()
                
                if max_sim >= self.threshold:
                    assigned_cluster_idx = best_cluster_idx
                    old_rep_normalized = self.cluster_representatives[u].data[best_cluster_idx]
                    old_size = self.cluster_sizes[u][best_cluster_idx]
                    
                    new_rep_unnormalized = (old_rep_normalized * old_size + new_frame_rep_normalized) / (old_size + 1)
                    new_rep_normalized_updated = torch.nn.functional.normalize(new_rep_unnormalized.float(), p=2, dim=0, eps=self.eps)
                    
                    self.cluster_representatives[u].data[best_cluster_idx] = new_rep_normalized_updated.to(old_rep_normalized.dtype)
                    self.cluster_members[u][best_cluster_idx].append(block_idx)
                    self.cluster_sizes[u][best_cluster_idx] += 1
                    
                    member_indices = self.cluster_members[u][best_cluster_idx]
                    if len(member_indices) > 4:
                        idx_tensor = torch.tensor(member_indices, device=self.device)
                        member_vectors = self.all_frame_reps[u].data[idx_tensor].float()

                        sims = torch.matmul(member_vectors, new_rep_normalized_updated.unsqueeze(1)).squeeze(1)
                        avg_sim = sims.mean().item()
                        variance = 1.0 - avg_sim

                        if variance > self.variance_threshold:
                            split_res = self._perform_2_means_split(member_vectors)
                            
                            if split_res is not None:
                                centroids, (local_idxs1, local_idxs2) = split_res
                                new_members1 = [member_indices[i] for i in local_idxs1]
                                new_members2 = [member_indices[i] for i in local_idxs2]
                                self.cluster_representatives[u].data[best_cluster_idx] = centroids[0].to(self.cluster_representatives[u].data.dtype)
                                self.cluster_members[u][best_cluster_idx] = new_members1
                                self.cluster_sizes[u][best_cluster_idx] = len(new_members1)
                                self.cluster_representatives[u].append(centroids[1].unsqueeze(0).to(self.cluster_representatives[u].data.dtype))
                                self.cluster_members[u].append(new_members2)
                                self.cluster_sizes[u].append(len(new_members2))
                    
                else:
                    assigned_cluster_idx = len(self.cluster_members[u])
                    self.cluster_representatives[u].append(new_frame_rep_normalized.unsqueeze(0).to(self.cluster_representatives[u].data.dtype))
                    self.cluster_members[u].append([block_idx])
                    self.cluster_sizes[u].append(1)
                
                self.logger.log_encoding_similarity(block_idx, max_sim, assigned_cluster_idx)
            
            end_event_cluster.record()
            torch.cuda.synchronize()
        
        else: # chunking
            rep_k_unsqueezed = representative_k[:, None, :]
            for u in range(self.num_units):
                self.block_k[u].append(rep_k_unsqueezed[u])

    def _update_anchor_batch_helper(self, u, target_ic, kv_pair_batch, batch_idx, global_idx, num_blocks):
        """[Batch-K] Helper for anchor extraction, fully decoupled from the per-frame _update_anchor."""
        block_size = kv_pair_batch[0].size(2) // num_blocks
        st = batch_idx * block_size
        curr_k = kv_pair_batch[0][u, :, st:st+block_size, :]
        curr_v = kv_pair_batch[1][u, :, st:st+block_size, :]
        curr_emb = self.all_frame_reps[u].data[global_idx]
        self._update_anchor(u, target_ic, curr_k, curr_v, curr_emb, global_idx)

    def add_blocks_batch(self, block_k_raw_batch, start_block_idx, num_blocks, external_emb_batch=None, kv_pair_batch=None):
        """[V6 Batch-K] Lossless vectorized batch clustering.
        Produces a cluster structure identical to frame-by-frame processing while
        eliminating most fragmented CUDA kernel launches:
        1. Pre-compute LayerNorm + L2 normalization for all N frames in one matrix op.
        2. Restore immediate split (no lazy deferral) to preserve strict temporal causality.
        """
        torch.cuda.synchronize()
        t0 = time.time()
        
        # =========================================================
        # Phase 1: Stateless math — vectorized across the entire batch
        # (eliminates ~90% of CUDA kernel launch overhead)
        # =========================================================
        representative_k_batch = block_k_raw_batch  # [U, N, Rep_Dim]
        
        # Internal global preprocessing: LayerNorm + L2 normalize in one pass
        temp_ln = torch.nn.functional.layer_norm(representative_k_batch.float(), representative_k_batch.shape[2:])
        rep_k_for_clustering_batch = torch.nn.functional.normalize(temp_ln, p=2, dim=-1, eps=self.eps)
        
        # Store raw frame representations
        if self.strategy.startswith('clustering') or self.strategy == 'external_internal':
            for u in range(self.num_units):
                self.all_frame_reps[u].append(representative_k_batch[u])
                
        if self.strategy == 'external_internal':
            assert external_emb_batch is not None, "External embedding missing"
            
            # External global preprocessing: L2 normalize in one pass
            external_emb_norm_batch = torch.nn.functional.normalize(external_emb_batch.float(), p=2, dim=-1, eps=self.eps)
            
            if self.all_external_reps[0].hidden_size != external_emb_norm_batch.shape[-1]:
                 for u in range(self.num_units):
                     self.all_external_reps[u] = VectorTensor(external_emb_norm_batch.shape[-1], torch.float32, self.device)
            
            for u in range(self.num_units):
                self.all_external_reps[u].append(external_emb_norm_batch[u])
                
            # =========================================================
            # Phase 2: State machine — strictly ordered routing
            # (preserves Markov causality; zero accuracy degradation)
            # =========================================================
            for u in range(self.num_units):
                unit_ext_emb_batch = external_emb_norm_batch[u] #[N, Ext_Dim]
                unit_int_emb_batch = rep_k_for_clustering_batch[u] #[N, Int_Dim]
                
                # Initialize dirty-flag sets for lazy split deferred settlement
                dirty_ics = set()
                dirty_ecs = set()

                # Iterate in strict physical time order (causality guarantee)
                for i in range(num_blocks):
                    global_idx = start_block_idx + i
                    unit_ext_emb = unit_ext_emb_batch[i]
                    unit_int_emb = unit_int_emb_batch[i]
                    
                    # Replicate the per-frame EC/IC routing logic from add_block
                    best_ec_idx = -1; max_ec_sim = -1.0
                    num_ec = len(self.external_clusters[u])
                    target_ec = None 
                    target_ic = None 
                    
                    # 1. Find the best matching EC
                    if num_ec > 0:
                        ec_centroids = torch.stack([ec.centroid for ec in self.external_clusters[u]]) 
                        sims = torch.matmul(unit_ext_emb.unsqueeze(0), ec_centroids.T).squeeze(0) 
                        best_val, best_idx = torch.max(sims, dim=0)
                        max_ec_sim = best_val.item()
                        best_ec_idx = best_idx.item()
                        
                    if num_ec > 0 and max_ec_sim >= self.external_threshold:
                        target_ec = self.external_clusters[u][best_ec_idx]
                        
                        # 2. Accept the new frame; update EC centroid
                        if target_ec.ext_vector_sum is None: target_ec.ext_vector_sum = target_ec.centroid.float()
                        temp_ext_sum = target_ec.ext_vector_sum + unit_ext_emb.float()
                        target_ec.ext_vector_sum = temp_ext_sum
                        target_ec.size += 1
                        target_ec.centroid = torch.nn.functional.normalize(temp_ext_sum, p=2, dim=0).to(target_ec.centroid.dtype)
                        
                        # 3. Find the best matching IC
                        best_ic_idx = -1; max_ic_sim = -1.0
                        num_ic = len(target_ec.sub_clusters)
                        
                        if num_ic > 0:
                            ic_centroids = torch.stack([ic.centroid.float() for ic in target_ec.sub_clusters])
                            ic_sims = torch.matmul(unit_int_emb.float().unsqueeze(0), ic_centroids.T).squeeze(0)
                            best_ic_val, best_ic_t = torch.max(ic_sims, dim=0)
                            max_ic_sim = best_ic_val.item()
                            best_ic_idx = best_ic_t.item()
                            
                        # 4. IC routing decision
                        if max_ic_sim >= self.threshold:
                            # Path A: Join IC
                            target_ic = target_ec.sub_clusters[best_ic_idx]
                            
                            if target_ic.int_vector_sum is None: target_ic.int_vector_sum = target_ic.centroid.float()
                            target_ic.int_vector_sum += unit_int_emb.float()
                            target_ic.member_indices.append(global_idx)
                            
                            if target_ic.external_emb_sum is None: target_ic.external_emb_sum = unit_ext_emb
                            else: target_ic.external_emb_sum += unit_ext_emb
                            
                            target_ic.size += 1
                            target_ic.centroid = torch.nn.functional.normalize(target_ic.int_vector_sum, p=2, dim=0).to(self.all_frame_reps[0].data.dtype)
                            
                            if getattr(self, 'enable_lazy_split', True):
                                # Lazy split: mark dirty, defer actual split to the end of the batch
                                dirty_ics.add((best_ec_idx, best_ic_idx))
                            else:
                                with Profiler.get_instance().timer("Enc: No Lazy Cluster Split", "compute"):
                                    # Eager split: split immediately (original per-frame logic)
                                    self._check_and_split_ic(u, target_ec, best_ic_idx)
                                    
                        else:
                            # Path C: New IC
                            new_ic = InternalCluster(unit_int_emb, [global_idx], external_emb_sum=unit_ext_emb, int_vector_sum=unit_int_emb.float())
                            target_ec.add_internal_cluster(new_ic)
                            target_ic = new_ic

                        if getattr(self, 'enable_lazy_split', True):
                            # Lazy EC split: defer
                            dirty_ecs.add(best_ec_idx)
                        else:
                            with Profiler.get_instance().timer("Enc: No Lazy Cluster Split", "compute"):
                                # Eager EC split
                                temp_avg_sim = torch.norm(target_ec.ext_vector_sum) / target_ec.size
                                ec_var = 1.0 - temp_avg_sim.item()
                                if target_ec.size > 2 and ec_var > self.external_variance_threshold:
                                    self._split_ec(u, best_ec_idx)
                                
                        # 5. Immediate EC-level split check (accuracy-critical: must not be deferred)
                        temp_avg_sim = torch.norm(target_ec.ext_vector_sum) / target_ec.size
                        ec_var = 1.0 - temp_avg_sim.item()
                        if target_ec.size > 2 and ec_var > self.external_variance_threshold:
                            self._split_ec(u, best_ec_idx)

                    else:
                        # Path E: New EC
                        new_ic = InternalCluster(unit_int_emb, [global_idx], external_emb_sum=unit_ext_emb, int_vector_sum=unit_int_emb.float())
                        new_ec = ExternalCluster(unit_ext_emb, ext_vector_sum=unit_ext_emb.float())
                        new_ec.add_internal_cluster(new_ic)
                        self.external_clusters[u].append(new_ec)
                        target_ic = new_ic
                        
                    # 6. Anchor update: must follow the same temporal order as the frame
                    if self.encoding_strategy == 'cluster_global_anchors' and target_ic and kv_pair_batch is not None:
                        if hasattr(self, '_update_anchor_batch_helper'):
                            self._update_anchor_batch_helper(u, target_ic, kv_pair_batch, i, global_idx, num_blocks)

                # Lazy split settlement: process all deferred splits at end of batch
                if getattr(self, 'enable_lazy_split', True):
                        # Step 1: settle IC-level splits
                        for ec_idx, ic_idx in list(dirty_ics):
                            with Profiler.get_instance().timer("Enc: Lazy Cluster Split", "compute"):
                                target_ec = self.external_clusters[u][ec_idx]
                                self._check_and_split_ic(u, target_ec, ic_idx)

                        # Step 2: settle EC-level splits
                        for ec_idx in list(dirty_ecs):
                            with Profiler.get_instance().timer("Enc: Lazy Cluster Split", "compute"):
                                target_ec = self.external_clusters[u][ec_idx]
                                temp_avg_sim = torch.norm(target_ec.ext_vector_sum) / target_ec.size
                                ec_var = 1.0 - temp_avg_sim.item()
                                if target_ec.size > 2 and ec_var > self.external_variance_threshold:
                                        self._split_ec(u, ec_idx)

        else:
            # Defensive fallback: compatibility with chunking and other non-external_internal strategies
            for i in range(num_blocks):
                curr_k = block_k_raw_batch[:, i, :]
                ext_fallback = external_emb_batch[:, i, :] if external_emb_batch is not None else None
                self.add_block(curr_k, start_block_idx + i, external_emb=ext_fallback, kv_pair=None)

        if DEBUG_SYSTEM and self.layer_idx % 5 == 0:
            torch.cuda.synchronize()
            total_cost = (time.time() - t0) * 1000
            logger.info(f"[System efficiency Layer {self.layer_idx}] Batch-K clustering latency ({num_blocks} frames): {total_cost:.2f} ms")


    def _get_best_candidates_from_members(self, u, member_indices, query_vec, k_needed):
        """Helper: retrieve the Top-K most similar frames from a cluster's member list."""
        if len(member_indices) == 0:
            return []
        
        if len(member_indices) <= k_needed:
            return member_indices

        indices_tensor = torch.tensor(member_indices, device=self.device, dtype=torch.long)
        member_vectors = self.all_frame_reps[u].data[indices_tensor].float()
        q = query_vec.unsqueeze(0).float()
        scores = torch.matmul(q, member_vectors.T).squeeze(0)
        _, top_indices_local = torch.topk(scores, k=k_needed)
        best_indices = [member_indices[i] for i in top_indices_local.cpu().tolist()]
        return best_indices
    
    def _debug_calc_avg_sim(self, u, frame_indices, query_vec):
        """Debug helper: compute the average similarity between the selected frames and the query."""
        if len(frame_indices) == 0: return 0.0
        
        # Fetch frame vectors
        idx_tensor = torch.tensor(frame_indices, device=self.device, dtype=torch.long)
        vectors = self.all_frame_reps[u].data[idx_tensor].float()  # (K, D)
        
        # Compute similarities
        q = query_vec.unsqueeze(0).float()  # (1, D)
        sims = torch.matmul(q, vectors.T).squeeze(0)  # (K,)
        
        return sims.mean().item()

    def retrieve_topk(self, query_vectors, topk, **kwargs):
        """
        [QA Phase] Core retrieval logic.
        Retrieves the Top-K most relevant frames using the configured strategy
        (Hierarchical, Global Sort, or IC Sort).
        
        Args:
            query_vectors: Internal Query for the current layer (Batch, D)
            topk: Total number of frames to retrieve
            kwargs: Optional keys: external_query, use_cluster_sampling, etc.
        """
        # Deadlock guard: skip synchronize inside the prefetch worker thread
        _is_prefetch = getattr(self, '_in_prefetch', False)
        if DEBUG_SYSTEM and not _is_prefetch:
            torch.cuda.synchronize()
        t0 = time.time()
        
        # Fallback: handle the case where video data is still in the global_remainder buffer
        # and has not yet been admitted to the cluster pool.
        
        num_global_block = kwargs.get("num_global_block", 0)
        
        # If the cluster pool has fewer blocks than topk, the video is likely still in the buffer
        if num_global_block <= topk:
            global_remainder = kwargs.get("global_remainder", None)
            from_group_kv_func = kwargs.get("from_group_kv_func", None)
            block_size = kwargs.get("block_size", 1)
            n_init = kwargs.get("n_init", 0)
            init_exc = kwargs.get("init_exc", True)

            # Trigger only during the encoding phase (init_exc=False) when the buffer has data
            if not init_exc and global_remainder is not None:
                 raw_len = global_remainder[0].size(-2)
                 if raw_len > n_init:
                     # 1. Extract buffer data (strip system prompt)
                     # global_k shape: (Batch, Heads, SeqLen, HeadDim)
                     global_k = global_remainder[0][:, :, n_init:, :]
                     
                     # GQA alignment
                     if from_group_kv_func is not None:
                         global_k = from_group_kv_func(global_k)
                     
                     # 2. Count the number of complete blocks in the buffer
                     real_block_count = global_k.size(-2) // block_size if block_size > 0 else 0
                     
                     if real_block_count > 0:
                        # Branch A: Short video (<= topk blocks) — select all, no similarity needed
                        if real_block_count <= topk:
                            # if self.layer_idx == 0:
                            #      logger.info(f"  [Buffer Retrieve] Short Video Bypass: All {real_block_count} blocks")
                            return [list(range(real_block_count)) for _ in range(self.num_units)], torch.tensor([])
                        
                        # Branch B: Medium-length video (> topk blocks, buffer not yet clustered)
                        # Must compute similarity on-the-fly, following the chunking pipeline
                        else:
                            # if self.layer_idx == 0:
                            #      logger.info(f"  [Buffer Retrieve] Middle Video Rescue: Select {topk}/{real_block_count}")

                            # A. Preprocessing: truncate to complete blocks only
                            valid_len = real_block_count * block_size
                            k_valid = global_k[:, :, :valid_len, :]
                            
                            # B. Reshape to block granularity
                            #    (Batch, Heads, TotalLen, Dim) -> (Batch, Heads, Blocks, BlockSize, Dim)
                            B, H, _, D = k_valid.shape
                            k_reshaped = k_valid.view(B, H, real_block_count, block_size, D)
                            
                            # C. Compute block mean (Mean Pooling)
                            # (Batch, Heads, Blocks, Dim)
                            k_mean = k_reshaped.mean(dim=3)
                            
                            # D. Flatten Heads and Dim to match Query shape
                            # (Batch, Heads, Blocks, Dim) -> (Batch, Blocks, Heads, Dim) -> (Batch, Blocks, H*D)
                            block_vecs = k_mean.permute(0, 2, 1, 3).reshape(B, real_block_count, -1)
                            
                            # E. Strict cosine similarity computation
                            # 1. Normalize query (B, H*D)
                            #    Strictly follows VectorTensor convention: Normalize -> Matmul
                            q_norm = torch.nn.functional.normalize(query_vectors.float(), p=2, dim=-1, eps=1e-8)
                            
                            # 2. Normalize block vectors (B, Blocks, H*D)
                            v_norm = torch.nn.functional.normalize(block_vecs.float(), p=2, dim=-1, eps=1e-8)
                            
                            # 3. Matrix multiply to compute similarity scores
                            #    (B, 1, Dim) @ (B, Dim, Blocks) -> (B, 1, Blocks) -> (B, Blocks)
                            temp_logits = torch.matmul(q_norm.unsqueeze(1), v_norm.transpose(1, 2)).squeeze(1)
                            
                            # F. Select Top-K and sort by timestamp (required for RoPE)
                            _, top_indices = torch.topk(temp_logits, k=topk, dim=1)
                            top_indices_sorted, _ = torch.sort(top_indices, dim=1)
                            
                            ret = top_indices_sorted.cpu().tolist()
                            
                            # Return selected indices and scores
                            return ret, temp_logits
        # ================= [FIX END] =================

        # =========================================================================
        # Strategy 1: External + Internal (the primary retrieval strategy)
        # =========================================================================
        if self.strategy == 'external_internal':
            # 1. Lazy index build check
            if not self._index_ready:
                self._freeze_hierarchy_index()
            
            # 2. Obtain External Query (e.g. CLIP embedding)
            external_query = kwargs.get('external_query', None)
            if external_query is None: 
                # Cannot perform external coarse filtering without an external query; return empty
                return [[] for _ in range(self.num_units)], torch.tensor([])
            
            use_cluster_sampling = kwargs.get('use_cluster_sampling', False)
            
            # ------------------------------------------------------------------
            # Step 1: External Coarse Filtering
            # Goal: select the Top-K most relevant External Clusters (ECs)
            # ------------------------------------------------------------------
            
            # Normalize External Query
            ext_q_norm = torch.nn.functional.normalize(external_query.float(), p=2, dim=-1, eps=self.eps).squeeze(1)
            
            # Store selected EC indices and scores for each batch unit
            top_ec_indices_list = []
            top_ec_scores_list = [] 
            
            for u in range(self.num_units):
                gpu_data = self._gpu_hierarchy[u]
                if gpu_data is None: 
                    top_ec_indices_list.append([])
                    top_ec_scores_list.append([])
                    continue
                
                # Compute similarity between External Query and all EC centroids
                ec_centroids = gpu_data['ec_centroids'] # (Num_EC, D_ext)
                ext_sims = torch.matmul(ec_centroids, ext_q_norm[u].unsqueeze(1)).squeeze(1)
                
                # Select Top-K ECs
                k_ext = min(ec_centroids.size(0), self.topk_external)
                top_scores, top_ec_indices = torch.topk(ext_sims, k=k_ext)
                top_ec_indices_list.append(top_ec_indices.tolist())
                top_ec_scores_list.append(top_scores.tolist())

            # ------------------------------------------------------------------
            # Step 2: Internal Fine Retrieval
            # Goal: select the final Top-K frames from within the selected ECs
            # ------------------------------------------------------------------
            all_units_ret = []
            # Normalize Internal Query
            int_query = torch.nn.functional.normalize(query_vectors.float(), p=2, dim=-1, eps=self.eps)
            
            for u in range(self.num_units):
                gpu_data = self._gpu_hierarchy[u]
                # Edge case: no GPU hierarchy data available; return empty
                if gpu_data is None: 
                    all_units_ret.append(torch.tensor([], device=self.device, dtype=torch.long))
                    continue
                
                top_ec_indices = top_ec_indices_list[u]
                top_ec_scores = top_ec_scores_list[u]
                ec_structs = gpu_data['ec_structs']
                curr_q = int_query[u].unsqueeze(0) # (1, D_int)

                # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                # Branch A: Global Sort
                # Logic: discard EC/IC boundaries; gather all frames from selected ECs
                # and rank them globally by Internal similarity.
                # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                if self.retrieve_method == 'global_sort':
                    global_cand_norm = gpu_data.get('global_cand_norm')
                    if global_cand_norm is None:
                        all_units_ret.append(torch.tensor([], device=self.device, dtype=torch.long))
                        continue
                        
                    # 1. Fast candidate extraction (eliminates Python for-loops and torch.cat overhead)
                    if len(top_ec_indices) == len(ec_structs):
                        # All ECs selected: use the global pre-built index directly
                        cand_norm = global_cand_norm
                        all_indices = gpu_data['global_cand_indices']
                    else:
                        # Partial ECs: gather from the precomputed global matrix via integer index
                        selected_indices = [gpu_data['ec_frame_indices'][idx] for idx in top_ec_indices]
                        all_indices = torch.cat(selected_indices) if selected_indices else torch.tensor([], device=self.device, dtype=torch.long)
                        if all_indices.numel() == 0:
                            all_units_ret.append(torch.tensor([], device=self.device, dtype=torch.long))
                            continue
                        cand_norm = global_cand_norm[all_indices]
                        
                    # 2. Normalize the query vector (1, D)
                    q_float = query_vectors.float()
                    if q_float.shape[-1] > 1024:
                        q_ln = torch.nn.functional.layer_norm(q_float, q_float.shape[1:])
                        curr_q_norm = torch.nn.functional.normalize(q_ln, p=2, dim=-1, eps=self.eps)[u].unsqueeze(0)
                    else:
                        curr_q_norm = torch.nn.functional.normalize(q_float, p=2, dim=-1, eps=self.eps)[u].unsqueeze(0)
                        
                    # 3. Single GPU matrix multiply to compute all similarities
                    scores = torch.matmul(curr_q_norm, cand_norm.T).squeeze(0)

                    # 4. Global Top-K truncation
                    k_needed = min(topk, scores.size(0))
                    if k_needed > 0:
                        _, top_idxs = torch.topk(scores, k=k_needed)
                        final_selected_frames = all_indices[top_idxs]
                        
                        # 5. Sort by timestamp (required for Attention computation)
                        final_selected_frames, _ = torch.sort(final_selected_frames)


                        
                        all_units_ret.append(final_selected_frames)
                        
                        if DEBUG_RETRIEVAL_COMPARE and u == 0:
                            frame_provenance = {}
                            ec_ic_structure = {}
                            for ec_idx in top_ec_indices:
                                ec_data = ec_structs[ec_idx]
                                if ec_data is None or not ec_data['ic_structs']: continue
                                ec_ic_structure[ec_idx] = {}
                                for ic_local_idx, ic_data in enumerate(ec_data['ic_structs']):
                                    if ic_data is not None:
                                        f_idxs = ic_data['real_indices']
                                        ec_ic_structure[ec_idx][ic_local_idx] = f_idxs.size(0)
                                        for fid in f_idxs.tolist():
                                            frame_provenance[fid] = (ec_idx, ic_local_idx)
                            logger.info(f"\n[Retrieval Comparison Layer{self.layer_idx}] Mode: global_sort")
                            global_ids = final_selected_frames.tolist()
                            global_ids_scores = scores[top_idxs].tolist()
                            
                            # Simulate hierarchical retrieval for comparison
                            hier_ids = []
                            hier_set = set()
                            max_f_ext = self.max_frames_per_external
                            max_f_int = self.max_frames_per_internal
                            curr_q_sim = curr_q 
                            candidate_pool = []
                            
                            for ec_idx in top_ec_indices:
                                if len(hier_ids) >= topk: break
                                ec_data = ec_structs[ec_idx]
                                if ec_data is None: continue
                                
                                # Sort ICs by centroid score
                                ic_centroids = ec_data['ic_centroids']
                                ic_sims = torch.matmul(curr_q_sim, ic_centroids.T).squeeze(0)
                                sorted_ic_indices = torch.argsort(ic_sims, descending=True).tolist()
                                ec_selected_count = 0
                                
                                for ic_local_idx in sorted_ic_indices:
                                    ic_data = ec_data['ic_structs'][ic_local_idx]
                                    if ic_data is None: continue
                                    f_vecs = ic_data['frame_vectors']
                                    f_idxs = ic_data['real_indices']
                                    f_scores = torch.matmul(curr_q_sim, f_vecs.T).squeeze(0)
                                    sorted_local = torch.argsort(f_scores, descending=True).tolist()
                                    
                                    ic_candidates = []
                                    for loc_i in sorted_local:
                                        ic_candidates.append((f_scores[loc_i].item(), f_idxs[loc_i].item()))
                                    
                                    # Quota check
                                    frames_to_add = ic_candidates[:max_f_int]
                                    frames_pool = ic_candidates[max_f_int:]
                                    
                                    remaining_ec = max_f_ext - ec_selected_count
                                    if remaining_ec > 0:
                                        real_add = frames_to_add[:remaining_ec]
                                        real_pool = frames_to_add[remaining_ec:] + frames_pool
                                        for sc, fix in real_add:
                                            if len(hier_ids) < topk:
                                                if fix not in hier_set:
                                                    hier_ids.append(fix)
                                                    hier_set.add(fix)
                                                    ec_selected_count += 1
                                        candidate_pool.extend(real_pool)
                                    else:
                                        candidate_pool.extend(frames_to_add + frames_pool)
                            
                            # Backfill from candidate pool
                            if len(hier_ids) < topk:
                                candidate_pool.sort(key=lambda x: x[0], reverse=True)
                                for sc, fix in candidate_pool:
                                    if len(hier_ids) >= topk: break
                                    if fix not in hier_set:
                                        hier_ids.append(fix)
                                        hier_set.add(fix)
                            
                            hier_ids.sort()
                            
                            # Compute overlap rate
                            overlap = len(set(global_ids) & set(hier_ids))
                            overlap_ratio = (overlap / len(global_ids)) * 100 if global_ids else 0
                            
                            logger.info(f"  > Global IDs ({len(global_ids)}): {global_ids}")
                            logger.info(f"  > Hier   IDs ({len(hier_ids)}): {hier_ids}")
                            logger.info(f"  > Overlap: {overlap}/{len(global_ids)} ({overlap_ratio:.1f}%)")
                            logger.info(f"  > Global Scores ({len(global_ids_scores)}): {global_ids_scores}")

                            # Print global sort distribution details
                            from collections import defaultdict
                            ec_distribution = defaultdict(list)
                            ic_distribution = defaultdict(lambda: defaultdict(int))
                            
                            for fid in global_ids:
                                if fid in frame_provenance:
                                    ec, ic = frame_provenance[fid]
                                    ec_distribution[ec].append(fid)
                                    ic_distribution[ec][ic] += 1
                            
                            logger.info(f"  > Global Sort Distribution (Ordered by Ext Score):")
                            for rank, (ec_idx, ext_score) in enumerate(zip(top_ec_indices, top_ec_scores)):
                                selected_fids = ec_distribution.get(ec_idx, [])
                                sel_count = len(selected_fids)
                                ic_stats = ec_ic_structure.get(ec_idx, {})
                                total_frames = sum(ic_stats.values())
                                
                                if total_frames == 0: continue
                                
                                tag = ""
                                if sel_count > self.max_frames_per_external:
                                    tag = f"[BREAK EC LIMIT {self.max_frames_per_external}]"
                                elif sel_count == 0:
                                    tag = "[SKIPPED]"
                                
                                logger.info(f"    #{rank} EC[{ec_idx}] (ExtScore: {ext_score:.4f}): {sel_count}/{total_frames} frames {tag}")
                                
                                if sel_count > 0:
                                    ic_breakdown_strs = []
                                    for ic_idx, count in ic_distribution[ec_idx].items():
                                        total_in_ic = ic_stats.get(ic_idx, 0)
                                        ic_tag = ""
                                        if count > self.max_frames_per_internal:
                                            ic_tag = f" [BREAK IC {self.max_frames_per_internal}]"
                                        ic_breakdown_strs.append(f"IC{ic_idx}:{count}/{total_in_ic}{ic_tag}")
                                    logger.info(f"       -> {', '.join(ic_breakdown_strs)}")
                    else:
                        all_units_ret.append(torch.tensor([], device=self.device, dtype=torch.long))

                # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                # Branch B: Two-Stage IC Sort
                # Flow: IC centroid coarse ranking -> build candidate pool -> frame-level fine ranking within pool
                # Efficiency: orders of magnitude faster than Global Sort (only scores the pool)
                # Accuracy: LayerNorm+L2 ensures full alignment with the Attention mechanism
                # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                elif self.retrieve_method == 'IC_sort':
                    # Expansion factor: controls the size of the candidate pool.
                    # factor=1.0: greedy selection, rank only within selected clusters (fastest)
                    # factor=2.0: recommended. Examine 2x frames to filter noise from good clusters.
                    RERANK_FACTOR = 2.0 
                    # RERANK_FACTOR = 3.0 
                    
                    # 1. Collect all candidate IC centroids (coarse candidates)
                    candidate_ic_centroids = []
                    ic_payloads = []  # Flat list: flat_idx -> ic_data_structure
                    
                    for ec_idx in top_ec_indices:
                        ec_data = ec_structs[ec_idx]
                        if ec_data is None or ec_data['ic_centroids'] is None: continue
                        
                        # ic_centroids are already LN+L2-normalized (ensured during add_block/split)
                        centroids = ec_data['ic_centroids'] 
                        
                        for ic_local_idx in range(centroids.size(0)):
                            ic_info = ec_data['ic_structs'][ic_local_idx]
                            if ic_info is None: continue
                            
                            candidate_ic_centroids.append(centroids[ic_local_idx])
                            ic_payloads.append(ic_info)

                    # Edge case: no candidate ICs available
                    if not candidate_ic_centroids:
                        all_units_ret.append(torch.tensor([], device=self.device, dtype=torch.long))
                        continue

                    # 2. Batch compute IC centroid scores (coarse scoring)
                    # One matrix multiply covers all ICs: all_centroids_tensor shape: (Total_ICs, D)
                    all_centroids_tensor = torch.stack(candidate_ic_centroids)
                    ic_scores = torch.matmul(curr_q, all_centroids_tensor.T).squeeze(0)
                    
                    # Sort ICs by score (descending)
                    _, sorted_ic_indices = torch.sort(ic_scores, descending=True)
                    
                    # 3. Build the frame-level candidate pool
                    target_pool_size = int(topk * RERANK_FACTOR)
                    # Pool size must be at least topk to guarantee enough candidates
                    target_pool_size = max(target_pool_size, topk)
                    
                    pool_vectors = []
                    pool_indices = []
                    current_pool_count = 0
                    debug_clusters_scanned = 0
                    
                    for flat_idx in sorted_ic_indices.tolist():
                        # Keep adding the most relevant clusters until pool is full
                        if current_pool_count >= target_pool_size:
                            break
                            
                        ic_info = ic_payloads[flat_idx]
                        f_vecs = ic_info['frame_vectors']  # Raw vectors
                        f_idxs = ic_info['real_indices']
                        
                        pool_vectors.append(f_vecs)
                        pool_indices.append(f_idxs)
                        current_pool_count += f_vecs.size(0)
                        debug_clusters_scanned += 1
                    
                    if not pool_vectors:
                        all_units_ret.append(torch.tensor([], device=self.device, dtype=torch.long))
                        continue

                    # 4. Frame-level fine ranking within the candidate pool
                    # This step ensures accuracy: even with factor=1, the best frames
                    # within selected clusters are still chosen precisely.
                    cand_vecs_raw = torch.cat(pool_vectors, dim=0)  # (Pool_Size, D)
                    cand_idxs = torch.cat(pool_indices, dim=0)
                    
                    # Apply LayerNorm + L2 normalization to address LLM vector anisotropy
                    if cand_vecs_raw.shape[-1] > 1024:
                        v_ln = torch.nn.functional.layer_norm(cand_vecs_raw, cand_vecs_raw.shape[1:])
                        v_norm = torch.nn.functional.normalize(v_ln, p=2, dim=-1, eps=self.eps)
                    else:
                        v_norm = torch.nn.functional.normalize(cand_vecs_raw, p=2, dim=-1, eps=self.eps)
                    
                    # Compute final scores (Pool_Size << Global Size, so this is fast)
                    frame_scores = torch.matmul(curr_q, v_norm.T).squeeze(0)
                    
                    # Select final Top-K
                    k_final = min(topk, frame_scores.size(0))
                    _, top_f_indices = torch.topk(frame_scores, k=k_final)
                    
                    # Map back to real frame IDs
                    final_selected_frames = cand_idxs[top_f_indices]
                    
                    # 5. Sort by timestamp (required for RoPE)
                    final_selected_frames, _ = torch.sort(final_selected_frames)
                    

                    all_units_ret.append(final_selected_frames)

                # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                # Branch C: Hierarchical Retrieval
                # Flow: EC coarse ranking -> IC centroid fine ranking -> frame-level fine ranking
                # Strictly follows the EC -> IC hierarchy with per-level quotas.
                # >>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
                else: 
                    final_selected_frames = []
                    selected_set = set()
                    candidate_pool = []  # Overflow pool for backfilling
                    
                    # Iterate over selected ECs (ordered by External similarity, highest first)
                    for loop_idx, ec_idx in enumerate(top_ec_indices):
                        if len(final_selected_frames) >= topk:
                            break

                        ec_data = ec_structs[ec_idx]
                        if ec_data is None: continue
                        
                        # Sub-branch B.1: Uniform sampling
                        if use_cluster_sampling:
                            # Collect all frames under this EC
                            all_ec_frames_list = []
                            if ec_data['ic_structs']:
                                for ic_data in ec_data['ic_structs']:
                                    if ic_data is not None:
                                        all_ec_frames_list.append(ic_data['real_indices'])
                            
                            if not all_ec_frames_list: continue

                            # Concatenate and sort
                            all_ec_frames = torch.cat(all_ec_frames_list)
                            all_ec_frames, _ = torch.sort(all_ec_frames)
                            num_available = all_ec_frames.size(0)

                            # Compute quota (bounded by max_frames_per_external)
                            target_count = min(num_available, self.max_frames_per_external)

                            # Uniform sampling via linspace
                            if target_count > 0:
                                indices = torch.linspace(0, num_available - 1, steps=target_count).long().to(self.device)
                                for idx in indices:
                                    fid = all_ec_frames[idx].item()
                                    if fid not in selected_set:
                                        final_selected_frames.append(fid)
                                        selected_set.add(fid)
                        
                        # Sub-branch B.2: Semantic sorting
                        else:
                            # 1. Sort ICs within this EC by centroid score
                            ic_centroids = ec_data['ic_centroids']
                            ic_sims = torch.matmul(curr_q, ic_centroids.T).squeeze(0)
                            sorted_ic_indices = torch.argsort(ic_sims, descending=True).tolist()
                            
                            ec_selected_count = 0
                            ic_structs = ec_data['ic_structs']
                            
                            # 2. Iterate over ICs
                            for ic_local_idx in sorted_ic_indices:
                                ic_data = ic_structs[ic_local_idx]
                                if ic_data is None: continue
                                
                                frame_vectors = ic_data['frame_vectors']
                                real_indices = ic_data['real_indices']
                                
                                # 3. Compute frame-level scores and sort
                                frame_scores = torch.matmul(curr_q, frame_vectors.T).squeeze(0)
                                sorted_local_indices = torch.argsort(frame_scores, descending=True).tolist()
                                
                                ic_candidates = []
                                for loc_idx in sorted_local_indices:
                                    ic_candidates.append((frame_scores[loc_idx].item(), real_indices[loc_idx].item()))
                                
                                # 4. Apply quota limits (IC limit and EC limit)
                                frames_to_add = ic_candidates[:self.max_frames_per_internal]
                                frames_pool = ic_candidates[self.max_frames_per_internal:]
                                
                                remaining_ec = self.max_frames_per_external - ec_selected_count
                                
                                if remaining_ec > 0:
                                    real_add = frames_to_add[:remaining_ec]
                                    real_pool = frames_to_add[remaining_ec:] + frames_pool
                                    
                                    for sc, fix in real_add:
                                        if len(final_selected_frames) < topk:
                                            if fix not in selected_set:
                                                final_selected_frames.append(fix)
                                                selected_set.add(fix)
                                                ec_selected_count += 1
                                    candidate_pool.extend(real_pool)
                                else:
                                    candidate_pool.extend(frames_to_add + frames_pool)

                    # Backfill: if TopK not reached, pull from candidate pool
                    if len(final_selected_frames) < topk and candidate_pool:
                        candidate_pool.sort(key=lambda x: x[0], reverse=True)
                        for score, frame_idx in candidate_pool:
                            if len(final_selected_frames) >= topk: break
                            if frame_idx not in selected_set:
                                final_selected_frames.append(frame_idx)
                                selected_set.add(frame_idx)
                    
                    final_selected_frames.sort()
                    all_units_ret.append(torch.tensor(final_selected_frames, device=self.device, dtype=torch.long))
            
            if DEBUG_SYSTEM and self.layer_idx % 5 == 0:
                if DEBUG_SYSTEM and not _is_prefetch:
                    torch.cuda.synchronize()
                t_cost = (time.time() - t0) * 1000
                logger.info(f"[System efficiency Layer {self.layer_idx}] Retrieval cost: {t_cost:.2f} ms")

            return all_units_ret, torch.tensor([])

        if self.strategy.startswith('clustering'):
            # ... (Simple Clustering Retrieval Logic) ...
            use_cluster_sampling = kwargs.get("use_cluster_sampling", False)
            frames_per_cluster = kwargs.get("frames_per_cluster", 4)

            all_units_ret = []
            all_units_similarities = []
            for u in range(self.num_units):
                if not self.cluster_members[u]:
                    all_units_ret.append([])
                    all_units_similarities.append(torch.tensor([], device=query_vectors.device))
                    continue
                
                cluster_similarities = self.cluster_representatives[u].get_true_cosine_similarity(query_vectors[u], eps=self.eps)
                sorted_indices_tensor = torch.argsort(cluster_similarities, descending=True)
                sorted_cluster_indices = sorted_indices_tensor.tolist()

                all_units_similarities.append(cluster_similarities)
                retrieved_frame_indices = []
                selected_set = set()

                if use_cluster_sampling:
                    for cluster_idx in sorted_cluster_indices:
                        if len(retrieved_frame_indices) >= topk: break
                        members = self.cluster_members[u][cluster_idx]
                        target_count = min(len(members), frames_per_cluster)
                        if target_count > 0:
                            remaining_slots = topk - len(retrieved_frame_indices)
                            actual_count = min(target_count, remaining_slots)
                            best_frames = self._get_best_candidates_from_members(u, members, query_vectors[u], actual_count)
                            for frame_idx in best_frames:
                                if frame_idx not in selected_set:
                                    retrieved_frame_indices.append(frame_idx)
                                    selected_set.add(frame_idx)

                    if len(retrieved_frame_indices) < topk:
                        for cluster_idx in sorted_cluster_indices:
                            if len(retrieved_frame_indices) >= topk: break
                            members = self.cluster_members[u][cluster_idx]
                            candidates = [m for m in members if m not in selected_set]
                            if not candidates: continue
                            remaining_slots = topk - len(retrieved_frame_indices)
                            best_remainder_frames = self._get_best_candidates_from_members(u, candidates, query_vectors[u], remaining_slots)
                            for frame_idx in best_remainder_frames:
                                retrieved_frame_indices.append(frame_idx)
                                selected_set.add(frame_idx)
                            if len(retrieved_frame_indices) >= topk: break
                else:
                    for cluster_idx in sorted_cluster_indices:
                        if len(retrieved_frame_indices) >= topk: break
                        members = self.cluster_members[u][cluster_idx]
                        candidates = [m for m in members if m not in selected_set]
                        if not candidates: continue
                        remaining_slots = topk - len(retrieved_frame_indices)
                        
                        if len(candidates) <= remaining_slots:
                            for frame_idx in candidates:
                                retrieved_frame_indices.append(frame_idx)
                                selected_set.add(frame_idx)
                        else:
                            best_remainder_frames = self._get_best_candidates_from_members(u, candidates, query_vectors[u], remaining_slots)
                            for frame_idx in best_remainder_frames:
                                retrieved_frame_indices.append(frame_idx)
                                selected_set.add(frame_idx)
                            break

                retrieved_frame_indices.sort()
                all_units_ret.append(retrieved_frame_indices)

            return all_units_ret, all_units_similarities[0] if all_units_similarities else torch.tensor([])
        
        else: # chunking
            # ... (Chunking Logic) ...
            chunk_size = kwargs.get("chunk_size")
            num_global_block = kwargs.get("num_global_block")
            init_exc = kwargs.get("init_exc")
            global_remainder = kwargs.get("global_remainder")
            from_group_kv_func = kwargs.get("from_group_kv_func")
            block_size = kwargs.get("block_size")
            n_init = kwargs.get("n_init")
            ret = [[] for _ in range(self.num_units)]
            
            logits = None
            if num_global_block <= topk:
                if not init_exc:
                    if global_remainder[0].size(-2) <= n_init:
                        return [[] for _ in range(self.num_units)], torch.tensor([])
                    global_k = global_remainder[0][:, :, n_init:, :]
                    global_k = from_group_kv_func(global_k)
                    if global_k.size(-2) == 0 or not block_size or global_k.size(-2) % block_size != 0:
                         return [[] for _ in range(self.num_units)], torch.tensor([])
                    block_num = global_k.size(-2) // block_size
                    if block_num <= topk:
                        ret = [list(range(block_num)) for _ in range(self.num_units)]
                    else:
                        global_k = global_k.transpose(1, 2)
                        global_k = global_k.reshape(self.num_units, block_num, block_size, -1)
                        global_k = global_k.mean(dim=-2, keepdim=False)
                        logits = torch.matmul(global_k.float(), query_vectors[:, :, None].float()).squeeze(dim=-1)
                else:
                    ret = [list(range(num_global_block)) for _ in range(self.num_units)]
            else:
                logits = torch.stack([self.block_k[u].get_true_cosine_similarity(query_vectors[u]) for u in range(self.num_units)])

            if logits is not None:
                if self.num_units == 0 or logits.numel() == 0:
                     return [[] for _ in range(self.num_units)], logits
                assert topk % chunk_size == 0
                remainder_size = logits.shape[1] % chunk_size
                chunked_logits = logits[:, :logits.shape[1]-remainder_size].reshape(self.num_units, -1, chunk_size).mean(dim=-1)
                if remainder_size > 0:
                    remainder_logits = logits[:, -remainder_size:].mean(dim=-1, keepdim=True)
                    chunked_logits = torch.cat([chunked_logits, remainder_logits], dim=1)
                
                k_for_topk = min(topk // chunk_size, chunked_logits.shape[1])
                if k_for_topk <= 0: return [[] for _ in range(self.num_units)], logits

                ret = chunked_logits.topk(k_for_topk, dim=1).indices
                ret = ret.sort(dim=1)[0][:, :, None]
                ret = ret * chunk_size + torch.arange(chunk_size, device=ret.device)[None, None, :]
                ret = ret.reshape(self.num_units, -1).cpu().tolist()
                for u in range(self.num_units):
                    ret[u] = list(filter(lambda idx: idx < logits.shape[1], ret[u]))

            if DEBUG_RETRIEVAL_COMPARE and self.num_units > 0:
                u = 0  # Only log batch 0 to avoid log spam
                chunking_ids = ret[u]
                chunking_ids.sort()
                
                logger.info(f"\n[Retrieval Chunking Layer{self.layer_idx}] Mode: chunking (chunk_size={kwargs.get('chunk_size')})")
                
                scores_display = []
                if logits is not None and len(chunking_ids) > 0:
                    try:
                        valid_ids = [i for i in chunking_ids if i < logits.shape[1]]
                        if valid_ids:
                            idx_tensor = torch.tensor(valid_ids, device=logits.device, dtype=torch.long)
                            val_scores = logits[u][idx_tensor]
                            scores_display = val_scores.tolist()
                    except Exception as e:
                        scores_display = [f"Error: {e}"]

                logger.info(f"  > Selected IDs ({len(chunking_ids)}): {chunking_ids}")
                logger.info(f"  > Scores: {scores_display}")
                logger.info(f"  > Sorted Scores Desc: {sorted(scores_display, reverse=True)}")
                
                if logits is not None:
                    k_inspect = min(5, logits.shape[1])
                    top_vals, top_inds = torch.topk(logits[u], k=k_inspect)
                    top_inds_list = top_inds.tolist()
                    top_inds_list.sort()
                    logger.info(f"  > Raw Logits Top-{k_inspect} Indices: {top_inds_list}")
            
            return ret, logits if logits is not None else torch.tensor([])
    def _log_full_dump(self, stage, unit, payload, final_frames=None, query_vec=None):
        """Dump full cluster state for all ICs (no truncation).
        Output file: cluster_full_dump.txt
        """
        # Frequency control: only log every 5 layers and unit 0
        if self.layer_idx % 5 != 0 or unit != 0:
            return

        import time
        import os
        
        filename = "cluster_full_dump.txt"
        lines = []
        sep = "=" * 100
        
        lines.append(f"\n{sep}")
        lines.append(f"[{stage}] Layer {self.layer_idx} | Unit {unit} | Time: {time.time():.2f}")
        lines.append(sep)

        # 1. Print basic payload fields
        for k, v in payload.items():
            lines.append(f"[*] {k}: {v}")
        
        # 2. [RETRIEVE stage] Print the full IC status table
        if stage == "RETRIEVE" and final_frames is not None and query_vec is not None:
            lines.append(f"\n[Full IC Status Table]")
            # Columns:
            # Tag: E0-I1 (EC index - IC index)
            # Size: total frames in the IC
            # Hits: frames selected by this retrieval
            # C_Sim: IC centroid similarity with the query
            # Hit_Rate: Hits / Size
            header = f"{'Tag':<10} | {'Size':<5} | {'Hits':<5} | {'C_Sim':<10} | {'Hit_Rate':<8} | {'Member_IDs (Partial)'}"
            lines.append("-" * len(header))
            lines.append(header)
            lines.append("-" * len(header))

            # Precompute the hit set
            final_set = set(final_frames.tolist() if isinstance(final_frames, torch.Tensor) else final_frames)
            
            # Iterate over all ECs and ICs
            total_hits_check = 0
            
            if unit < len(self.external_clusters):
                # Get query device to avoid device mismatch errors
                dev = query_vec.device
                
                for ec_i, ec in enumerate(self.external_clusters[unit]):
                    for ic_i, ic in enumerate(ec.sub_clusters):
                        tag = f"E{ec_i}-I{ic_i}"
                        
                        # 1. Compute hits
                        hits = 0
                        for m in ic.member_indices:
                            if m in final_set:
                                hits += 1
                        total_hits_check += hits
                        
                        # 2. Compute Centroid Sim (on the fly)
                        # Assumes ic.centroid and query_vec are both normalized
                        c_vec = ic.centroid.to(dev).float()
                        # Simple dot product = cosine similarity for normalized vectors
                        sim = torch.dot(query_vec.view(-1), c_vec.view(-1)).item()
                        
                        # 3. Format and append row
                        hit_rate = (hits / ic.size) * 100
                        members_str = str(ic.member_indices[:5]) + "..." if ic.size > 5 else str(ic.member_indices)
                        
                        # Highlight rows with hits using a leading asterisk
                        prefix = "* " if hits > 0 else "  "
                        
                        row = f"{prefix}{tag:<8} | {ic.size:<5} | {hits:<5} | {sim:.6f}   | {hit_rate:.1f}%   | {members_str}"
                        lines.append(row)

            lines.append("-" * len(header))
            lines.append(f"Check Total Hits: {total_hits_check} / {len(final_frames)}")
            
            # Detect orphan frames (still in buffer, not yet clustered)
            orphans = [f for f in final_frames if f not in set().union(*[set(ic.member_indices) for ec in self.external_clusters[unit] for ic in ec.sub_clusters])]
            if orphans:
                lines.append(f"WARNING: {len(orphans)} orphan frame(s) not in any cluster: {orphans}")

        lines.append("\n")

        # Atomic write
        try:
            with open(filename, "a", encoding="utf-8") as f:
                f.write("\n".join(lines))
        except: pass


# =============================================================================
# Class: ContextManager
# Role: Per-layer KV-cache manager.
# Responsibilities:
#   1. Streaming encoding during the Encoding Phase (append)
#   2. KV-cache retrieval and loading during the QA Phase (get_retrieved_kv)
#   3. Pipeline prefetch scheduling (trigger_next_layer_prefetch)
# =============================================================================

GLOBAL_STREAM = None
CONTEXT_MANAGER_INSTANCE_COUNTER = 0

class ContextManager:
    _registry = {}

    def __init__(self, 
                 position_embedding,
                 n_init, n_local, 
                 block_size, max_cached_block, topk, chunk_size, exc_block_size, 
                 fattn: bool = False,
                 retrieval_strategy: str = 'chunking',
                 cluster_threshold: float = 0.85,
                 async_global_stream: bool = False,
                 pin_memory: bool = False,
                 stats_filename: str = "timing_stats.json",
                 retrieval_log_filename: str = "retrieval_log.json",
                 use_cluster_sampling: bool = False,
                 frames_per_cluster: int = 4,
                 variance_threshold: float = None,
                 external_threshold: float = 0.7,
                 external_variance_threshold: float = 0.1,
                 topk_external: int = 5,
                 max_frames_per_external: int = 16,
                 max_frames_per_internal: int = 8,
                 layer_idx: int = -1,
                 enable_pipeline: bool = True,
                 enable_cluster_storage: bool = False, 
                 external_internal_retrieve_method: str = 'hierarchical',
                 enable_gpu_clustering: bool = False,
                 enable_batch_clustering: bool = True,
                 encoding_strategy: str = 'default',
                 max_anchors: int = 64,
                 anchor_selection_method: str = 'closest_to_centroid',
                 anchors_per_cluster: int = 1,
                 prefetch_factor: float = 5.0,
                 prefetch_reserve_ratio: float = 0.2,
                 enable_fast_io: bool = True,
                 enable_cluster_lru: bool = True,
                 enable_lazy_split: bool = True,
    ):
        from clustervlm.attention.kv_cache_manager import CONTEXT_MANAGER_INSTANCE_COUNTER
        
        global CONTEXT_MANAGER_INSTANCE_COUNTER
        self.layer_idx = layer_idx if layer_idx >= 0 else CONTEXT_MANAGER_INSTANCE_COUNTER
        if layer_idx < 0: CONTEXT_MANAGER_INSTANCE_COUNTER += 1

        if self.layer_idx == 0:
            RetrievalManager.reset_class_cache()
        
        ContextManager._registry[self.layer_idx] = self
        self.enable_pipeline = enable_pipeline
        self.prefetch_factor = prefetch_factor
        self.prefetch_reserve_ratio = prefetch_reserve_ratio
        self.enable_fast_io = enable_fast_io
        self.enable_cluster_lru = enable_cluster_lru
        self.qa_cache_hits = 0
        self.qa_cache_requests = 0
        self.prefetch_hit_blocks = 0
        self.prefetch_required_blocks = 0
        self.prefetch_predicted_blocks = 0

        self.prefetch_stream = torch.cuda.Stream()
        self.prefetched_kv = None
        self.is_prefetching = False
        # CUDA event on `prefetch_stream`; next layer waits on it before consuming.
        self.prefetch_event = None
        # Indices the previous layer asked us to pre-load (for hit-rate diagnostic).
        self.prefetch_indices = None
        # Strictly-negative LRU timestamps for speculatively prefetched blocks
        # so they are evicted before any genuinely-loaded block.
        self._prefetch_lru_counter = 0
        
        self.enable_cluster_storage = enable_cluster_storage

        self.enable_gpu_clustering = enable_gpu_clustering
        self.enable_lazy_split = enable_lazy_split
        self.enable_batch_clustering = enable_batch_clustering
        if self.layer_idx == 0:
            logger.info(f"[ContextManager] Batch-K Clustering: {self.enable_batch_clustering}")

        self.retrieve_method = external_internal_retrieve_method
        if self.layer_idx == 0:
            logger.info(f"[ContextManager] Retrieval Method: {self.retrieve_method}")
        
        self.encoding_strategy = encoding_strategy
        self.anchor_params = {
            'method': anchor_selection_method,
            'per_cluster': anchors_per_cluster,
            'max_total': max_anchors
        }

        
        if DEBUG_ATTENTION and self.layer_idx == 0:
            logger.info(f"[ContextManager] Encoding Strategy: {self.encoding_strategy}")
            logger.info(f"                 Anchor Params: {self.anchor_params}")

        self.length = 0
        self.position_embedding = position_embedding

        self.n_init = n_init
        # Immediately sync to ensure the RoPE proxy has the correct system_prompt_len during encoding
        if hasattr(self.position_embedding, "system_prompt_len"):
            self.position_embedding.system_prompt_len = n_init

        self.n_local = n_local
        self.block_size = block_size
        self.max_cached_block = max_cached_block
        self.exc_block_size = exc_block_size
        assert exc_block_size <= n_local
        self.topk = topk
        self.chunk_size = chunk_size
        
        self.use_cluster_sampling = use_cluster_sampling
        self.frames_per_cluster = frames_per_cluster
        
        self.Attn, _ = get_multi_stage_dot_production_attention(fattn)
        self.fattn = fattn
        self.initialized = False
        self.load_count = 0
        self.async_global_stream = async_global_stream
        self.pin_memory = pin_memory
        
        self.retrieval_strategy = retrieval_strategy
        self.cluster_threshold = cluster_threshold
        self.variance_threshold = variance_threshold
        
        self.external_threshold = external_threshold
        self.external_variance_threshold = external_variance_threshold
        self.topk_external = topk_external
        self.max_frames_per_external = max_frames_per_external
        self.max_frames_per_internal = max_frames_per_internal

        self.stats_manager = TimingStats.get_instance()
        self.logger = RetrievalLogger.get_instance()

        self.temp_external_embeddings = None 
        
        global GLOBAL_STREAM
        if self.async_global_stream and GLOBAL_STREAM is None:
            GLOBAL_STREAM = torch.cuda.Stream()

        self.reset_retrieval()

        # Defer batch_size-dependent initialization to init() (called on first append)
        self.global_blocks = [] 
        self.cached_blocks = []
        self.retrieval_manager = None 
    
    def update_external_embeddings(self, emb):
        self.temp_external_embeddings = emb
    
    def _remove_lru_blocks(self, u, num_remove: Optional[int] = None, ignore_blocks = None):
        if num_remove is None:
            num_remove = len(self.cached_blocks[u]) - self.max_cached_block

        if num_remove <= 0:
            return

        lst = list(self.cached_blocks[u].items())
        lst.sort(key=lambda x: x[1])

        removed = 0
        for i in range(len(lst)):
            idx = lst[i][0]
            if ignore_blocks is None or (idx not in ignore_blocks):
                if self.global_blocks[u][idx].gpu_data is not None:
                    self.global_blocks[u][idx].offload()
                
                if idx in self.cached_blocks[u]:
                    self.cached_blocks[u].pop(idx)
                removed += 1

            if removed >= num_remove:
                return

    def _from_group_kv(self, tensor):
        assert tensor.dim() == 4 
        assert tensor.size(1) == self.num_heads_kv
        if self.num_heads == self.num_heads_kv:
            return tensor
        _, _, length, dim_head = tensor.shape
        num_group = self.num_heads // self.num_heads_kv
        tensor = tensor.view((self.num_units, self.unit_size_kv, 1, length, dim_head))
        tensor = tensor.expand((self.num_units, self.unit_size_kv, num_group, length, dim_head)).reshape((self.num_units, self.num_heads, length, dim_head))
        return tensor
    
    def init(self, local_q, local_k, local_v, global_q, global_k, global_v):
        """
        Lazy initialization, called on the first append.
        Determines batch_size (num_units) and allocates all dependent structures.
        """
        assert local_q.dim() == 4
        batch_size, num_heads, len_q, dim_head = local_q.shape
        num_heads_kv = local_k.size(1)

        self.batch_size = batch_size
        self.num_heads = num_heads
        self.num_heads_kv = num_heads_kv
        self.dim_head = dim_head
        self.num_units = batch_size
        self.unit_size = num_heads
        self.unit_size_kv = num_heads_kv

        self.global_blocks = [[] for _ in range(self.num_units)]
        self.cached_blocks = [{} for _ in range(self.num_units)]
        self.num_global_block = 0

        # Initialize RetrievalManager
        self.retrieval_manager = RetrievalManager(
            strategy=self.retrieval_strategy,
            threshold=self.cluster_threshold,
            num_units=self.num_units,
            rep_dim=dim_head * num_heads,
            dtype=global_k.dtype,
            device=global_k.device,
            variance_threshold=self.variance_threshold,
            external_threshold=self.external_threshold,
            external_variance_threshold=self.external_variance_threshold,
            topk_external=self.topk_external,
            max_frames_per_external=self.max_frames_per_external,
            max_frames_per_internal=self.max_frames_per_internal,
            layer_idx=self.layer_idx,
            retrieve_method=self.retrieve_method,
            enable_gpu_clustering=self.enable_gpu_clustering,
            enable_lazy_split=self.enable_lazy_split,
            # Pass remaining parameters
            encoding_strategy=self.encoding_strategy,
            anchor_params=self.anchor_params,
            kv_shape_params=None 
        )

        self.local_k = torch.empty((self.num_units, self.unit_size_kv, 0, dim_head), dtype=local_k.dtype, device=local_k.device)
        self.local_v = torch.empty((self.num_units, self.unit_size_kv, 0, dim_head), dtype=local_v.dtype, device=local_v.device)

        self.global_remainder = (
            torch.empty((self.num_units, self.unit_size_kv, 0, dim_head), dtype=global_k.dtype, device=global_k.device),
            torch.empty((self.num_units, self.unit_size_kv, 0, dim_head), dtype=global_v.dtype, device=global_v.device),
        )

        self.init_k = torch.empty((self.num_units, self.unit_size_kv, 0, dim_head), dtype=global_k.dtype, device=global_k.device)
        self.init_v = torch.empty((self.num_units, self.unit_size_kv, 0, dim_head), dtype=global_k.dtype, device=global_k.device)
        self.init_exc = False
        self.dtype = local_q.dtype
        self.position_embedding._update_cos_sin_tables_len(
            self.n_local + self.exc_block_size + 1, local_k.device, local_k.dim()
        )

        # Allocate global buffer: topk blocks + system prompt
        buffer_len = self.topk * self.block_size + self.n_init

        self.global_buffer = torch.zeros(
                (2, self.num_units, self.unit_size_kv, buffer_len , dim_head),
                dtype = global_k.dtype, device=global_k.device
            )
        self.global_buffer_init_st = 0
        self.global_buffer_init_ed = 0
        self.cuda_cache = CudaCache(
            self.max_cached_block * self.num_units,
            self.unit_size_kv * self.block_size * dim_head * 2,
            local_k.dtype
        )

        self.initialized = True
    
    def set_retrieval(self):
        self.to_retrieve = True

    def reset_retrieval(self):
        self.similarity = None
        self.retrieved_block_indices = None
        self.to_retrieve = False
        self.prefetched_kv = None
        self.is_prefetching = False
        self.prefetch_event = None
        self.prefetch_indices = None

    def set_retrieved_block_indices(self, retrieved_block_indices):
        if isinstance(retrieved_block_indices, torch.Tensor):
            retrieved_block_indices = retrieved_block_indices.cpu().tolist()
        self.retrieved_block_indices = retrieved_block_indices

    @classmethod
    def trigger_next_layer_prefetch(cls, current_layer_idx, retrieved_indices):
        next_layer_idx = current_layer_idx + 1
        if next_layer_idx in cls._registry:
            next_instance = cls._registry[next_layer_idx]
            if not next_instance.enable_pipeline:
                return
            # Pass retrieved indices directly to the next layer's prefetch
            next_instance.submit_prefetch_task(retrieved_indices)

    def submit_prefetch_task(self, retrieved_indices):
        """Launch async H2D copies on `self.prefetch_stream` for the next layer.
        Speculative blocks register negative LRU timestamps (see __init__)."""
        if not self.init_exc or not getattr(self, 'enable_fast_io', True):
            return
        if retrieved_indices is None:
            return
        # A still-unconsumed prefetch is left intact; its `prefetch_event` is reused.
        if self.is_prefetching:
            return

        with torch.cuda.stream(self.prefetch_stream):
            for u in range(self.num_units):
                cands = retrieved_indices[u]
                cands_list = cands.tolist() if isinstance(cands, torch.Tensor) else cands
                if not cands_list:
                    continue
                for b_idx in cands_list:
                    if b_idx < 0 or b_idx >= len(self.global_blocks[u]):
                        continue
                    unit = self.global_blocks[u][b_idx]
                    if unit.gpu_data is not None:
                        # Already resident: only register if absent, never promote above genuine loads.
                        self._prefetch_lru_counter -= 1
                        self.cached_blocks[u].setdefault(b_idx, self._prefetch_lru_counter)
                        continue
                    if len(unit.cache.idle_set) == 0:
                        break  # pool full; let the consume-time LRU handle the rest
                    try:
                        g_data, g_id = unit.cache.alloc()
                    except KeyError:
                        continue
                    g_data = g_data.view((2,) + unit.cpu_data[0].shape)
                    g_data[0].copy_(unit.cpu_data[0], non_blocking=True)
                    g_data[1].copy_(unit.cpu_data[1], non_blocking=True)
                    unit.gpu_data = g_data
                    unit.gpu_data_id = g_id
                    unit.event = None
                    self._prefetch_lru_counter -= 1
                    self.cached_blocks[u][b_idx] = self._prefetch_lru_counter

        ev = torch.cuda.Event()
        ev.record(self.prefetch_stream)
        self.prefetch_event = ev
        self.prefetch_indices = retrieved_indices
        self.is_prefetching = True

    def _load_kv_to_buffer(self):
        with Profiler.get_instance().timer("Ret: Load Total", "func"):
            global_h_k = self.global_buffer[0]
            global_h_v = self.global_buffer[1]

            if self.init_exc:
                # Fast path collapses ~num_units * topk per-block H2D/D2D copies
                # into a single index_select + index_copy_, gated on enable_fast_io
                # and wrapped in try/except for transparent fallback.
                enable_fast_io_flag = getattr(self, 'enable_fast_io', True)
                init_ed = self.init_k.size(-2)
                self.load_count += 1
                load_count = self.load_count

                if enable_fast_io_flag:
                    self._batched_load_fast_io(global_h_k, global_h_v, init_ed, load_count)
                else:
                    self._slow_load_fallback(global_h_k, global_h_v, init_ed, load_count)

                if DEBUG_CACHE and self.layer_idx % 10 == 0 and self.load_count > 0:
                    hit_rate = (self.qa_cache_hits / self.qa_cache_requests) * 100 if self.qa_cache_requests > 0 else 0
                    logger.info(f"[Cache Stats Layer {self.layer_idx}] QA requests: {self.qa_cache_requests}, hits: {self.qa_cache_hits}, hit rate: {hit_rate:.2f}%")
            else:
                # === Short-video / full-GPU-resident path (unchanged) ===
                init_st = 0
                init_ed = self.n_init
                global_h_k[:, :, init_st:init_ed].copy_(self.global_remainder[0][:, :, :self.n_init], non_blocking=True)
                global_h_v[:, :, init_st:init_ed].copy_(self.global_remainder[1][:, :, :self.n_init], non_blocking=True)

                for u in range(self.num_units):
                    indices_u = self.retrieved_block_indices[u]
                    indices_list = indices_u.tolist() if isinstance(indices_u, torch.Tensor) else indices_u
                    if not indices_list: continue

                    with Profiler.get_instance().timer("Ret: IO Loop", "loop_2"):
                        for cnt, b_idx in enumerate(indices_list):
                            remainder_st = self.n_init + b_idx * self.block_size
                            remainder_ed = remainder_st + self.block_size

                            if remainder_st >= self.global_remainder[0].size(2): break

                            st = init_ed + cnt * self.block_size
                            ed = st + self.block_size

                            # Pure D2D copy: zero extra allocation, enters queue immediately
                            global_h_k[u, :, st:ed].copy_(self.global_remainder[0][u, :, remainder_st:remainder_ed], non_blocking=True)
                            global_h_v[u, :, st:ed].copy_(self.global_remainder[1][u, :, remainder_st:remainder_ed], non_blocking=True)

            # Compute final boundary
            indices_0 = self.retrieved_block_indices[0]
            if isinstance(indices_0, torch.Tensor): num_retrieved = indices_0.size(0)
            elif isinstance(indices_0, list): num_retrieved = len(indices_0)
            else: num_retrieved = 0

            if self.init_exc:
                total_len = self.init_k.size(-2) + num_retrieved * self.block_size
            else:
                total_len = self.n_init + num_retrieved * self.block_size

        return (global_h_k[:, :, :total_len, :], global_h_v[:, :, :total_len, :])

    # ----- Batched-IO loader helpers --------------------------------------------

    def _batched_load_fast_io(self, global_h_k, global_h_v, init_ed: int, load_count: int):
        """Cache-aware loader for `enable_fast_io=True`.
        Hits and freshly-loaded misses are gathered via a single index_select
        from the CudaCache pool and written to the buffer with one index_copy_;
        pool-full misses go straight to the buffer."""
        try:
            B = self.block_size
            heads_kv = self.unit_size_kv
            dim_head = self.dim_head
            cache_data = self.cuda_cache.data
            device = cache_data.device

            # Reinterpret the flat pool as block-shaped rows for index_select.
            cache_view = cache_data.view(-1, 2, heads_kv, B, dim_head)
            arange_B = torch.arange(B, device=device, dtype=torch.long)

            for u in range(self.num_units):
                indices_u = self.retrieved_block_indices[u]
                indices_list = indices_u.tolist() if isinstance(indices_u, torch.Tensor) else indices_u
                if not indices_list:
                    continue

                # Compute eviction budget *before* updating bookkeeping; prefetch
                # sentinels in cached_blocks already count as 'present'.
                cached_u = self.cached_blocks[u]
                needed_slots = sum(1 for b in indices_list if b not in cached_u)
                current_cached = len(cached_u)
                num_remove = (current_cached + needed_slots) - self.max_cached_block
                if num_remove > 0:
                    self._remove_lru_blocks(u, num_remove, ignore_blocks=set(indices_list))
                    cached_u = self.cached_blocks[u]

                # Classify each block: hit / freshly-loaded / direct-buffer.
                hit_ids = []
                hit_cnts = []

                for cnt, b_idx in enumerate(indices_list):
                    unit = self.global_blocks[u][b_idx]
                    self.qa_cache_requests += 1
                    if unit.gpu_data is not None:
                        self.qa_cache_hits += 1
                        hit_ids.append(unit.gpu_data_id)
                        hit_cnts.append(cnt)
                    else:
                        cache_pool = unit.cache
                        if len(cache_pool.idle_set) > 0:
                            try:
                                g_data, g_id = cache_pool.alloc()
                            except KeyError:
                                g_data, g_id = None, None
                            if g_data is not None:
                                g_data_view = g_data.view((2,) + unit.cpu_data[0].shape)
                                g_data_view[0].copy_(unit.cpu_data[0], non_blocking=True)
                                g_data_view[1].copy_(unit.cpu_data[1], non_blocking=True)
                                unit.gpu_data = g_data_view
                                unit.gpu_data_id = g_id
                                unit.event = None
                                hit_ids.append(g_id)
                                hit_cnts.append(cnt)
                            else:
                                self._direct_h2d_to_buffer(global_h_k, global_h_v, u, cnt, init_ed, unit, B)
                        else:
                            self._direct_h2d_to_buffer(global_h_k, global_h_v, u, cnt, init_ed, unit, B)

                # Same load_count for every accessed block this round (matches legacy semantics).
                cached_u.update({b: load_count for b in indices_list})

                n_hit = len(hit_ids)
                if n_hit == 0:
                    continue
                topk_u = len(indices_list)

                ids_t  = torch.as_tensor(hit_ids,  device=device, dtype=torch.long)
                cnts_t = torch.as_tensor(hit_cnts, device=device, dtype=torch.long)

                gathered = cache_view.index_select(0, ids_t)
                src = gathered.permute(1, 2, 0, 3, 4).reshape(2, heads_kv, n_hit * B, dim_head)

                slot_flat = self.global_buffer[:, u, :, init_ed: init_ed + topk_u * B, :]
                token_indices = (cnts_t.unsqueeze(1) * B + arange_B.unsqueeze(0)).reshape(-1)
                slot_flat.index_copy_(2, token_indices, src)

        except Exception as e:  # pragma: no cover - safety net
            logger.warning(
                f"[FastIO] Batched load fell back to legacy path on layer "
                f"{self.layer_idx}: {type(e).__name__}: {e}"
            )
            self._slow_load_fallback(global_h_k, global_h_v, init_ed, load_count)

    def _direct_h2d_to_buffer(self, global_h_k, global_h_v, u, cnt, init_ed, unit, B):
        """H2D a single block straight into the buffer (cache pool was full)."""
        st = init_ed + cnt * B
        ed = st + B
        global_h_k[u, :, st:ed].copy_(unit.cpu_data[0], non_blocking=True)
        global_h_v[u, :, st:ed].copy_(unit.cpu_data[1], non_blocking=True)

    def _slow_load_fallback(self, global_h_k, global_h_v, init_ed: int, load_count: int):
        """Legacy triple-pass loader; used when enable_fast_io=False or as fallback."""
        # Pass 1: LRU eviction
        for u in range(self.num_units):
            indices_tensor = self.retrieved_block_indices[u]
            indices_list = indices_tensor.tolist() if isinstance(indices_tensor, torch.Tensor) else indices_tensor

            current_cached = len(self.cached_blocks[u])
            needed_slots = 0
            for b_idx in indices_list:
                if b_idx not in self.cached_blocks[u]:
                    needed_slots += 1

            num_remove = (current_cached + needed_slots) - self.max_cached_block
            if num_remove > 0:
                self._remove_lru_blocks(u, num_remove, ignore_blocks=set(indices_list))

        # Pass 2: bookkeeping
        for u in range(self.num_units):
            indices_u = self.retrieved_block_indices[u]
            indices_list = indices_u.tolist() if isinstance(indices_u, torch.Tensor) else indices_u
            if not indices_list: continue
            for b_idx in indices_list:
                self.cached_blocks[u][b_idx] = load_count

        # Pass 3: actual IO via the legacy single-block API
        for u in range(self.num_units):
            indices_u = self.retrieved_block_indices[u]
            indices_list = indices_u.tolist() if isinstance(indices_u, torch.Tensor) else indices_u
            if not indices_list: continue

            with Profiler.get_instance().timer("Ret: IO Loop", "loop"):
                for cnt, b_idx in enumerate(indices_list):
                    st = init_ed + cnt * self.block_size
                    ed = st + self.block_size
                    unit = self.global_blocks[u][b_idx]

                    self.qa_cache_requests += 1
                    if unit.gpu_data is not None:
                        self.qa_cache_hits += 1

                    # Slow path: defer fully to MemoryUnit.load (which in turn handles
                    # both hit and miss with its own copies + event recording).
                    unit.load((global_h_k[u, :, st:ed, :], global_h_v[u, :, st:ed, :]))

    def _refine_topk_on_gpu(self, query, candidates_M):
        """
        GPU-side exact re-ranking.
        Uses clamp + masked_fill to avoid CPU-GPU implicit sync deadlocks
        caused by dynamic tensor indexing.
        """
        global_h_q = query.mean(dim=2, keepdim=False)
        global_h_q = global_h_q.reshape(self.num_units, -1)

        refined_ret =[]
        for u in range(self.num_units):
            cands = candidates_M[u]
            
            # Normalize input to Tensor (handles both Tensor and List inputs)
            if isinstance(cands, torch.Tensor):
                cand_tensor = cands
                cand_size = cand_tensor.shape[0]
            else:
                cand_tensor = torch.tensor(cands, device=self.retrieval_manager.device, dtype=torch.long)
                cand_size = len(cands)

            if cand_size <= self.topk:
                # No re-ranking needed; return candidates as-is
                refined_ret.append(cand_tensor.cpu().tolist())
                continue

            q_float = global_h_q[u].unsqueeze(0).float()
            
            # === Lock-free out-of-bounds protection ===
            invalid_mask = None

            if not self.init_exc:
                # Short-video / pure-buffer path.
                # Extract raw KV and expand Grouped Heads to avoid GQA dimension mismatch.
                rem_k_raw = self.global_remainder[0][:, :, self.n_init:, :]
                rem_k_expanded = self._from_group_kv(rem_k_raw)  # [B, H_q, L, D]
                
                B_sz = self.block_size
                H = rem_k_expanded.size(1)  # Use the expanded head count
                D = rem_k_expanded.size(3)
                vid_k = rem_k_expanded[u].view(H, -1, B_sz, D)
                max_valid_idx = vid_k.size(1) - 1
                if max_valid_idx < 0:
                    refined_ret.append([])
                    continue
                
                # Fast bounds clamp: replace bool indexing to avoid shape changes and sync costs
                invalid_mask = (cand_tensor > max_valid_idx) | (cand_tensor < 0)
                safe_cands = torch.clamp(cand_tensor, 0, max_valid_idx)
                
                sel_k = vid_k[:, safe_cands, :, :].mean(dim=2)
                raw_vecs = sel_k.permute(1, 0, 2).reshape(cand_size, -1).float()
                v_norm = None
            else:
                # Long-video / persisted-blocks path
                gpu_data = self.retrieval_manager._gpu_hierarchy[u] if hasattr(self.retrieval_manager, '_gpu_hierarchy') else None
                global_cand_norm = gpu_data.get('global_cand_norm') if gpu_data else None

                if global_cand_norm is not None:
                    max_valid_idx = global_cand_norm.size(0) - 1
                    if max_valid_idx < 0:
                        refined_ret.append([])
                        continue
                        
                    invalid_mask = (cand_tensor > max_valid_idx) | (cand_tensor < 0)
                    safe_cands = torch.clamp(cand_tensor, 0, max_valid_idx)
                    
                    v_norm = global_cand_norm[safe_cands]
                    raw_vecs = None
                else:
                    # Fallback: read from raw frame representations
                    max_valid_idx = self.retrieval_manager.all_frame_reps[u].length - 1
                    if max_valid_idx < 0:
                        refined_ret.append([])
                        continue
                        
                    invalid_mask = (cand_tensor > max_valid_idx) | (cand_tensor < 0)
                    safe_cands = torch.clamp(cand_tensor, 0, max_valid_idx)
                    
                    raw_vecs = self.retrieval_manager.all_frame_reps[u].data[safe_cands].float()
                    v_norm = None

            # Normalize feature vectors
            if v_norm is None and raw_vecs is not None:
                if raw_vecs.shape[-1] > 1024:
                    v_ln = torch.nn.functional.layer_norm(raw_vecs, raw_vecs.shape[1:])
                    v_norm = torch.nn.functional.normalize(v_ln, p=2, dim=-1, eps=self.retrieval_manager.eps)
                else:
                    v_norm = torch.nn.functional.normalize(raw_vecs, p=2, dim=-1, eps=self.retrieval_manager.eps)

            if q_float.shape[-1] > 1024:
                q_ln = torch.nn.functional.layer_norm(q_float, q_float.shape[1:])
                q_norm = torch.nn.functional.normalize(q_ln, p=2, dim=-1, eps=self.retrieval_manager.eps)
            else:
                q_norm = torch.nn.functional.normalize(q_float, p=2, dim=-1, eps=self.retrieval_manager.eps)

            # Compute similarity scores
            scores = torch.matmul(q_norm, v_norm.T).squeeze(0)
            
            # Kill scores for clamped (out-of-bounds) candidates by setting them to -inf
            if invalid_mask is not None:
                scores.masked_fill_(invalid_mask, -float('inf'))

            # Select the true Top-K
            k_needed = min(self.topk, scores.size(0))
            _, topk_idx = torch.topk(scores, k=k_needed)

            # Map back to real block IDs using the original candidate tensor
            final_cands = cand_tensor[topk_idx]
            final_cands, _ = torch.sort(final_cands)
            
            # Move to CPU and remove any residual invalid IDs (those with -inf scores)
            cands_list = final_cands.cpu().tolist()
            cands_list = [x for x in cands_list if 0 <= x <= max_valid_idx]
            
            refined_ret.append(cands_list)

        return refined_ret

    def get_retrieved_kv(self, query=None, external_query=None):
        predicted_indices_M = None
        true_indices_K =[]

        # 1. Main thread: compute similarity scores (global O(N) search)
        if query is not None:
            if external_query is None: 
                external_query = self.temp_external_embeddings
            
            # Compute the exact Top-K this layer needs directly (never over-fetch then slice)
            with Profiler.get_instance().timer("Ret: Index Search", "compute"):
                true_indices_K = self._calc_block_topk(query, external_query=external_query, override_topk=self.topk)
            
            self.set_retrieved_block_indices(true_indices_K)

        # 2. Synchronize this layer: consume the data the previous layer prefetched.
        #    `wait_event` is a pure GPU-side ordering primitive — no Python/GIL roundtrip.
        if self.enable_pipeline and self.is_prefetching and self.prefetch_event is not None:
            torch.cuda.current_stream().wait_event(self.prefetch_event)
            predicted_indices_M = self.prefetch_indices
            self.is_prefetching = False
            self.prefetch_event = None
            self.prefetch_indices = None

            # Log pipeline miss rate (compare prefetch prediction vs. actual Top-K)
            if predicted_indices_M is not None and DEBUG_SYSTEM and self.layer_idx % 5 == 0:
                u = 0
                pred_set = set(predicted_indices_M[u].tolist() if isinstance(predicted_indices_M[u], torch.Tensor) else predicted_indices_M[u])
                true_set = set(true_indices_K[u].tolist() if isinstance(true_indices_K[u], torch.Tensor) else true_indices_K[u])
                
                miss_count = len(true_set - pred_set)
                total_req = len(true_set)
                miss_rate = (miss_count / total_req) * 100 if total_req > 0 else 0
                
                logger.info(f"[Fast Pipeline Layer {self.layer_idx}] Prefetch: {len(pred_set)} blocks, required: {total_req}, miss: {miss_count} ({miss_rate:.1f}%)")

            if predicted_indices_M is not None and DEBUG_PREFETCH_RATIO:
                def _as_index_set(indices):
                    if indices is None:
                        return set()
                    if isinstance(indices, torch.Tensor):
                        indices = indices.tolist()
                    return set(indices)

                hit_count = 0
                total_req = 0
                total_pred = 0
                for u in range(self.num_units):
                    pred_set = _as_index_set(predicted_indices_M[u])
                    true_set = _as_index_set(true_indices_K[u])
                    hit_count += len(pred_set & true_set)
                    total_req += len(true_set)
                    total_pred += len(pred_set)

                self.prefetch_hit_blocks += hit_count
                self.prefetch_required_blocks += total_req
                self.prefetch_predicted_blocks += total_pred

                hit_rate = (hit_count / total_req) * 100 if total_req > 0 else 0
                precision = (hit_count / total_pred) * 100 if total_pred > 0 else 0
                cumulative_hit_rate = (
                    self.prefetch_hit_blocks / self.prefetch_required_blocks * 100
                    if self.prefetch_required_blocks > 0 else 0
                )

                logger.info(
                    f"[Prefetch Ratio Layer {self.layer_idx}] "
                    f"hit: {hit_count}/{total_req} ({hit_rate:.1f}%), "
                    f"prefetched: {total_pred}, precision: {precision:.1f}%, "
                    f"cumulative: {self.prefetch_hit_blocks}/"
                    f"{self.prefetch_required_blocks} ({cumulative_hit_rate:.1f}%)"
                )

        # 3. Physically load KV blocks for this layer.
        #    This issues H2D copies for any cache misses on `current_stream`.
        with Profiler.get_instance().timer("Ret: Load Total", "func"):
            kv_buffer = self._load_kv_to_buffer()

        # 4. Trigger next-layer prefetch AFTER our own load has been issued.
        #    This avoids the previous bug where the next-layer prefetch was
        #    queued *before* this layer's load and the two H2D streams competed
        #    for PCIe bandwidth. Now the prefetch overlaps with the upcoming
        #    FlashAttention compute on `current_stream`.
        if query is not None and self.enable_pipeline:
            ContextManager.trigger_next_layer_prefetch(self.layer_idx, true_indices_K)

        # Compute context window boundaries
        indices_0 = self.retrieved_block_indices[0]
        num_retrieved = len(indices_0) if isinstance(indices_0, list) else (indices_0.size(0) if torch.is_tensor(indices_0) else 0)
        
        sys_len = self.n_init
        video_len = num_retrieved * self.block_size
        total_len = sys_len + video_len

        if hasattr(self.position_embedding, "system_prompt_len"):
            self.position_embedding.system_prompt_len = sys_len
        if hasattr(self.position_embedding, "video_token_end_index"):
            self.position_embedding.video_token_end_index = total_len

        return kv_buffer

    def _calc_block_topk(self, global_h_q, external_query=None, override_topk=None):
        start_t = time.time()
        global_h_q = global_h_q.mean(dim=2, keepdim=False)
        assert global_h_q.shape == (self.num_units, self.unit_size, self.dim_head)
        global_h_q = global_h_q.reshape(self.num_units, self.dim_head * self.unit_size)
        
        chunking_kwargs = {
            "chunk_size": self.chunk_size,
            "num_global_block": self.num_global_block,
            "init_exc": self.init_exc,
            "global_remainder": self.global_remainder,
            "from_group_kv_func": self._from_group_kv,
            "block_size": self.block_size,
            "n_init": self.n_init,
            "use_cluster_sampling": self.use_cluster_sampling,
            "frames_per_cluster": self.frames_per_cluster,
            "external_query": external_query
        }
        
        # Use override_topk if provided, else fall back to the default topk
        target_k = override_topk if override_topk is not None else self.topk
        
        # Measure retrieval latency (External + Internal computation)
        with Profiler.get_instance().timer("Ret: Index Search", "compute"):
            ret, similarities = self.retrieval_manager.retrieve_topk(global_h_q, target_k, **chunking_kwargs)
        
        self.logger.buffer_layer_retrieval(self.layer_idx, similarities, ret[0])
        
        end_t = time.time()
        if DEBUG_SYSTEM and self.layer_idx == 0:
            logger.info(f"[DEBUG Layer 0] CPU Dispatch Cost: {(end_t - start_t)*1000:.2f} ms")

        return ret

    def get_global_hidden_and_mask(self, exc_length):
        global_h_k = self.global_buffer[0]
        global_h_v = self.global_buffer[1]
        global_remainder_ed = self._global_remainder_ed + exc_length
        global_remainder_st = self._global_remainder_st
        global_remainder_len = global_remainder_ed - global_remainder_st
        if not self.init_exc and global_remainder_len > self.n_local:
            global_k = self.global_remainder[0]
            global_v = self.global_remainder[1]
            append_init_len = min(
                self.n_init - self.init_k.size(-2),
                global_remainder_len - self.n_local
            )
            self.init_k = torch.cat(
                (self.init_k, global_k[:, :, global_remainder_st:global_remainder_st + append_init_len, :]), dim=-2
            )
            self.init_v = torch.cat(
                (self.init_v, global_v[:, :, global_remainder_st:global_remainder_st + append_init_len, :]), dim=-2
            )
            global_remainder_st += append_init_len
            global_remainder_len -= append_init_len
            if self.init_k.size(-2) == self.n_init:
                self.init_exc = True
        self._global_remainder_ed = global_remainder_ed
        self._global_remainder_st = global_remainder_st
        init_st = 0
        init_ed = self.init_k.size(-2)
        if self.global_buffer_init_st != init_st or self.global_buffer_init_ed != init_ed:
            global_h_k[:, :, init_st: init_ed, :].copy_(self.init_k, non_blocking=True)
            global_h_v[:, :, init_st: init_ed, :].copy_(self.init_v, non_blocking=True)
        self.global_buffer_init_st = init_st
        self.global_buffer_init_ed = init_ed
        global_h_k = global_h_k[:, :, :init_ed, :]
        global_h_v = global_h_v[:, :, :init_ed, :]
        return global_h_k, global_h_v

    # ========================================================================
    # [Internal Attention] Physical concatenation of Anchors + Local Window
    # ========================================================================
    def _append(self, local_q, local_k, local_v, global_q, extra_global_k=None, extra_global_v=None):
        """
        Args:
            extra_global_k/v: Global Anchors (raw KV tensors)
        """
        # 1. [Physical concatenation] Build combined local context: [Anchors] + [Local Window]
        if extra_global_k is not None and extra_global_v is not None:
            # Concatenate Key and Value
            # Shape: [Batch, Heads, (Anchor_Len + Local_Len), Dim]
            combined_local_k = torch.cat([extra_global_k, local_k], dim=-2)
            combined_local_v = torch.cat([extra_global_v, local_v], dim=-2)
            
            # Record anchor length for dynamic sliding window adjustment
            anchor_len = extra_global_k.size(-2)
        else:
            combined_local_k = local_k
            combined_local_v = local_v
            anchor_len = 0

        # Dynamically detect whether the system prompt is still present at the head of the buffer.
        # If remainder == n_init, the system prompt has not yet been trimmed out.
        current_len = combined_local_k.size(-2)
        remainder = current_len % 196
        has_sys = (remainder == self.n_init)
        
        # Propagate the system prompt boundary to the RoPE proxy
        if hasattr(self.position_embedding, "system_prompt_len"):
            self.position_embedding.system_prompt_len = self.n_init if has_sys else 0
            
        # Set video end to infinity so all video tokens are covered
        if hasattr(self.position_embedding, "video_token_end_index"):
            self.position_embedding.video_token_end_index = 1000000

        if DEBUG_QWEN and self.layer_idx == 0 and local_q.shape[2] == 196 and self.length == 15:
            print("\n" + "="*60)
            print("CLUSTERVLM AUTOMATIC ALIGNMENT VERIFICATION")
            print("="*60)
            print(f"[L0 Query BEFORE RoPE] Actual:   {local_q[0, 0, 0, :5].tolist()}")

        # =================[VERIFY: L1 Query BEFORE RoPE]=================
        if DEBUG_QWEN and self.layer_idx == 1 and local_q.shape[2] == 196 and self.length == 15:
            print("\n" + "="*60)
            print("CLUSTERVLM AUTOMATIC ALIGNMENT VERIFICATION")
            print("="*60)
            print(f"[L1 Query BEFORE RoPE] Actual:   {local_q[0, 0, 0, :5].tolist()}")
            print(f"                       Expected:[1.5156, 2.0312, 1.0078, -1.2421, 0.1718]")

        local_h_q, local_h_k = self.position_embedding(local_q, combined_local_k)
        
        # =================[VERIFY: L1 Query AFTER RoPE]=================
        if DEBUG_QWEN and self.layer_idx == 1 and local_q.shape[2] == 196 and self.length == 15:
            print(f"\n[L1 Query AFTER RoPE] Actual:    {local_h_q[0, 0, 0, :5].tolist()}")
            print(f"                      Expected:[-0.4843, 2.1093, -1.3750, 1.0859, 0.1621]")
            print("="*60)

        local_h_v = combined_local_v
        
        # 3. [Attention computation]
        attn = self.Attn(local_h_q.shape, local_h_q.dtype, local_h_q.device)
        
        # Dynamically expand the sliding window to cover Global Anchors.
        # Without this, FlashAttention would mask all positions beyond n_local,
        # silently discarding all Anchor tokens.
        effective_window_size = self.n_local + anchor_len
        attn.append(
            local_h_q, local_h_k, local_h_v, 
            get_score=False, 
            sliding_window=effective_window_size
        )
        
        current_total_len = combined_local_k.size(-2)
        with torch.cuda.stream(GLOBAL_STREAM):
            # Determine Global Q RoPE strategy based on RoPE type
            if getattr(self.position_embedding, "is_3d_rope", False):
                # Qwen2.5-VL 3D RoPE: reuse local_h_q which already carries perfect 3D coordinates
                global_h_q = local_h_q
                
                # Fetch system-prompt KV (positions 0~N_init)
                global_h_k, global_h_v = self.get_global_hidden_and_mask(exc_length=global_q.size(-2))
            
                # Apply 3D RoPE to system-prompt Keys using rotate_k_only
                if global_h_k.size(2) > 0:
                    sys_len = global_h_k.size(2)
                    sys_indices = torch.arange(sys_len, device=global_h_k.device, dtype=torch.long)
                    sys_ids = torch.stack([sys_indices, sys_indices, sys_indices], dim=0).unsqueeze(1).expand(3, global_h_k.shape[0], -1)
                    global_h_k = self.position_embedding.rotate_k_only(global_h_k, sys_ids)
            
            else:
                # [Original ClusterVLM logic] Preserved perfectly; LLaVA-OV accuracy will instantly recover!
                global_h_q = self.position_embedding.apply_rotary_pos_emb_one_angle(global_q, current_total_len)
                global_h_k, global_h_v = self.get_global_hidden_and_mask(exc_length=global_q.size(-2))



        if self.async_global_stream:
            torch.cuda.current_stream().wait_stream(GLOBAL_STREAM)
        
        # Global Attention Step
        attn.append(
            global_h_q, global_h_k, global_h_v, 
            end=True,
            get_score=False, 
            sliding_window=None,
            complement_sliding_window=True,
        )
        
        o, _ = attn.get_result()
        
        if self.async_global_stream:
            GLOBAL_STREAM.wait_stream(torch.cuda.current_stream())

        return o.view((self.batch_size, self.num_heads, -1, self.dim_head))

    
    def _append_global(self, external_embeddings=None):
        global_remainder_ed = self._global_remainder_ed
        global_remainder_st = self._global_remainder_st
        global_remainder_len = global_remainder_ed - global_remainder_st
        if self.init_exc:
            assert global_remainder_len % self.block_size == 0
            
            use_batch_clustering = getattr(self, "enable_batch_clustering", True)
            
            if use_batch_clustering and global_remainder_len > 0:
                # =====================================================================
                # [Batch-K Path] Vectorized batch clustering
                # =====================================================================
                num_blocks = global_remainder_len // self.block_size
                block_st = global_remainder_st
                block_ed = global_remainder_st + num_blocks * self.block_size
                
                # Physical storage (MemoryUnit allocation)
                with Profiler.get_instance().timer("Enc: MemoryUnit Alloc", "io"):
                    # Allocate one MemoryUnit per frame (preserves original semantics)
                    for b in range(num_blocks):
                        curr_st = block_st + b * self.block_size
                        curr_ed = curr_st + self.block_size
                        for u in range(self.num_units):
                            self.global_blocks[u].append((
                                MemoryUnit(
                                    (
                                        self.global_remainder[0][u, :, curr_st:curr_ed, :],
                                        self.global_remainder[1][u, :, curr_st:curr_ed, :]
                                    ),
                                    self.cuda_cache,
                                    False,
                                    self.pin_memory
                                )
                            ))
                
                start_event_overhead = torch.cuda.Event(enable_timing=True)
                end_event_overhead = torch.cuda.Event(enable_timing=True)
                start_event_overhead.record()
                
                # Batch extraction: gather all blocks into a single batch tensor
                current_k_batch = self.global_remainder[0][:, :, block_st:block_ed, :]
                current_v_batch = self.global_remainder[1][:, :, block_st:block_ed, :]
                
                # Build block_k_raw_batch: mean-pool to [Batch, Num_Blocks, Head*Dim]
                block_k_raw_full = self._from_group_kv(current_k_batch) #[U, H, num_blocks*block_size, D]
                U, H, L, D = block_k_raw_full.shape
                block_k_raw_reshaped = block_k_raw_full.view(U, H, num_blocks, self.block_size, D)
                block_k_raw_batch = block_k_raw_reshaped.mean(dim=3).permute(0, 2, 1, 3).reshape(U, num_blocks, H*D)
                
                curr_ext_emb_batch = None
                # Resolve External Embedding alignment out-of-bounds issue
                if getattr(self, "global_remainder_ext", None) is not None:
                    ext_slice = self.global_remainder_ext[:, block_st:block_ed, :]
                    curr_ext_emb_batch = ext_slice.view(U, num_blocks, self.block_size, -1).mean(dim=2)
                elif external_embeddings is not None:
                    curr_ext_emb = external_embeddings.mean(dim=1)
                    curr_ext_emb_batch = curr_ext_emb.unsqueeze(1).expand(U, num_blocks, curr_ext_emb.shape[-1])
                
                # Run batch clustering (Batch-K)
                with Profiler.get_instance().timer("Enc: Clustering Logic", "compute"):
                    if hasattr(self.retrieval_manager, 'add_blocks_batch'):
                        self.retrieval_manager.add_blocks_batch(
                            block_k_raw_batch, 
                            self.num_global_block, 
                            num_blocks,
                            external_emb_batch=curr_ext_emb_batch,
                            kv_pair_batch=(current_k_batch, current_v_batch)
                        )
                    else:
                        # Fallback to frame-by-frame (compatibility guard)
                        for i in range(num_blocks):
                            self.retrieval_manager.add_block(
                                block_k_raw_batch[:, i, :], 
                                self.num_global_block + i, 
                                external_emb=curr_ext_emb_batch[:, i, :] if curr_ext_emb_batch is not None else None,
                                kv_pair=(current_k_batch[:, :, i*self.block_size:(i+1)*self.block_size, :], 
                                         current_v_batch[:, :, i*self.block_size:(i+1)*self.block_size, :])
                            )
                
                end_event_overhead.record()
                torch.cuda.synchronize()
                
                self.num_global_block += num_blocks
                global_remainder_st += num_blocks * self.block_size
                global_remainder_len -= num_blocks * self.block_size

            else:
                # =====================================================================
                # [Frame-by-Frame Path] Sequential single-frame processing
                # =====================================================================
                while global_remainder_len > 0:
                    block_st = global_remainder_st
                    block_ed = global_remainder_st + self.block_size
                    global_remainder_len -= self.block_size
                    
                    # Physical storage (MemoryUnit allocation)
                    with Profiler.get_instance().timer("Enc: MemoryUnit Alloc", "io"):
                        # Allocate one MemoryUnit per frame
                        for u in range(self.num_units):
                            self.global_blocks[u].append((
                                MemoryUnit(
                                    (
                                        self.global_remainder[0][u, :, block_st:block_ed, :],
                                        self.global_remainder[1][u, :, block_st:block_ed, :]
                                    ),
                                    self.cuda_cache,
                                    False,
                                    self.pin_memory
                                )
                            ))
                    
                    # Trigger Retrieval Manager update
                    start_event_overhead = torch.cuda.Event(enable_timing=True)
                    end_event_overhead = torch.cuda.Event(enable_timing=True)
                    start_event_overhead.record()
                    
                    # Extract raw K vector for the current block
                    current_k = self.global_remainder[0][:, :, block_st:block_ed, :]
                    current_v = self.global_remainder[1][:, :, block_st:block_ed, :]
                    block_k_raw = self._from_group_kv(current_k)
                    
                    curr_ext_emb = None
                    if getattr(self, "global_remainder_ext", None) is not None:
                        ext_slice = self.global_remainder_ext[:, block_st:block_ed, :]
                        curr_ext_emb = ext_slice.mean(dim=1)
                    elif external_embeddings is not None:
                        curr_ext_emb = external_embeddings.mean(dim=1) 
                    
                    # Run single-frame clustering (Add Block)
                    with Profiler.get_instance().timer("Enc: Clustering Logic", "compute"):
                        # --- Update Retrieval & Anchors ---
                        self.retrieval_manager.add_block(
                            block_k_raw, 
                            self.num_global_block, 
                            external_emb=curr_ext_emb,
                            kv_pair=(current_k, current_v) # Pass KV for anchor storage
                        )
                    
                    end_event_overhead.record()
                    torch.cuda.synchronize()
                    self.num_global_block += 1
                    global_remainder_st += self.block_size

        self._global_remainder_ed = global_remainder_ed
        self._global_remainder_st = global_remainder_st

    # ========================================================================
    # [Main Interface] Data preparation and KVCache update
    # ========================================================================

    def append(self, local_q, local_k, local_v, global_q, global_k, global_v, external_embeddings=None):
        # E2E latency measurement: start timer at layer 0
        if self.layer_idx == 0:
            torch.cuda.synchronize()
            self._e2e_start_time = time.time()
        
        if not self.initialized:
            self.init(local_q, local_k, local_v, global_q, global_k, global_v)
        if external_embeddings is None:
            external_embeddings = self.temp_external_embeddings
        input_length = local_q.size(-2)
        
        # Inject absolute coordinate offset into the RoPE proxy
        if hasattr(self.position_embedding, "chunk_offset"):
            self.position_embedding.chunk_offset = self.length

        # 1. Update local KV cache
        if self.async_global_stream:
            GLOBAL_STREAM.wait_stream(torch.cuda.current_stream())
        self.local_k = torch.cat((self.local_k, local_k), dim=-2)
        self.local_v = torch.cat((self.local_v, local_v), dim=-2)
        kv_length = self.local_k.size(-2)
        
        # 2. Append to global remainder (including external embeddings)
        with torch.cuda.stream(GLOBAL_STREAM):
            self._global_remainder_st = 0
            self._global_remainder_ed = self.global_remainder[0].size(-2)
            self.global_remainder = (
                torch.cat((self.global_remainder[0], global_k), dim=-2),
                torch.cat((self.global_remainder[1], global_v), dim=-2),
            )
            # Physical-length absolute alignment guard.
            # If the buffer dimension changes (e.g. CLIP 768 -> LLM ViT 3584), discard and rebuild.
            input_length_for_ext = global_k.size(-2)
            ext_dim = external_embeddings.size(-1) if external_embeddings is not None else 768
            
            if getattr(self, "global_remainder_ext", None) is not None and self.global_remainder_ext.size(-1) != ext_dim:
                self.global_remainder_ext = None
            
            if getattr(self, "global_remainder_ext", None) is None:
                # Pre-fill zeros to cover tokens that were already in the buffer (e.g. system prompt)
                if self._global_remainder_ed > 0:
                    self.global_remainder_ext = torch.zeros((self.num_units, self._global_remainder_ed, ext_dim), dtype=torch.float32, device=global_k.device)
                else:
                    self.global_remainder_ext = torch.empty((self.num_units, 0, ext_dim), dtype=torch.float32, device=global_k.device)

            if external_embeddings is not None:
                ext_len = external_embeddings.size(1)
                if ext_len == input_length_for_ext:
                    # Video encoding phase: perfect alignment
                    ext_to_add = external_embeddings.float()
                elif ext_len == 1:
                    # QA phase: broadcast single-frame query to full prompt length
                    ext_to_add = external_embeddings.float().expand(-1, input_length_for_ext, -1)
                else:
                    # Rare misalignment: pad with zeros as a safe fallback
                    ext_to_add = torch.zeros((self.num_units, input_length_for_ext, ext_dim), dtype=torch.float32, device=global_k.device)
                
                self.global_remainder_ext = torch.cat((self.global_remainder_ext, ext_to_add), dim=1)
            else:
                # Pure text: pad with zeros to keep pointer alignment
                dummy_ext = torch.zeros((self.num_units, input_length_for_ext, ext_dim), dtype=torch.float32, device=global_k.device)
                self.global_remainder_ext = torch.cat((self.global_remainder_ext, dummy_ext), dim=1)

            
        # =========================================================
        # 3. Retrieve Global Anchors (raw KV tensors)
        # =========================================================
        anchor_k, anchor_v = None, None
        if self.encoding_strategy == 'cluster_global_anchors':
            # Cutoff: only frames older than the local window can serve as anchors
            current_block_idx = self.num_global_block
            n_local_blocks = math.ceil(self.n_local / self.block_size)
            cutoff = current_block_idx - n_local_blocks
            
            # Retrieve anchors that pass the cutoff filter
            anchor_k, anchor_v = self.retrieval_manager.get_current_anchor_kv(cutoff)

        o_list = []
        for st in range(0, input_length, self.exc_block_size):
            ed = min(st + self.exc_block_size, input_length)
            
            # Compute the local-window slice
            kv_st = max(kv_length + st - input_length - self.n_local, 0)
            kv_ed = kv_length + ed - input_length

            chunk_local_q = local_q[:, :, st:ed, :]
            chunk_local_k = self.local_k[:, :, kv_st: kv_ed, :]
            chunk_local_v = self.local_v[:, :, kv_st: kv_ed, :]
            chunk_global_q = global_q[:, :, st:ed, :] # Raw Tensor
            
            # 4. Run core attention computation (with raw Global Anchors)
            chunk_o = self._append(
                chunk_local_q,
                chunk_local_k,
                chunk_local_v,
                chunk_global_q,
                extra_global_k=anchor_k, 
                extra_global_v=anchor_v
            )
            o_list.append(chunk_o)
            
            with torch.cuda.stream(GLOBAL_STREAM):
                curr_ext_slice = None
                if external_embeddings is not None:
                     curr_ext_slice = external_embeddings[:, st:ed, :]
                self._append_global(external_embeddings=curr_ext_slice)
            if self.async_global_stream:
                torch.cuda.current_stream().wait_stream(GLOBAL_STREAM)
        
        self.length += input_length


        # Trim local KV cache to the local window size
        if self.local_k.size(-2) >= self.n_local:
             self.local_k = self.local_k[:, :, -self.n_local:, :]
             self.local_v = self.local_v[:, :, -self.n_local:, :]

        # Flush the processed portion of global remainder
        with torch.cuda.stream(GLOBAL_STREAM):
            self.global_remainder = (
                self.global_remainder[0][:, :, self._global_remainder_st:, :],
                self.global_remainder[1][:, :, self._global_remainder_st:, :]
            )
            if getattr(self, "global_remainder_ext", None) is not None:
                self.global_remainder_ext = self.global_remainder_ext[:, self._global_remainder_st:, :]


        # E2E latency log: only for Layer 0 and long inputs (video feature batches)
        if DEBUG_SYSTEM and self.layer_idx == 0 and input_length > 100:
            torch.cuda.synchronize()
            e2e_time_ms = (time.time() - self._e2e_start_time) * 1000
            mode = "Batch-K ON (vectorized)" if getattr(self, "enable_batch_clustering", True) else "Batch-K OFF (sequential)"
            logger.info(f"\n{'='*70}\n[E2E Performance] Layer 0\n[*] Mode: {mode}\n[*] Input length: {input_length} tokens\n[*] append() total latency (attention + clustering): {e2e_time_ms:.2f} ms\n{'='*70}")


        return torch.cat(o_list, dim=-2)
    
    def size(self, *args, **kwargs):
        return self.length

    def calculate_cpu_memory(self):
        memory = 0
        for u in range(self.num_units):
            for block in self.global_blocks[u]:
                memory += block.calculate_cpu_memory()
        return memory
    
    # [Phase 4] Resource cleanup
    def free_encoding_memory(self):
        """Release temporary VRAM allocated during the encoding phase (e.g. Global Anchors)."""
        if hasattr(self, 'retrieval_manager'):
            self.retrieval_manager.free_anchor_memory()

