import torch
from typing import Optional, List, Union, Tuple
from transformers.models.qwen2.modeling_qwen2 import Qwen2RotaryEmbedding
from transformers.modeling_outputs import CausalLMOutputWithPast
from transformers.modeling_outputs import BaseModelOutputWithPast

from logzero import logger
from clustervlm.attention import RotaryEmbeddingESM, clustervlm_attention_forward

# Qwen2.5-VL component imports (optional; gracefully degrade on older environments)
try:
    from transformers import Qwen2_5_VLForConditionalGeneration
    from transformers.models.qwen2_5_vl.modeling_qwen2_5_vl import Qwen2_5_VLRotaryEmbedding
    logger.info("[ClusterVLM Setup] Qwen2.5-VL modules imported successfully.")
except ImportError:
    # Compatible with older environments
    Qwen2_5_VLForConditionalGeneration = None
    Qwen2_5_VLRotaryEmbedding = None
    logger.warning("[ClusterVLM Setup] Qwen2.5-VL modules NOT found. Skipped.")

def huggingface_forward(forward):
    def hf_forward(
        self,
        hidden_states: torch.Tensor,
        attention_mask = None,
        position_ids = None,
        past_key_value = None,
        output_attentions: bool = False,
        use_cache: bool = False,
        **kwargs,
    ):
        assert not output_attentions
        external_embeddings = kwargs.get('external_embeddings', None)

        if past_key_value is None and 'past_key_values' in kwargs:
            past_key_value = kwargs['past_key_values']

        # Dynamically inject global absolute 3D RoPE coordinates into the RoPE proxy
        # when a ClusterVLM ContextManager is detected as the KVCache.
        if type(past_key_value).__name__ == "ContextManager":
            cm = past_key_value
            pb = getattr(cm, "position_embedding", None)
            if pb is not None:
                pb.system_prompt_len = cm.n_init
                if not getattr(cm, "to_retrieve", False):
                    # Frame encoding phase: disable 3D coordinate generation
                    pb.is_qa_phase = False
                else:
                    # Query retrieval phase: enable 3D coordinates for text tokens
                    pb.is_qa_phase = True

        num_heads = getattr(self, "num_heads", self.config.num_attention_heads)
        num_key_value_heads = getattr(self, "num_key_value_heads", self.config.num_key_value_heads)

        ret = forward(
            self, hidden_states, hidden_states,
            position_ids, use_cache, past_key_value,
            self.q_proj, self.k_proj, self.v_proj, self.o_proj, 
            self.head_dim, num_heads, num_key_value_heads, 
            external_embeddings=external_embeddings,
        )
        
        if use_cache: o, pkv = ret
        else: o = ret; pkv = None
        return o, None, pkv

    return hf_forward


def patch_hf(
    model,
    attn_kwargs: dict = {},
    base = None, 
    distance_scale = None,
    **kwargs
):
    attn_kwargs.update(kwargs)
    from transformers import LlamaForCausalLM, MistralForCausalLM, Qwen2ForCausalLM, Qwen2Model
    from transformers.models.llama.modeling_llama import LlamaAttention, LlamaModel, BaseModelOutputWithPast

    # Monkey-patch for Qwen2DecoderLayer (transformers >= 4.48.0).
    # Forces the DecoderLayer to return past_key_value so ClusterVLM can intercept and inject the KVCache.
    def qwen2_decoder_layer_forward_patched(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_value: Optional[Tuple[torch.Tensor]] = None,
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None,  # Added in transformers 4.48+
        **kwargs,
    ) -> Tuple[torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]]:
        
        residual = hidden_states
        hidden_states = self.input_layernorm(hidden_states)

        # Self Attention
        # Force receive 3 return values (hidden, attn_weights, present_kv).
        # The original 4.48+ code only receives 2 values and drops the cache.
        hidden_states, self_attn_weights, present_key_value = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_value=past_key_value,
            output_attentions=output_attentions,
            use_cache=use_cache,
            cache_position=cache_position,
            position_embeddings=position_embeddings,
            **kwargs,
        )
        hidden_states = residual + hidden_states

        # Feed-Forward Network
        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (self_attn_weights,)

        # Explicitly return the KVCache
        if use_cache:
            outputs += (present_key_value,)

        return outputs
    
    # Monkey-patch for Qwen2.5-VL DecoderLayer.
    # Forces cache return to connect the ClusterVLM data flow.
    def qwen2_5_vl_decoder_layer_forward_patched(
        self,
        hidden_states: torch.Tensor,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[Tuple[torch.Tensor]] = None,  # Note: official parameter is plural
        output_attentions: Optional[bool] = False,
        use_cache: Optional[bool] = False,
        cache_position: Optional[torch.LongTensor] = None,
        position_embeddings: Optional[Tuple[torch.Tensor, torch.Tensor]] = None, 
        **kwargs,
    ) -> Tuple[torch.FloatTensor, Optional[Tuple[torch.FloatTensor, torch.FloatTensor]]]:
        
        residual = hidden_states
        
        layer_idx = None
        if hasattr(self.self_attn, "layer_idx"):
            layer_idx = self.self_attn.layer_idx

        # Apply layer normalization
        hidden_states = self.input_layernorm(hidden_states)

        # Self Attention
        # ClusterVLM's Attention forward returns 3 values: (hidden, weights, cache).
        # The official Qwen2.5-VL only receives 2; intercept here and propagate the cache.
        hidden_states, self_attn_weights, present_key_value = self.self_attn(
            hidden_states=hidden_states,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            output_attentions=output_attentions,
            use_cache=use_cache,
            cache_position=cache_position,
            position_embeddings=position_embeddings,
            **kwargs,
        )
        hidden_states = residual + hidden_states

        residual = hidden_states
        hidden_states = self.post_attention_layernorm(hidden_states)
        hidden_states = self.mlp(hidden_states)
        hidden_states = residual + hidden_states

        outputs = (hidden_states,)

        if output_attentions:
            outputs += (self_attn_weights,)

        # Explicitly return the KVCache
        if use_cache:
            outputs += (present_key_value,)

        return outputs
    
    # Qwen2.5-VL Synthetic 3D RoPE proxy.
    # Intercepts ClusterVLM's linear-index RoPE calls and internally maps them to
    # Qwen2.5-VL's 3D (T, H, W) coordinate system.
    # Structure of the context window: [Text (System)] + [Video (Retrieved)] + [Text (Question)]
    class Qwen2_5_Synthetic_3D_RoPE(torch.nn.Module):
        def __init__(self, original_rope, config):
            super().__init__()
            self.original_rope = original_rope
            self.config = config
            
            if hasattr(config, "rope_scaling") and config.rope_scaling:
                self.mrope_section = config.rope_scaling.get("mrope_section", [16, 24, 24])
            elif hasattr(config, "text_config") and hasattr(config.text_config, "rope_scaling"):
                self.mrope_section = config.text_config.rope_scaling.get("mrope_section", [16, 24, 24])
            else:
                self.mrope_section = [16, 24, 24] 
            
            dim = original_rope.config.hidden_size // original_rope.config.num_attention_heads
            if hasattr(original_rope.config, "head_dim"):
                dim = original_rope.config.head_dim
            
            base = getattr(original_rope.config, "rope_theta", 1000000.0)
            self.fallback_rope = RotaryEmbeddingESM(dim, base)
            
            self.tokens_per_frame = 196
            self.grid_size = 14
            self.system_prompt_len = 15 
            self.video_token_end_index = 100000000 
            
            vision_config = getattr(config, "vision_config", None) or getattr(getattr(config, "model", None), "vision_config", None)
            self.tokens_per_second = getattr(vision_config, "tokens_per_second", 25.0) if vision_config else 25.0
            self.temporal_patch_size = getattr(vision_config, "temporal_patch_size", 2) if vision_config else 2
            
            self.video_fps = 0.5 
            self.t_step = (self.temporal_patch_size / self.video_fps) * self.tokens_per_second

            # Flag indicating this is a 3D RoPE module
            self.is_3d_rope = True

            self.is_qa_phase = False

            # [Keep as-is] Do not arbitrarily add/remove attributes
            self.chunk_offset = 0  # Initial offset is 0
            self._last_rotated_q = None  # Cache for intercepting 1D rotation

        @property
        def _cos_cached(self): return self.fallback_rope._cos_cached
        @_cos_cached.setter
        def _cos_cached(self, value): self.fallback_rope._cos_cached = value
        @property
        def _sin_cached(self): return self.fallback_rope._sin_cached
        @_sin_cached.setter
        def _sin_cached(self, value): self.fallback_rope._sin_cached = value
        @property
        def inv_freq(self): return self.fallback_rope.inv_freq
        @inv_freq.setter
        def inv_freq(self, value): self.fallback_rope.inv_freq = value
        
        # [CRITICAL] Preserve interface contract; do NOT remove
        def _update_cos_sin_tables_len(self, *args, **kwargs):
            return self.fallback_rope._update_cos_sin_tables_len(*args, **kwargs)

        def apply_rotary_pos_emb_one_angle(self, x, index):
            # Intercept 1D RoPE rotation attempts on video queries.
            # When the ContextManager tries to apply a 1D RoPE to video Query tokens,
            # substitute the precomputed 3D-rotated Query instead.
            if hasattr(self, "_last_rotated_q") and self._last_rotated_q is not None:
                if self._last_rotated_q.shape == x.shape:
                    return self._last_rotated_q
            return self.fallback_rope.apply_rotary_pos_emb_one_angle(x, index)

        def rotate_k_only(self, k, position_ids):
            """Rotate K only (not Q) to avoid length mismatch errors with the system prompt."""
            cos, sin = self.original_rope(k, position_ids)
            def rotate_half(x): return torch.cat((-x[..., x.shape[-1] // 2 :], x[..., : x.shape[-1] // 2]), dim=-1)
            
            # Fix mrope dimension channel slice alignment
            mrope_section = self.mrope_section * 2  
            
            cos = torch.cat([m[i % 3] for i, m in enumerate(cos.split(mrope_section, dim=-1))], dim=-1).unsqueeze(1)
            sin = torch.cat([m[i % 3] for i, m in enumerate(sin.split(mrope_section, dim=-1))], dim=-1).unsqueeze(1)
            k_len = k.shape[-2]
            k_embed = (k * cos[..., -k_len:, :]) + (rotate_half(k) * sin[..., -k_len:, :])
            return k_embed.to(k.dtype)

        def _apply_rope(self, q, k, cos, sin):
            def rotate_half(x):
                x1 = x[..., : x.shape[-1] // 2]
                x2 = x[..., x.shape[-1] // 2 :]
                return torch.cat((-x2, x1), dim=-1)

            # Must use list copy [16,24,24,16,24,24]; NEVER use a list comprehension here
            mrope_section = self.mrope_section * 2

            cos = torch.cat([m[i % 3] for i, m in enumerate(cos.split(mrope_section, dim=-1))], dim=-1).unsqueeze(1)
            sin = torch.cat([m[i % 3] for i, m in enumerate(sin.split(mrope_section, dim=-1))], dim=-1).unsqueeze(1)
            
            q_len = q.shape[-2]
            k_len = k.shape[-2]
            
            cos_q = cos[..., -q_len:, :]
            sin_q = sin[..., -q_len:, :]
            cos_k = cos[..., -k_len:, :]
            sin_k = sin[..., -k_len:, :]

            q_embed = (q * cos_q) + (rotate_half(q) * sin_q)
            k_embed = (k * cos_k) + (rotate_half(k) * sin_k)
            return q_embed.to(q.dtype), k_embed.to(k.dtype)

        def forward(self, q: torch.Tensor, k: torch.Tensor, position_ids_tensor=None, seq_dim=-2):
            seq_len = k.shape[seq_dim]
            device = k.device
            
            is_qa_phase = getattr(self, "is_qa_phase", False)
            
            if position_ids_tensor is not None and not isinstance(position_ids_tensor, torch.nn.Module):
                if position_ids_tensor.dim() == 3: indices = position_ids_tensor[0, 0, :] 
                elif position_ids_tensor.dim() == 2: indices = position_ids_tensor[0, :]
                else: indices = position_ids_tensor
            else:
                # Maintain pure relative coordinate mechanism
                indices = torch.arange(seq_len, device=device, dtype=torch.long)
            
            is_system = indices < self.system_prompt_len
            is_video = (indices >= self.system_prompt_len) & (indices < self.video_token_end_index)
            is_text_tail = indices >= self.video_token_end_index
            
            video_relative_idx = torch.clamp(indices - self.system_prompt_len, min=0)
            block_idx = video_relative_idx // self.tokens_per_frame
            
            v_t = self.system_prompt_len + (block_idx * self.t_step).long()
            # Fix global offset of H and W coordinates
            v_h = (video_relative_idx % self.tokens_per_frame) // self.grid_size + self.system_prompt_len
            v_w = (video_relative_idx % self.tokens_per_frame) % self.grid_size + self.system_prompt_len
            
            t_final = indices.clone()
            h_final = indices.clone()
            w_final = indices.clone()
            
            t_final[is_video] = v_t[is_video]
            h_final[is_video] = v_h[is_video]
            w_final[is_video] = v_w[is_video]
            
            total_video_blocks = (self.video_token_end_index - self.system_prompt_len) // self.tokens_per_frame
            if total_video_blocks > 0:
                last_video_t = self.system_prompt_len + int((total_video_blocks - 1) * self.t_step)
                question_start_t = last_video_t + 1
                
                if is_text_tail.any():
                    # Compute the start physical index of the text tail
                    tail_start_phys = indices[is_text_tail][0]
                    # Compute the mrope_delta to seamlessly connect text T coordinates to video T
                    mrope_delta = tail_start_phys - question_start_t
                    # Adjust text-tail coordinates only
                    t_final[is_text_tail] -= mrope_delta
                    h_final[is_text_tail] -= mrope_delta
                    w_final[is_text_tail] -= mrope_delta

            if hasattr(self.original_rope, "inv_freq") and self.original_rope.inv_freq.device != device:
                self.original_rope.to(device)

            ids = torch.stack([t_final, h_final, w_final], dim=0).unsqueeze(1).expand(3, k.shape[0], -1)

            cos, sin = self.original_rope(k, ids)
            
            q_emb, k_embed = self._apply_rope(q, k, cos, sin)
            
            # Cache the 3D-rotated query for potential interception
            self._last_rotated_q = q_emb
            
            return q_emb, k_embed

    # 1. Inner Model Forward
    def model_forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask = None,
        position_ids = None,
        past_key_values = None,
        inputs_embeds = None,
        use_cache = None,
        output_attentions = None,
        output_hidden_states = None,
        return_dict = None,
        *args,
        **kwargs
    ):
        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        use_cache = use_cache if use_cache is not None else self.config.use_cache
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        if input_ids is not None and inputs_embeds is not None:
            raise ValueError("You cannot specify both decoder_input_ids and decoder_inputs_embeds at the same time")
        elif input_ids is not None:
            batch_size, seq_length = input_ids.shape
        elif inputs_embeds is not None:
            batch_size, seq_length, _ = inputs_embeds.shape
        else:
            raise ValueError("You have to specify either decoder_input_ids or decoder_inputs_embeds")

        if inputs_embeds is None:
            inputs_embeds = self.embed_tokens(input_ids)
            if hasattr(self, "config") and hasattr(self.config, "scale_emb"):
                inputs_embeds = inputs_embeds * self.config.scale_emb

        if use_cache:
            pkv = tuple()
        else:
            pkv = None

        hidden_states = inputs_embeds
        external_embeddings = kwargs.get("external_embeddings", None)

        all_hidden_states = () if output_hidden_states else None
        all_self_attns = () if output_attentions else None

        # RoPE pre-computation logic for transformers >= 4.45+ (preserved as-is)
        # The position_ids passing logic is preserved here; ClusterVLM will handle it internally.
        
        for i, decoder_layer in enumerate(self.layers):
            if output_hidden_states:
                all_hidden_states += (hidden_states,)

            layer_outputs = decoder_layer(
                hidden_states,
                attention_mask=attention_mask,
                position_ids=self.position_bias,
                past_key_value=past_key_values[i] if past_key_values is not None else None,
                output_attentions=output_attentions,
                use_cache=use_cache,
                external_embeddings=external_embeddings, 
            )

            hidden_states = layer_outputs[0]

            if use_cache:
                _cache = layer_outputs[2 if output_attentions else 1]
                pkv = pkv + (_cache,)

            if output_attentions:
                all_self_attns += (layer_outputs[1],)

        hidden_states = self.norm(hidden_states)

        if output_hidden_states:
            all_hidden_states += (hidden_states,)

        if not return_dict:
            return tuple(v for v in [hidden_states, pkv, all_hidden_states, all_self_attns] if v is not None)
        return BaseModelOutputWithPast(
            last_hidden_state=hidden_states,
            past_key_values=pkv,
            hidden_states=all_hidden_states,
            attentions=all_self_attns,
        )

    # 2. Outer Model Forward
    def causal_lm_forward(
        self,
        input_ids: torch.LongTensor = None,
        attention_mask: Optional[torch.Tensor] = None,
        position_ids: Optional[torch.LongTensor] = None,
        past_key_values: Optional[List[torch.FloatTensor]] = None,
        inputs_embeds: Optional[torch.FloatTensor] = None,
        labels: Optional[torch.LongTensor] = None,
        use_cache: Optional[bool] = None,
        output_attentions: Optional[bool] = None,
        output_hidden_states: Optional[bool] = None,
        return_dict: Optional[bool] = None,
        *args, 
        **kwargs 
    ):
        external_embeddings = kwargs.get('external_embeddings', None)

        output_attentions = output_attentions if output_attentions is not None else self.config.output_attentions
        output_hidden_states = (
            output_hidden_states if output_hidden_states is not None else self.config.output_hidden_states
        )
        return_dict = return_dict if return_dict is not None else self.config.use_return_dict

        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            position_ids=position_ids,
            past_key_values=past_key_values,
            inputs_embeds=inputs_embeds,
            use_cache=use_cache,
            output_attentions=output_attentions,
            output_hidden_states=output_hidden_states,
            return_dict=return_dict,
            external_embeddings=external_embeddings, 
        )

        hidden_states = outputs[0]
        logits = self.lm_head(hidden_states)
        logits = logits.float()

        loss = None
        if labels is not None:
            shift_logits = logits[..., :-1, :].contiguous()
            shift_labels = labels[..., 1:].contiguous()
            loss_fct = torch.nn.CrossEntropyLoss()
            shift_logits = shift_logits.view(-1, self.config.vocab_size)
            shift_labels = shift_labels.view(-1)
            shift_labels = shift_labels.to(shift_logits.device)
            loss = loss_fct(shift_logits, shift_labels)

        if not return_dict:
            output = (logits,) + outputs[1:]
            return ((loss,) + output) if loss is not None else output

        return CausalLMOutputWithPast(
            loss=loss,
            logits=logits,
            past_key_values=outputs.past_key_values,
            hidden_states=outputs.hidden_states,
            attentions=outputs.attentions,
        )

    forward = huggingface_forward(clustervlm_attention_forward(**attn_kwargs))

    backbone = None
    Attention = None
    ModelClass = None

    logger.info(f"[ClusterVLM Patch] patching model type: {type(model).__name__}")

    if isinstance(model, LlamaForCausalLM):
        backbone = model.model
        Attention = backbone.layers[0].self_attn.__class__
        ModelClass = backbone.__class__
    elif isinstance(model, MistralForCausalLM):
        backbone = model.model
        Attention = backbone.layers[0].self_attn.__class__
        ModelClass = backbone.__class__
    elif isinstance(model, Qwen2ForCausalLM):
        backbone = model.model
        Attention = backbone.layers[0].self_attn.__class__
        ModelClass = backbone.__class__
    
    # Compatibility for transformers >= 4.52.1:
    # LLaVA may pass a bare Qwen2Model (no .model attribute).
    elif isinstance(model, Qwen2Model):
        backbone = model  # itself is the backbone
        Attention = backbone.layers[0].self_attn.__class__
        ModelClass = backbone.__class__
        logger.info("[ClusterVLM Patch] Detected pure Qwen2Model (Backbone), adapting structure...")
    
    # Qwen2.5-VL: structure is model -> visual + language_model (Backbone)
    elif Qwen2_5_VLForConditionalGeneration is not None and isinstance(model, Qwen2_5_VLForConditionalGeneration):
        backbone = model.model.language_model
        Attention = backbone.layers[0].self_attn.__class__
        ModelClass = backbone.__class__
        logger.info("[ClusterVLM Patch] Detected Qwen2.5-VL! Extracting TextModel backbone...")

    elif model.__class__.__name__ == "MiniCPMForCausalLM":
        backbone = model.model
        Attention = backbone.layers[0].self_attn.__class__
        ModelClass = backbone.__class__
    else:
        logger.error(f"[ClusterVLM Patch] Unsupported model class: {model.__class__.__name__}")
        raise ValueError(f"Only supports llama, mistral and qwen2 models, not {model.__class__.__name__}.")

    logger.info(f"[ClusterVLM Patch] Backbone identified: {ModelClass.__name__}")

    # Locate the RoPE module: prefer a model-level global RoPE (transformers >= 4.48),
    # fall back to the per-layer RoPE otherwise.
    if hasattr(backbone, "rotary_emb"):
        hf_rope = backbone.rotary_emb
        logger.info("[ClusterVLM Patch] Found Global RoPE in Backbone (transformers >= 4.48)")
    else:
        hf_rope = backbone.layers[0].self_attn.rotary_emb
        logger.info("[ClusterVLM Patch] Found Local RoPE in Attention Layer (transformers < 4.48)")

    is_qwen2_rope = isinstance(hf_rope, Qwen2RotaryEmbedding)
    is_qwen2_5_vl_rope = (Qwen2_5_VLRotaryEmbedding is not None and isinstance(hf_rope, Qwen2_5_VLRotaryEmbedding))

    if is_qwen2_rope or is_qwen2_5_vl_rope:
        if hasattr(hf_rope, "config") and hf_rope.config is not None:
            base = getattr(hf_rope.config, "rope_theta", 1000000.0)
            
            base_hidden = hf_rope.config.hidden_size
            base_heads = hf_rope.config.num_attention_heads
            # Prefer head_dim from config; adapted for Qwen2.5-VL
            if hasattr(hf_rope.config, "head_dim"):
                dim = hf_rope.config.head_dim
            else:
                dim = base_hidden // base_heads
            
            logger.info(f"[ClusterVLM Patch] RoPE Config from {type(hf_rope).__name__}: Base={base}, Dim={dim}")
        else:
            # Legacy fallback
            base = hf_rope.base
            distance_scale = distance_scale if distance_scale is not None else 1.0
            dim = hf_rope.dim
    else:
        # Llama / Mistral logic (unchanged)
        base = hf_rope.config.rope_theta
        distance_scale = distance_scale if distance_scale is not None else 1.0
        partial_rotary_factor = hf_rope.config.partial_rotary_factor if hasattr(hf_rope.config, "partial_rotary_factor") else 1.0
        dim = int((hf_rope.config.hidden_size // hf_rope.config.num_attention_heads) * partial_rotary_factor)
    
    if distance_scale is None: 
        distance_scale = 1.0
    
    if is_qwen2_5_vl_rope:
        # Pass the full VL config (which contains vision_config) rather than the text backbone config
        full_config = getattr(model, "config", None)
        if full_config is None:
            full_config = backbone.config  # Fallback
            
        rope_proxy = Qwen2_5_Synthetic_3D_RoPE(hf_rope, full_config)
        backbone.position_bias = rope_proxy
        logger.info("[ClusterVLM Patch] Injected Qwen2.5-VL Synthetic 3D RoPE Proxy")
    else:
        # Llama / Qwen2 path
        rope = RotaryEmbeddingESM(dim, base, distance_scale)
        backbone.position_bias = rope
        logger.info(f"[ClusterVLM Patch] Injected ClusterVLM RotaryEmbedding into {type(backbone).__name__}")

    def set_forward(m):
        if isinstance(m, Attention):
            m._old_forward = m.forward
            m.forward = forward.__get__(m, Attention)

    model.apply(set_forward)

    # Apply Monkey Patch to the DecoderLayer class for KVCache return compatibility
    DecoderLayerClass = backbone.layers[0].__class__
    
    if DecoderLayerClass.__name__ == "Qwen2DecoderLayer":
        if not hasattr(DecoderLayerClass, "_is_clustervlm_patched"):
            logger.info(f"[ClusterVLM Patch] Applying Monkey Patch to {DecoderLayerClass.__name__} for cache return compatibility.")
            DecoderLayerClass._old_forward = DecoderLayerClass.forward
            DecoderLayerClass.forward = qwen2_decoder_layer_forward_patched
            DecoderLayerClass._is_clustervlm_patched = True
    elif DecoderLayerClass.__name__ == "Qwen2_5_VLDecoderLayer":
        if not hasattr(DecoderLayerClass, "_is_clustervlm_patched"):
            logger.info(f"[ClusterVLM Patch] Applying Monkey Patch to {DecoderLayerClass.__name__}")
            DecoderLayerClass._old_forward = DecoderLayerClass.forward
            DecoderLayerClass.forward = qwen2_5_vl_decoder_layer_forward_patched
            DecoderLayerClass._is_clustervlm_patched = True
        else:
            logger.info(f"[ClusterVLM Patch] {DecoderLayerClass.__name__} already patched.")

    backbone._old_forward = backbone.forward
    backbone.forward = model_forward.__get__(backbone, ModelClass)

    if isinstance(model, (LlamaForCausalLM, MistralForCausalLM, Qwen2ForCausalLM)):
        model._old_forward = model.forward
        model.forward = causal_lm_forward.__get__(model, model.__class__)
        
    elif Qwen2_5_VLForConditionalGeneration is not None and isinstance(model, Qwen2_5_VLForConditionalGeneration):
        logger.info("[ClusterVLM Patch] Replacing outer forward for Qwen2.5-VL Wrapper")
        model._old_forward = model.forward
        model.forward = causal_lm_forward.__get__(model, model.__class__)

    # Explicitly inject layer_idx into each Attention module to bypass DecoderLayer parameter passing limitations
    for i, layer in enumerate(backbone.layers):
        if hasattr(layer, "self_attn"):
            layer.self_attn.layer_idx = i

    return model
